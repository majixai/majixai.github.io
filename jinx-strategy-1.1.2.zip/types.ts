

export enum OptionType {
  Call = "call",
  Put = "put",
}

export enum Action {
  Buy = "buy",
  Sell = "sell",
}

export interface OptionLeg {
  id: string;
  type: OptionType;
  action: Action;
  strike: string; 
  premium: string; 
  quantity: string; 
  role?: string;
  premiumMissing?: boolean; 
}

export interface PlotOptions {
  id: string; 
  underlyingName: string;
  currentS: string;
  pointValue: string;
  minST: string;
  maxST: string;
  numPoints: string;
  showIndividualLegs: boolean;
  initialTTEForSimulation?: number | null; 
  simulationSigma?: string; 
  simulationR?: string;     
}

export interface StrategyLegDefinition {
  type: OptionType;
  action: Action;
  quantity: number;
  role: string; 
}

export interface PredefinedStrategy {
  name: string;
  legs: StrategyLegDefinition[];
}

export interface PayoffPoint {
  s_t: number; 
  p_l: number; 
  [key: string]: number; 
}

export interface ChartData {
  sTArray: number[];
  totalPayoff: number[];
  individualLegPayoffs: number[][];
  legDescriptions: string[];
  minSTPlot: number;
  maxSTPlot: number;
  currentSNum?: number;
  underlyingName: string;
  strategyTitleShort?: string; 
  maxProfit?: number;
  maxLoss?: number;
  riskRewardRatio?: number | string; 
  profitZoneInPlot?: number; 
}

export interface BlackScholesInputs {
  stockPrice: string;
  strikePrice: string;
  timeToExpiration: string; 
  riskFreeRate: string; 
  volatility: string; 
  optionType: OptionType;
}

export interface BlackScholesResults {
  callPrice?: number;
  putPrice?: number;
  callDelta?: number;
  putDelta?: number;
  gamma?: number;
  vega?: number;
  callTheta?: number;
  putTheta?: number;
  callRho?: number;
  putRho?: number;
}

export interface GroundingSource {
  uri: string;
  title: string;
}

export interface OptionChainEntry { 
  strike: number;
  bid: number | null;
  ask: number | null;
  last: number | null;
  mid?: number | null; 
  openInterest?: number | null;
  volume?: number | null;
  parity?: number | null; 
  expirationDate?: string; 
  impliedVolatility?: number | null;
  delta?: number | null;
  gamma?: number | null;
  theta?: number | null;
  vega?: number | null;
}

export interface OptionsChainData { 
  expirationDate: string | null; 
  calls: OptionChainEntry[];
  puts: OptionChainEntry[];
  currentStockPriceForChain?: number | null; 
  source?: 'gemini' | 'fmp'; 
}


export interface TargetStrikeInfo {
  role: string;
  targetStrike: number | null;
}

export interface GeminiStrategyDataResponse {
  currentStockPrice?: number | null;
  optionsChain?: OptionsChainData | null; 
  targetStrikesByRole?: TargetStrikeInfo[];
  suggestedPointValue?: number | null;
  suggestedNumPoints?: number | null;
  dataComment?: string;
  error?: string;
  sources?: GroundingSource[];
  durationMs?: number; 
  fmpDataUsed?: boolean;
}

export interface GeminiBlackScholesInputsResponse {
  stockPrice?: number | null;
  strikePrice?: number | null;
  timeToExpiration?: number | null; 
  riskFreeRate?: number | null;   
  volatility?: number | null;     
  dataComment?: string;
  error?: string;
  sources?: GroundingSource[];
  durationMs?: number; 
  fmpDataUsed?: boolean;
}

export interface BlackScholesFetchStatus {
  message: string;
  type: 'info' | 'success' | 'warning' | 'error';
  key: number;
}

export interface SuggestedStrategyInfo {
    name: string; 
    reasoning?: string; 
    rank?: number; 
    suitability?: 'High' | 'Medium' | 'Low' | string; 
}

export interface StoredAISuggestion extends SuggestedStrategyInfo { 
  id: string; 
  underlyingName: string; 
  timestamp: number;
}

export interface GeminiStrategySuggestionResponse {
    suggestedStrategies?: SuggestedStrategyInfo[];
    dataComment?: string;
    error?: string;
    sources?: GroundingSource[];
    durationMs?: number; 
    fmpDataUsed?: boolean;
}

export enum StockPriceCategory {
    Below15 = "Below $15",
    AboveOrEqual15 = "Above/Equal $15",
}

export enum OutlookHorizon {
    ShortTerm = "Short-Term", 
    MidTerm = "Mid-Term",   
    LongTerm = "Long-Term",    
}

export interface PriceProjectionDetail {
    targetPrice: number;
    probabilityEstimate?: string; 
    projectedPriceChangePercent: number;
    timelineDetail: string; 
    reasoning?: string; 
    stdDevLevels?: { 
        level1up: number;
        level1down: number;
        level2up: number;
        level2down: number;
    };
}

export interface ChartPatternInfo {
    patternName: string;
    description: string;
    timeframe: string;
    keyLevels?: string;
    status?: "Forming" | "Confirmed Breakout" | "Failed Breakout" | "Approaching Resistance/Support";
}

export interface BarPlayAnalysisInfo {
    playType: string; 
    outcome?: "Identified - Bullish" | "Identified - Bearish" | "Not Clearly Identified" | "Potential Setup";
    confidence?: "High" | "Medium" | "Low";
    description: string; 
    relevantTimeframe?: string; 
}

export interface BullishStockSuggestion { 
    ticker: string;
    currentPrice: number | null;
    reasoning?: string; 
    priceCategory: StockPriceCategory;
    outlookHorizon: OutlookHorizon; 
    projectedPriceChangePercentMin?: number | null; 
    projectedPriceChangePercentMax?: number | null; 
    projectedTimeline?: string | null; 
    
    detailedReasoning?: string; 
    priceProjectionDetails?: PriceProjectionDetail[]; 
    microstructureInsights?: string;
    covarianceConsiderations?: string;
    advancedModelReferences?: string;
    analysisTimestamp?: number; 
    dataComment?: string; 
    currentChartPatterns?: ChartPatternInfo[]; 
    barPlayAnalysis?: BarPlayAnalysisInfo[];   
}
export interface StoredBullishStockSuggestion extends BullishStockSuggestion { 
    id: string; 
    timestamp: number; 
}

export interface GeminiBullishStockSuggestionResponse {
    suggestedStocks?: BullishStockSuggestion[];
    dataComment?: string;
    error?: string;
    sources?: GroundingSource[];
    durationMs?: number; 
    fmpDataUsed?: boolean;
}


export interface GeminiDeeperAnalysisResponse extends Partial<BullishStockSuggestion> {
    sources?: GroundingSource[];
    error?: string;
    durationMs?: number; 
    fmpDataUsed?: boolean;
    analysisTimestamp?: number; 
    currentChartPatterns?: ChartPatternInfo[];
    barPlayAnalysis?: BarPlayAnalysisInfo[];
}


export interface ReasoningModalInfo {
  title: string;
  reasoning: string;
}

export enum InsightTabKey {
    Status = "status",
    Tickers = "tickers",
    Strategies = "strategies",
    History = "history", 
    Analytics = "analytics", 
}

export interface GeneralStatusMessage {
    text: string;
    type: 'info' | 'success' | 'warning' | 'error';
    key: number;
}

export enum AICallType {
    StrategyData = 'strategyData',
    BsInputs = 'bsInputs',
    StrategyExplanation = 'strategyExplanation',
    StrategySuggestions = 'strategySuggestions',
    BullishStocksInitial = 'bullishStocksInitial',
    BullishStocksDeepDive = 'bullishStocksDeepDive',
    HistoricalOptionSuggestion = 'historicalOptionSuggestion', // Added new call type
}

export interface AppDBState {
    id: string; 
    selectedStrategyName: string;
    showBlackScholes: boolean;
    currentAIStrategySuggestions: StoredAISuggestion[] | null; 
    lastUnderlyingForStrategySuggestions: string | null; 
    currentAIBullishStockSuggestions: StoredBullishStockSuggestion[] | null; 
    lastFetchedBullishStocksTimestamp: number | null; 
    allAccumulatedAISources?: GroundingSource[] | null; 
    activeInsightTab?: InsightTabKey;
    aiCallDurations?: { [key in AICallType]?: number }; 
    showAnalyticsPanel?: boolean; 
}

export interface GitHubExportSettings {
    id: string; 
    pat: string;
    username: string;
    repoName: string;
    filePath: string;
}

export interface ModalPrimingLegInfo {
    legId: string;
    strike: string; 
    optionType: OptionType;
}

export interface HistoricalBullishSuggestionEntry {
    id: string; 
    ticker: string;
    priceAtSuggestion: number | null;
    initialTimestamp: number;
    projectedPriceChangePercentMin: number | null;
    projectedPriceChangePercentMax: number | null;
    projectedTimeline: string | null;
    priceCategory: StockPriceCategory;
    outlookHorizon: OutlookHorizon;
    reasoning: string | undefined; 
    detailedReasoning?: string;
    analysisTimestamp?: number;
    priceProjectionDetails?: PriceProjectionDetail[];
    currentChartPatterns?: ChartPatternInfo[];
    barPlayAnalysis?: BarPlayAnalysisInfo[];
}

export interface TradingViewWidgetConfig {
    symbol: string;
    theme?: string;
    interval?: string; 
    studies?: string[]; 
    compareSymbols?: string[]; 
    timezone?: string;
    style?: string; 
    locale?: string;
    withdateranges?: boolean;
    range?: string; 
    allow_symbol_change?: boolean;
}

export interface FMHistoricalPrice {
  date: string; // "YYYY-MM-DD" or "YYYY-MM-DD HH:MM:SS" for intraday
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export interface StockInsightModalData {
    suggestion: StoredBullishStockSuggestion | HistoricalBullishSuggestionEntry;
    isHistorical: boolean;
    deepDiveAnalysis: GeminiDeeperAnalysisResponse | null; 
    isLoadingDeepDive: boolean;
    historicalChartData?: { // Optional to store fetched FMP data
        daily?: FMHistoricalPrice[];
        intraday?: FMHistoricalPrice[];
    };
    isLoadingChartData?: boolean; // Loading state for FMP charts
}

// FMP Types
export interface FMPApiKey {
  key: string;
  lastUsed: number;
  requestsMade: number; 
}

export interface FMPProfile {
  symbol: string;
  price: number;
  beta: number;
  volAvg: number;
  mktCap: number;
  lastDiv: number;
  range: string;
  changes: number;
  companyName: string;
  currency: string;
  cik: string;
  isin: string;
  cusip: string;
  exchange: string;
  exchangeShortName: string;
  industry: string;
  website: string;
  description: string;
  ceo: string;
  sector: string;
  country: string;
  fullTimeEmployees: string;
  phone: string;
  address: string;
  city: string;
  state: string;
  zip: string;
  dcfDiff: number;
  dcf: number;
  image: string;
  ipoDate: string;
  defaultImage: boolean;
  isEtf: boolean;
  isActivelyTrading: boolean;
  isAdr: boolean;
  isFund: boolean;
}

export interface FMPQuote {
  symbol: string;
  name: string;
  price: number;
  changesPercentage: number;
  change: number;
  dayLow: number;
  dayHigh: number;
  yearHigh: number;
  yearLow: number;
  marketCap: number;
  priceAvg50: number;
  priceAvg200: number;
  exchange: string;
  volume: number;
  avgVolume: number;
  open: number;
  previousClose: number;
  eps: number;
  pe: number;
  earningsAnnouncement: string;
  sharesOutstanding: number;
  timestamp: number;
}

export interface FMPOption { 
  optionSymbol: string; 
  strike: number;
  bid: number | null;
  ask: number | null;
  lastPrice: number | null; 
  volume: number | null;
  openInterest: number | null;
  impliedVolatility: number | null;
  delta: number | null;
  gamma: number | null;
  theta: number | null;
  vega: number | null;
  expirationDate: string; 
  updated: number; 
}

export interface FMPOptionChain { 
    expirationDate: string; 
    options: FMPOption[]; 
}

export interface AIInteractionLogEntry {
    id: string; 
    timestamp: number; 
    call_type: AICallType;
    underlying_name?: string | null;
    strategy_name?: string | null;
    fmp_data_used: 0 | 1; 
    prompt_token_count?: number | null; 
    candidates_token_count?: number | null; 
    total_token_count?: number | null; 
    error_present: 0 | 1; 
    duration_ms: number;
}

// FMP Cache Types
export interface FMPCacheEntry<T> {
  id: string; // e.g., "AAPL_profile" or "MSFT_quote" or "SPY_1day_2023-01-01_2023-02-01"
  data: T;
  timestamp: number; // When the data was fetched/cached
}

export type CachedFMPProfile = FMPCacheEntry<FMPProfile>;
export type CachedFMPQuote = FMPCacheEntry<FMPQuote>;
export type FMPCacheHistoricalEntry = FMPCacheEntry<FMHistoricalPrice[]>;


// Polygon.io Types
export interface PolygonAggregate {
  v: number; // volume
  vw?: number; // volume weighted average price
  o: number; // open
  c: number; // close
  h: number; // high
  l: number; // low
  t: number; // timestamp (unix ms)
  n?: number; // number of transactions
}

export interface PolygonAggregateResponse {
  ticker?: string;
  queryCount?: number;
  resultsCount?: number;
  adjusted?: boolean;
  results?: PolygonAggregate[];
  status?: string; // e.g., "OK", "ERROR"
  request_id?: string;
  count?: number; // For /v2/aggs/grouped/locale/us/market/stocks/{date}
  error?: string; // For API-level errors directly in JSON response
}

// Type for AI-suggested historical option play
export interface HistoricalOptionLegSuggestion {
  type: OptionType;
  action: Action;
  strike: number;
  role: string;
}

export interface GeminiSuggestedHistoricalOption {
  legs?: HistoricalOptionLegSuggestion[];
  reasoningForOptionChoice?: string;
  estimatedNetCostOrCredit?: number; // e.g. -0.5 for debit, 0.3 for credit
  dataComment?: string;
  // Common Gemini response fields
  error?: string;
  sources?: GroundingSource[];
  durationMs?: number;
  fmpDataUsed?: boolean; // Will likely be false for this specific call
}


declare global {
  interface Window {
    // Potentially define CSS variables for colors if using JS to set them
    // CSS_DUKE_BLUE?: string;
    // CSS_STANFORD_RED?: string;
    // CSS_OREGON_GREEN?: string;
    // CSS_OREGON_YELLOW?: string;
    initSqlJs?: (config: any) => Promise<any>; // For sql.js CDN load
    Plotly?: any; // For Plotly.js
  }
  namespace NodeJS {
    interface ProcessEnv {
      API_KEY?: string;
      POLY_API_KEY?: string; 
    }
  }
}