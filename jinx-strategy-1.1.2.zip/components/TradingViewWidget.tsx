
import React, { useEffect, useRef, memo } from 'react';
import { TradingViewWidgetConfig } from '../types';

const DEFAULT_STUDIES = [
    "MASimple@tv-basicstudies", // Moving Average
    "MAExp@tv-basicstudies",    // Exponential Moving Average
    "RSI@tv-basicstudies",      // Relative Strength Index
    "MACD@tv-basicstudies",     // Moving Average Convergence Divergence
    "BB@tv-basicstudies",       // Bollinger Bands
    "VWAP@tv-basicstudies",     // Volume Weighted Average Price
    "IchimokuCloud@tv-basicstudies", // Ichimoku Cloud
    "ATR@tv-basicstudies",      // Average True Range
    "StochasticRSI@tv-basicstudies", // Stochastic RSI (replaced OBV as it's more common as a default study)
    "DM@tv-basicstudies"        // Directional Movement (ADX/DMI)
];

const DEFAULT_COMPARE_SYMBOLS = ["SPY", "QQQ"];

const TradingViewWidget: React.FC<TradingViewWidgetConfig> = ({
  symbol,
  theme = "light",
  interval = "D", // Default to Daily
  studies = DEFAULT_STUDIES,
  compareSymbols = DEFAULT_COMPARE_SYMBOLS,
  timezone = "America/New_York", // Common trading timezone
  style = "1", // Candles
  locale = "en",
  withdateranges = true,
  range = "6M", // Default range to 6 Months
  allow_symbol_change = true, // Allow user to change symbol in widget
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const scriptAddedRef = useRef(false);

  useEffect(() => {
    if (!containerRef.current || !symbol) return;

    // Clear previous widget if symbol or other key params change
    if (containerRef.current) {
        while (containerRef.current.firstChild) {
            containerRef.current.removeChild(containerRef.current.firstChild);
        }
    }
    scriptAddedRef.current = false;


    const widgetConfig = {
      autosize: true,
      symbol: symbol,
      interval: interval,
      timezone: timezone,
      theme: theme,
      style: style,
      locale: locale,
      toolbar_bg: "#f1f3f6",
      enable_publishing: false,
      withdateranges: withdateranges,
      range: range,
      studies: studies,
      hide_side_toolbar: false,
      allow_symbol_change: allow_symbol_change,
      // details: true, // Show details like open, high, low, close
      // hotlist: true, // Show hotlist
      // calendar: true, // Show economic calendar
      // news: true, // Show news
      // watchlist: ["NASDAQ:AAPL", "NASDAQ:TSLA"], // Example watchlist
      // no_referral_id: true, // If you have a pro account and don't want referral links
      // Hide the "Save chart" and "Load chart layout" buttons by default
      // "hide_top_toolbar": true, // Hides the entire top toolbar
      // "disabled_features": ["header_widget", "header_symbol_search", "symbol_search_hotkey"], // More granular control

      // Add comparison symbols
      // "compare_symbols": compareSymbols.map(s => ({ symbol: s, title: s })), // This is not the standard way to add comparisons via script.
                                                                              // Comparisons are usually added via UI or specific study like "Compare@tv-basicstudies"
      // For adding comparison symbols directly, they are usually part of the main `symbol` or studies array.
      // The library might handle `studies` array with comparison studies like "Compare@tv-basicstudies"
      // For simplicity, we will keep it as `compareSymbols` prop and let user add via UI if needed,
      // or pre-configure `studies` with "Compare" if that's desired and works.
      // For this iteration, we will stick to standard studies and let users add comparisons.
      // The `studies` array should contain study IDs like "Compare@tv-basicstudies" with inputs for symbols.
      // For a simple solution, we'll just list main studies.
    };

    const script = document.createElement("script");
    script.src = "https://s3.tradingview.com/external-embedding/embed-widget-advanced-chart.js";
    script.type = "text/javascript";
    script.async = true;
    script.innerHTML = JSON.stringify(widgetConfig);

    if (containerRef.current && !scriptAddedRef.current) {
      containerRef.current.appendChild(script);
      scriptAddedRef.current = true;
    }
    
    return () => {
        if (containerRef.current) {
            while (containerRef.current.firstChild) {
                containerRef.current.removeChild(containerRef.current.firstChild);
            }
        }
        scriptAddedRef.current = false;
    };
  }, [symbol, theme, interval, studies, timezone, style, locale, withdateranges, range, allow_symbol_change, compareSymbols]);

  return (
    <div className="tradingview-widget-container" ref={containerRef} style={{ height: "100%", width: "100%" }}>
      <div className="tradingview-widget-container__widget" style={{ height: "calc(100% - 32px)", width: "100%" }}></div>
       {/* TradingView might add its own copyright. If not, this is a placeholder. */}
       {/* <div className="tradingview-widget-copyright"><a href="https://www.tradingview.com/" rel="noopener nofollow" target="_blank"><span className="text-blue-500">Track all markets on TradingView</span></a></div> */}
    </div>
  );
}

export default memo(TradingViewWidget);
