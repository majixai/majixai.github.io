
import React from 'react';
import { DUKE_BLUE, PANEL_BACKGROUND, BORDER_COLOR } from '../constants'; // Adjust path as necessary

interface PanelSectionProps {
    title: string;
    isVisible: boolean;
    onToggle: () => void;
    children: React.ReactNode;
    titleIcon?: React.ReactElement;
    contentClassName?: string;
}

const PanelSection: React.FC<PanelSectionProps> = ({ 
    title, 
    isVisible, 
    onToggle, 
    children, 
    titleIcon, 
    contentClassName 
}) => (
    <div style={{backgroundColor: PANEL_BACKGROUND, borderColor: BORDER_COLOR}} className="shadow-xl rounded-xl mb-6">
      <button
        onClick={onToggle}
        style={{color: DUKE_BLUE, backgroundColor: isVisible ? '#EBF5FF' : '#F9FAFB'}} 
        className="w-full flex justify-between items-center p-4 text-left text-lg font-semibold rounded-t-xl focus:outline-none focus:ring-2 focus:ring-opacity-50"
        aria-expanded={isVisible}
        aria-controls={`panel-content-${title.replace(/\s+/g, '-')}`}
      >
        <div className="flex items-center">
            {titleIcon && React.cloneElement<{className?: string}>(titleIcon, { className: `mr-2 w-5 h-5 text-[${DUKE_BLUE}]` })}
            {title}
        </div>
        <span className={`transform transition-transform duration-300 ${isVisible ? 'rotate-180' : 'rotate-0'}`}>
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path></svg>
        </span>
      </button>
      {isVisible && (
        <div 
            id={`panel-content-${title.replace(/\s+/g, '-')}`} 
            style={{borderColor: BORDER_COLOR}} 
            className={`p-4 sm:p-5 border-t bg-white rounded-b-xl ${contentClassName || ''} transition-all duration-500 ease-in-out max-h-[1000px] opacity-100 overflow-hidden`}
        >
          {children}
        </div>
      )}
    </div>
);

export default PanelSection;
