import React, { useState, useRef, useEffect } from 'react';
import { DUKE_BLUE, PANEL_BACKGROUND, TEXT_COLOR_PRIMARY, BORDER_COLOR } from '../constants'; // Adjust path as necessary

interface ChartSettingsDropdownProps {
    showBlackScholes: boolean;
    onToggleBlackScholes: () => void;
    showTTESimulation: boolean;
    onToggleTTESimulation: () => void;
    showDataManagement: boolean;
    onToggleDataManagement: () => void;
    showDeveloperTools: boolean;
    onToggleDeveloperTools: () => void;
    showAnalyticsPanel: boolean;
    onToggleAnalyticsPanel: () => void;
    anyAppLoading: boolean;
}

const ChartSettingsDropdown: React.FC<ChartSettingsDropdownProps> = ({
    showBlackScholes, onToggleBlackScholes,
    showTTESimulation, onToggleTTESimulation,
    showDataManagement, onToggleDataManagement,
    showDeveloperTools, onToggleDeveloperTools,
    showAnalyticsPanel, onToggleAnalyticsPanel,
    anyAppLoading
}) => {
    const [isOpen, setIsOpen] = useState(false);
    const dropdownRef = useRef<HTMLDivElement>(null);

    const toggleItem = (label: string, checked: boolean, onToggle: () => void) => (
        <label htmlFor={`toggle-${label.replace(/\s+/g, '-')}`} className="flex items-center justify-between px-3 py-2 text-sm hover:bg-slate-100 cursor-pointer transition-colors">
            <span style={{ color: TEXT_COLOR_PRIMARY }}>{label}</span>
            <input
                type="checkbox"
                id={`toggle-${label.replace(/\s+/g, '-')}`}
                checked={checked}
                onChange={onToggle}
                disabled={anyAppLoading}
                className="h-4 w-4 rounded focus:ring-2"
                style={{ borderColor: BORDER_COLOR, color: DUKE_BLUE, accentColor: DUKE_BLUE }}
            />
        </label>
    );

    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
                setIsOpen(false);
            }
        };
        document.addEventListener("mousedown", handleClickOutside);
        return () => document.removeEventListener("mousedown", handleClickOutside);
    }, []);

    return (
        <div className="relative inline-block text-left w-full" ref={dropdownRef}>
            <div>
                <button
                    type="button"
                    onClick={() => setIsOpen(!isOpen)}
                    disabled={anyAppLoading}
                    className="w-full flex items-center justify-center p-2.5 rounded-lg text-sm sm:text-sm font-medium shadow-md text-white hover:opacity-90 transition-all duration-150 disabled:opacity-60"
                    style={{ backgroundColor: DUKE_BLUE }}
                    aria-haspopup="true"
                    aria-expanded={isOpen}
                >
                    Chart Settings & Advanced Panels
                    <svg className={`ml-2 h-5 w-5 transform transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                        <path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" />
                    </svg>
                </button>
            </div>

            {isOpen && (
                <div
                    className="origin-top-right absolute right-0 mt-2 w-full rounded-md shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none z-50"
                    role="menu"
                    aria-orientation="vertical"
                    aria-labelledby="menu-button"
                    style={{ backgroundColor: PANEL_BACKGROUND, borderColor: BORDER_COLOR }}
                >
                    <div className="py-1 divide-y" style={{borderColor: BORDER_COLOR}} role="none">
                        {toggleItem("Black-Scholes Calc", showBlackScholes, onToggleBlackScholes)}
                        {toggleItem("TTE Simulation Panel", showTTESimulation, onToggleTTESimulation)}
                        {toggleItem("Data Management", showDataManagement, onToggleDataManagement)}
                        {toggleItem("Analytics Panel", showAnalyticsPanel, onToggleAnalyticsPanel)}
                        {toggleItem("Developer Tools", showDeveloperTools, onToggleDeveloperTools)}
                    </div>
                </div>
            )}
        </div>
    );
};

export default ChartSettingsDropdown;
