
import React from 'react';
import { HistoricalBullishSuggestionEntry, ReasoningModalInfo, StockInsightModalData } from '../../types'; // Adjust path

interface HistoryTabContentProps {
    historicalBullishSuggestions: HistoricalBullishSuggestionEntry[] | null;
    onOpenReasoningModal: (info: ReasoningModalInfo) => void;
    onTriggerStockInsightModal: (suggestion: HistoricalBullishSuggestionEntry, isHistorical: boolean) => Promise<void>;
    isLoading: boolean; // General loading state
    currentStockForInsightModal: StockInsightModalData | null; // To show loading specific to a ticker
}

const HistoryTabContent: React.FC<HistoryTabContentProps> = ({ 
    historicalBullishSuggestions, onOpenReasoningModal, onTriggerStockInsightModal, isLoading, currentStockForInsightModal 
}) => {
    const isFetchingDeepDiveForThisTicker = (ticker: string) => 
        currentStockForInsightModal?.isLoadingDeepDive && currentStockForInsightModal.suggestion.ticker === ticker;

    if (!historicalBullishSuggestions || historicalBullishSuggestions.length === 0) {
        return <p className="p-4 text-sm text-gray-500">No historical bullish ticker suggestions found. Suggestions will appear here after using the "AI Suggest Bullish Underlyings" feature.</p>;
    }

    // Assuming historicalBullishSuggestions is sorted by timestamp descending from App.tsx
    return (
        <div className="p-4 space-y-3 max-h-96 overflow-y-auto">
             <p className="text-sm text-gray-600 mb-2">Showing {historicalBullishSuggestions.length} historical bullish suggestions. Click to re-evaluate & view detailed analysis/chart.</p>
            {historicalBullishSuggestions.map(hist => (
                <div key={hist.id} className="p-3 border border-gray-300 rounded-lg bg-gray-50 hover:bg-gray-100 transition-colors shadow-sm">
                    <div className="flex justify-between items-start mb-1">
                        <button 
                            onClick={() => onTriggerStockInsightModal(hist, true)}
                            disabled={isLoading}
                            className="font-semibold text-gray-700 hover:text-blue-600 text-md disabled:opacity-50 flex items-center"
                            title={`Re-evaluate ${hist.ticker} from ${new Date(hist.initialTimestamp).toLocaleDateString()}`}
                        >
                            {hist.ticker} ({hist.priceAtSuggestion?.toFixed(2) || 'N/A'})
                            {isFetchingDeepDiveForThisTicker(hist.ticker) && <span className="animate-spin rounded-full h-3 w-3 border-b-2 border-current inline-block ml-1.5"></span>}
                        </button>
                        <span className="text-xs text-gray-500">{new Date(hist.initialTimestamp).toLocaleString()}</span>
                    </div>
                    <p className="text-xs text-green-600">
                        Initial Proj: +{hist.projectedPriceChangePercentMin ?? 'N/A'}% to +{hist.projectedPriceChangePercentMax ?? 'N/A'}%
                        {hist.projectedTimeline && ` (⏳ ${hist.projectedTimeline})`}
                    </p>
                    {hist.reasoning && (
                         <button
                            onClick={() => onOpenReasoningModal({title: `Historical Insight: ${hist.ticker} (${new Date(hist.initialTimestamp).toLocaleDateString()})`, reasoning: hist.reasoning!})}
                            className="text-xs text-gray-500 hover:underline mt-0.5"
                        >Read Initial Reasoning...
                        </button>
                    )}
                </div>
            ))}
        </div>
    );
};

export default HistoryTabContent;
