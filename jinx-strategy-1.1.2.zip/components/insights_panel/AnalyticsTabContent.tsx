
import React from 'react';
import { ClipboardIcon } from '../../constants'; // Adjust path as necessary

interface AnalyticsTabContentProps {
    allLoggedErrors: string[];
    onCopyErrorsToClipboard: () => Promise<void>;
    anyAppLoading: boolean; // To disable copy button during other operations
}

const AnalyticsTabContent: React.FC<AnalyticsTabContentProps> = ({ 
    allLoggedErrors, 
    onCopyErrorsToClipboard,
    anyAppLoading
}) => {
    return (
        <div className="p-4 space-y-4 max-h-96 overflow-y-auto">
            <div>
                <h3 className="text-md font-semibold text-slate-700 mb-2">Application Error Log ({allLoggedErrors.length})</h3>
                {allLoggedErrors.length > 0 ? (
                    <>
                        <div className="max-h-60 overflow-y-auto bg-red-50 border border-red-200 p-3 rounded-md text-xs text-red-800 mb-2 shadow-sm">
                            {allLoggedErrors.map((err, idx) => (
                                <p key={idx} className="mb-1 pb-1 border-b border-red-100 last:border-b-0 last:pb-0 last:mb-0 break-words">
                                    {err}
                                </p>
                            ))}
                        </div>
                        <button 
                            onClick={onCopyErrorsToClipboard} 
                            disabled={anyAppLoading}
                            className="flex items-center bg-yellow-500 hover:bg-yellow-600 text-white text-sm font-medium py-1.5 px-3 rounded-md shadow-sm disabled:opacity-50 transition-colors"
                        >
                            <ClipboardIcon className="mr-1.5" /> Copy All Errors to Clipboard
                        </button>
                    </>
                ) : (
                    <p className="text-sm text-gray-500">No errors logged yet. Great!</p>
                )}
            </div>

            {/* Placeholder for future analytics like user flow - not implemented yet */}
            {/* 
            <div>
                <h3 className="text-md font-semibold text-slate-700 mb-2">User Flow Analytics (Placeholder)</h3>
                <p className="text-sm text-gray-500">User action tracking and flow visualization would appear here.</p>
            </div>
            */}
        </div>
    );
};

export default AnalyticsTabContent;
