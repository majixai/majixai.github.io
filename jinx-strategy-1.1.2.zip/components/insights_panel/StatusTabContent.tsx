
import React from 'react';
import { GeneralStatusMessage } from '../../types'; // Adjust path as necessary

interface StatusTabContentProps {
    generalStatusMessage: GeneralStatusMessage | null;
    onCloseGeneralStatus: () => void;
    isLoading: boolean; // To show loading spinner with info messages
}

const StatusTabContent: React.FC<StatusTabContentProps> = ({ generalStatusMessage, onCloseGeneralStatus, isLoading }) => {
    if (!generalStatusMessage) {
        return <p className="p-4 text-sm text-gray-500">No current status messages.</p>;
    }

    return (
        <div className={`p-3 text-sm opacity-100 translate-y-0
            ${generalStatusMessage.type === 'success' ? 'bg-green-100 border-green-300 text-green-700' : ''}
            ${generalStatusMessage.type === 'info' ? 'bg-blue-100 border-blue-300 text-blue-700' : ''}
            ${generalStatusMessage.type === 'warning' ? 'bg-yellow-100 border-yellow-300 text-yellow-700' : ''}
            ${generalStatusMessage.type === 'error' ? 'bg-red-100 border-red-300 text-red-700' : ''}
            border rounded-b-md`} role="alert"
        >
            <div className="flex items-start">
                <span className={`flex-grow whitespace-pre-wrap`}>{generalStatusMessage.text}</span>
                {isLoading && generalStatusMessage.type === 'info' && (
                    <span className="animate-spin rounded-full h-4 w-4 border-b-2 border-current inline-block ml-2 flex-shrink-0"></span>
                )}
                <button 
                    onClick={onCloseGeneralStatus} 
                    className="ml-3 font-bold hover:text-opacity-70 transition-opacity flex-shrink-0" 
                    aria-label="Close status message"
                >
                    X
                </button>
            </div>
        </div>
    );
};

export default StatusTabContent;
