
import React from 'react';
import { StoredBullishStockSuggestion, ReasoningModalInfo, StockInsightModalData, OutlookHorizon } from '../../types'; // Adjust path
import { BrainIcon } from '../../constants'; // Adjust path

interface TickersTabContentProps {
    bullishStockInsights: StoredBullishStockSuggestion[] | null;
    onOpenReasoningModal: (info: ReasoningModalInfo) => void;
    onTriggerStockInsightModal: (suggestion: StoredBullishStockSuggestion, isHistorical: boolean) => Promise<void>;
    isLoading: boolean; // General loading state for disabling buttons
    currentStockForInsightModal: StockInsightModalData | null; // To show loading specific to a ticker
}

const TickersTabContent: React.FC<TickersTabContentProps> = ({ 
    bullishStockInsights, onOpenReasoningModal, onTriggerStockInsightModal, isLoading, currentStockForInsightModal 
}) => {
    const isFetchingDeepDiveForThisTicker = (ticker: string) => 
        currentStockForInsightModal?.isLoadingDeepDive && currentStockForInsightModal.suggestion.ticker === ticker;

    if (!bullishStockInsights || bullishStockInsights.length === 0) {
        return <p className="p-4 text-sm text-gray-500">No bullish ticker insights available. Use "AI Suggest Bullish Underlyings" to populate.</p>;
    }

    return (
        <div className="p-4 space-y-3 max-h-96 overflow-y-auto">
            {bullishStockInsights.map(stock => {
                const isShortTermStock = stock.outlookHorizon === OutlookHorizon.ShortTerm;
                 return (
                    <div key={stock.id} className={`p-3 border ${isShortTermStock ? 'border-orange-300 bg-orange-50/80' : 'border-sky-200 bg-sky-50/70'} rounded-lg shadow-sm`}>
                        <div className="flex justify-between items-start mb-1">
                             <button 
                                onClick={() => onTriggerStockInsightModal(stock, false)}
                                disabled={isLoading}
                                className={`font-semibold ${isShortTermStock ? 'text-orange-700 hover:text-orange-600' : 'text-sky-700 hover:text-sky-600'} text-md disabled:opacity-50 flex items-center`}
                                title={`View Detailed Analysis & Chart for ${stock.ticker}`}
                            >
                                {isShortTermStock && <BrainIcon className="w-4 h-4 mr-1.5 text-orange-600"/>}
                                {stock.ticker} ({stock.currentPrice?.toFixed(2) || 'N/A'})
                                {isShortTermStock && <span className="text-orange-500 ml-1">⚡️</span>}
                                {isFetchingDeepDiveForThisTicker(stock.ticker) && <span className="animate-spin rounded-full h-3 w-3 border-b-2 border-current inline-block ml-1.5"></span>}
                            </button>
                            <span className={`text-xs ${isShortTermStock ? 'text-orange-500' : 'text-sky-500'}`}>{stock.priceCategory}, {stock.outlookHorizon}</span>
                        </div>
                         {isFetchingDeepDiveForThisTicker(stock.ticker) && (
                            <div className="text-xs text-sky-600 flex items-center my-1">
                                <span className="animate-spin rounded-full h-3 w-3 border-b-2 border-sky-600 mr-1.5"></span>
                                Performing deeper analysis...
                            </div>
                        )}
                        
                        {/* Always show initial projection if available */}
                        {(stock.projectedPriceChangePercentMin !== null && stock.projectedPriceChangePercentMin !== undefined) || (stock.projectedPriceChangePercentMax !== null && stock.projectedPriceChangePercentMax !== undefined) ? (
                            <p className={`text-xs mt-0.5 ${isShortTermStock ? 'text-green-700 font-medium' : 'text-green-600'}`}>
                                Initial Projection: 📈 +{stock.projectedPriceChangePercentMin ?? '?'}% to +{stock.projectedPriceChangePercentMax ?? '?'}%
                            </p>
                        ) : null}
                        {stock.projectedTimeline && (
                             <p className={`text-xs mt-0.5 ${isShortTermStock ? 'text-green-700 font-medium' : 'text-green-600'}`}>
                                ⏳ {stock.projectedTimeline}
                            </p>
                        )}

                        {stock.reasoning && (!stock.detailedReasoning || stock.reasoning !== stock.detailedReasoning) && (
                            <div className="mt-1">
                                <button onClick={() => onOpenReasoningModal({title: `Initial Insight: ${stock.ticker}`, reasoning: stock.reasoning!})}
                                        className={`text-xs ${isShortTermStock ? 'text-orange-500 hover:underline' : 'text-sky-500 hover:underline'}`}>Read Initial Insight...
                                </button>
                            </div>
                        )}
                    </div>
                );
            })}
        </div>
    );
};

export default TickersTabContent;
