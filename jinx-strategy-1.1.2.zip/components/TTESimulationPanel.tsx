
import React from 'react';
import { PlotOptions } from '../types';
import { ClearIcon } from '../constants';
import { InputField } from './SharedControls';

interface TTESimulationPanelProps {
    plotOptions: PlotOptions;
    currentSimulatedTTEDays: number;
    simulationSigmaInput: string;
    simulationRInput: string;
    isTTESimulationActive: boolean;
    onToggleTTESimulation: () => void;
    onSet0DTESimulation: () => void; // New prop for 0 DTE
    onResetTTESimulation: () => void;
    onCurrentSimulatedTTEDaysChange: (days: number) => void;
    onSimulationSigmaInputChange: (value: string) => void;
    onSimulationRInputChange: (value: string) => void;
    anyAppLoading: boolean;
}

const TTESimulationPanel: React.FC<TTESimulationPanelProps> = ({
    plotOptions, currentSimulatedTTEDays, simulationSigmaInput, simulationRInput,
    isTTESimulationActive, onToggleTTESimulation, onSet0DTESimulation, onResetTTESimulation,
    onCurrentSimulatedTTEDaysChange, onSimulationSigmaInputChange, onSimulationRInputChange,
    anyAppLoading
}) => {
    return (
        <>
            <p className="text-xs text-gray-500 mb-3">Simulate option premiums and P/L at a future Time To Expiration (TTE). Uses Black-Scholes for premium calculation. <strong className="text-red-600">Requires a valid Current Stock Price in main config.</strong></p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-3">
                <div>
                    <label htmlFor="tteDaysSim" className="block text-xs font-medium text-[#555555] mb-1">Simulate at TTE (Days): {currentSimulatedTTEDays} days</label>
                    <input type="range" id="tteDaysSim" name="tteDaysSim"
                        min="0" max={plotOptions.initialTTEForSimulation ? Math.max(30, Math.round(plotOptions.initialTTEForSimulation * 365 * 1.2)) : 90}
                        value={currentSimulatedTTEDays}
                        onChange={e => onCurrentSimulatedTTEDaysChange(parseInt(e.target.value, 10))}
                        className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-[#00539B]"
                        disabled={anyAppLoading || !plotOptions.currentS}
                    />
                </div>
                <InputField label="Sim Volatility (σ, decimal)" id="simulationSigma" type="number" step="0.001" value={simulationSigmaInput} onChange={e => onSimulationSigmaInputChange(e.target.value)} placeholder="e.g., 0.20" disabled={anyAppLoading || !plotOptions.currentS} />
                <InputField label="Sim Risk-Free Rate (r, decimal)" id="simulationR" type="number" step="0.001" value={simulationRInput} onChange={e => onSimulationRInputChange(e.target.value)} placeholder="e.g., 0.05" disabled={anyAppLoading || !plotOptions.currentS} />
                 <button 
                    onClick={onSet0DTESimulation}
                    disabled={anyAppLoading || !plotOptions.currentS || parseFloat(plotOptions.currentS) <= 0}
                    className="sm:col-span-2 flex items-center justify-center bg-orange-500 hover:bg-orange-600 text-white text-sm font-medium py-2 px-3 rounded-md shadow-sm disabled:opacity-50 transition-all"
                >
                    Set 0 DTE Simulation
                </button>
            </div>
            <div className="mt-4 flex space-x-2">
                <button onClick={onToggleTTESimulation}
                    disabled={anyAppLoading || !plotOptions.currentS || parseFloat(plotOptions.currentS) <= 0}
                    className={`flex-1 flex items-center justify-center text-sm font-medium py-2 px-3 rounded-md shadow-sm transition-all ${isTTESimulationActive
                            ? 'bg-red-600 hover:bg-red-700 text-white'
                            : 'bg-green-600 hover:bg-green-700 text-white disabled:opacity-50'
                        }`}
                >
                    {isTTESimulationActive ? 'Deactivate Simulation' : 'Activate & Apply Simulation'}
                </button>
                <button onClick={onResetTTESimulation}
                    disabled={anyAppLoading || !plotOptions.currentS}
                    className="flex-shrink-0 flex items-center justify-center bg-gray-200 hover:bg-gray-300 text-gray-700 text-sm font-medium py-2 px-3 rounded-md shadow-sm disabled:opacity-50 transition-all"
                >
                    <ClearIcon /> Reset Sim
                </button>
            </div>
            {isTTESimulationActive && plotOptions.currentS && parseFloat(plotOptions.currentS) > 0 && (
                <p className="text-xs text-green-700 mt-2 italic">Simulation is active. Premiums on legs and plot are simulated values for {currentSimulatedTTEDays} days TTE.</p>
            )}
            {!plotOptions.currentS && (
                <p className="text-xs text-red-600 mt-2 italic">Current Stock Price is required to use TTE Simulation.</p>
            )}
        </>
    );
};

export default TTESimulationPanel;
