
import React from 'react';
import { GroundingSource, AppDBState } from '../types';
// import { ClipboardIcon } from '../constants'; // No longer needed here

interface DeveloperToolsPanelProps {
    showAIDataProvenance: boolean;
    onToggleAIDataProvenance: (checked: boolean) => void;
    allAccumulatedAISources: GroundingSource[];
    aiCallDurations: AppDBState['aiCallDurations'];
    // allLoggedErrors: string[]; // Moved
    // onCopyErrorsToClipboard: () => Promise<void>; // Moved
    anyAppLoading: boolean;
}

const DeveloperToolsPanel: React.FC<DeveloperToolsPanelProps> = ({
    showAIDataProvenance, onToggleAIDataProvenance, allAccumulatedAISources,
    aiCallDurations, anyAppLoading
    // allLoggedErrors, onCopyErrorsToClipboard, // Moved
}) => {
    return (
        <>
            <h3 className="text-lg font-semibold text-[#00407A] mb-3">Developer Information</h3>

            <div className="flex items-center mb-3">
                <input type="checkbox" id="showAIDataProvenance" checked={showAIDataProvenance} onChange={e => onToggleAIDataProvenance(e.target.checked)} className="h-4 w-4 text-[#00539B] border-[#D1D5DB] rounded focus:ring-[#00539B]" disabled={anyAppLoading} />
                <label htmlFor="showAIDataProvenance" className="ml-2 block text-sm text-[#333333]">Show AI Data Provenance (Accumulated Sources)</label>
            </div>

            {showAIDataProvenance && (
                <>
                    <h4 className="text-md font-semibold text-[#00539B] mt-4 mb-2">All Accumulated AI Sources ({allAccumulatedAISources.length})</h4>
                    {allAccumulatedAISources.length > 0 ? (
                        <div className="max-h-48 overflow-y-auto bg-blue-50 border border-blue-200 p-2 rounded text-xs text-blue-800">
                            {allAccumulatedAISources.map((source, idx) => (
                                <p key={idx} className="truncate">
                                    <a href={source.uri} target="_blank" rel="noopener noreferrer" title={source.title} className="hover:underline">
                                        {idx + 1}. {source.title || new URL(source.uri).hostname}
                                    </a>
                                </p>
                            ))}
                        </div>
                    ) : <p className="text-xs text-gray-500">No AI sources accumulated yet.</p>}
                </>
            )}

            <h4 className="text-md font-semibold text-[#00539B] mt-4 mb-2">AI Call Durations (ms)</h4>
            {aiCallDurations && Object.keys(aiCallDurations).length > 0 ? (
                <pre className="text-xs bg-gray-100 p-2 rounded max-h-32 overflow-y-auto">
                    {JSON.stringify(aiCallDurations, null, 2)}
                </pre>
            ) : <p className="text-xs text-gray-500">No AI call durations recorded yet.</p>}
        </>
    );
};

export default DeveloperToolsPanel;
