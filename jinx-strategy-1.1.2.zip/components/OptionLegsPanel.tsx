
import React from 'react';
import { OptionLeg, OptionType, Action, OptionsChainData, ModalPrimingLegInfo } from '../types';
import { MAX_LEGS, PlusIcon, TrashIcon, WalletIcon } from '../constants';
import { InputField, SelectField } from './SharedControls';

interface OptionLegsPanelProps {
    legs: OptionLeg[];
    onLegChange: (id: string, field: keyof OptionLeg, value: string | OptionType | Action) => void;
    onAddLeg: () => void;
    onRemoveLeg: (id: string) => void;
    onOpenChainForLeg: (legId: string, currentStrike: string, optionType: OptionType) => void;
    optionsChainForModal: OptionsChainData | null;
    anyAppLoading: boolean;
}

const OptionLegsPanel: React.FC<OptionLegsPanelProps> = ({
    legs, onLegChange, onAddLeg, onRemoveLeg, onOpenChainForLeg, optionsChainForModal, anyAppLoading
}) => {
    return (
        <>
            <div className="flex justify-between items-center mb-4 border-b pb-2 border-[#D1D5DB]">
                <h3 className="text-xl font-semibold text-[#00407A]">Define Legs</h3>
                <button onClick={onAddLeg} disabled={legs.length >= MAX_LEGS || anyAppLoading}
                    className="flex items-center bg-[#00539B] hover:bg-[#00407A] text-white text-sm font-medium py-2 px-3 rounded-md shadow-sm disabled:opacity-50 transition-all">
                    <PlusIcon /> Add Leg
                </button>
            </div>
            <div className="space-y-4 max-h-96 overflow-y-auto pr-2">
                {legs.map((leg, index) => (
                    <div key={leg.id} className="p-3 border border-[#E5E7EB] rounded-lg bg-slate-50/70 shadow-sm">
                        <div className="flex justify-between items-center mb-2">
                            <h3 className="text-sm font-semibold text-[#00539B]">Leg {index + 1} <span className="text-xs text-gray-500 font-normal">({leg.role || 'N/A'})</span></h3>
                            <button onClick={() => onRemoveLeg(leg.id)} disabled={anyAppLoading}
                                className="text-red-500 hover:text-red-700 disabled:opacity-50 transition-colors p-1 rounded-full hover:bg-red-100">
                                <TrashIcon />
                            </button>
                        </div>
                        <div className="grid grid-cols-2 sm:grid-cols-3 gap-x-3 gap-y-1">
                            <SelectField label="Type" id={`type-${leg.id}`} value={leg.type} onChange={e => onLegChange(leg.id, 'type', e.target.value as OptionType)} options={[{ value: OptionType.Call, label: 'Call' }, { value: OptionType.Put, label: 'Put' }]} disabled={anyAppLoading} />
                            <SelectField label="Action" id={`action-${leg.id}`} value={leg.action} onChange={e => onLegChange(leg.id, 'action', e.target.value as Action)} options={[{ value: Action.Buy, label: 'Buy' }, { value: Action.Sell, label: 'Sell' }]} disabled={anyAppLoading} />
                            <InputField label="Strike" id={`strike-${leg.id}`} type="number" value={leg.strike} onChange={e => onLegChange(leg.id, 'strike', e.target.value)} placeholder="e.g., 100" step="0.01" disabled={anyAppLoading} required />
                            <InputField label="Premium" id={`premium-${leg.id}`} type="number" value={leg.premium} onChange={e => onLegChange(leg.id, 'premium', e.target.value)} placeholder="e.g., 1.50" step="0.01" disabled={anyAppLoading} required />
                            <InputField label="Qty" id={`quantity-${leg.id}`} type="number" value={leg.quantity} onChange={e => onLegChange(leg.id, 'quantity', e.target.value)} placeholder="e.g., 1" min="1" disabled={anyAppLoading} required />
                            {optionsChainForModal && leg.strike && (
                                <button onClick={() => onOpenChainForLeg(leg.id, leg.strike, leg.type)}
                                    disabled={anyAppLoading}
                                    title={`Set Premium for K:${leg.strike} ${leg.type} from Chain`}
                                    className="mt-4 col-span-2 sm:col-span-1 flex items-center justify-center text-xs bg-sky-100 hover:bg-sky-200 text-sky-700 font-medium py-1.5 px-2 rounded-md border border-sky-300 shadow-sm disabled:opacity-50 transition-all"
                                >
                                    <WalletIcon className="mr-1" /> Set from Chain
                                </button>
                            )}
                        </div>
                        {leg.premiumMissing && leg.strike && <p className="text-xs text-orange-600 mt-1 italic">Premium needed for K:{leg.strike} {leg.type}.</p>}
                    </div>
                ))}
            </div>
        </>
    );
};

export default OptionLegsPanel;
