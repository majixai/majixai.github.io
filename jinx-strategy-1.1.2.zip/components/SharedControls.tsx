
import React from 'react';
import { TEXT_COLOR_SECONDARY, BORDER_COLOR, DUKE_BLUE, PANEL_BACKGROUND, TEXT_COLOR_PRIMARY } from '../constants';

// Helper Component: InputField
export const InputField: React.FC<{
  label: string;
  id: string;
  type?: string;
  value: string;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  placeholder?: string;
  step?: string;
  min?: string;
  max?: string;
  className?: string;
  disabled?: boolean;
  required?: boolean;
  list?: string; 
}> = ({ label, id, type = "text", value, onChange, placeholder, step, min, max, className = "", disabled = false, required = false, list }) => (
  <div className={`mb-3 ${className}`}>
    <label htmlFor={id} className="block text-xs font-medium mb-1" style={{color: TEXT_COLOR_SECONDARY}}>{label}{required && <span className="text-red-500">*</span>}</label>
    <input
      type={type}
      id={id}
      name={id}
      value={value}
      onChange={onChange}
      placeholder={placeholder}
      step={step}
      min={min}
      max={max}
      disabled={disabled}
      required={required}
      list={list}
      className="w-full p-2.5 border rounded-md shadow-sm text-sm focus:ring-2 focus:ring-opacity-50 disabled:bg-slate-100 disabled:text-slate-500 disabled:cursor-not-allowed"
      style={{
        borderColor: BORDER_COLOR,
        color: disabled ? TEXT_COLOR_SECONDARY : TEXT_COLOR_PRIMARY,
        backgroundColor: disabled ? '#F1F5F9' : PANEL_BACKGROUND, // Tailwind slate-100
        outlineColor: DUKE_BLUE, 
      }}
      autoComplete={list ? "off" : "on"} // Turn off browser autocomplete if using datalist
    />
  </div>
);

// Helper Component: SelectField
export const SelectField: React.FC<{
  label: string;
  id: string;
  value: string;
  onChange: (e: React.ChangeEvent<HTMLSelectElement>) => void;
  options: { value: string; label: string }[];
  className?: string;
  disabled?: boolean;
}> = ({ label, id, value, onChange, options, className = "", disabled = false }) => (
  <div className={`mb-3 ${className}`}>
    <label htmlFor={id} className="block text-xs font-medium mb-1" style={{color: TEXT_COLOR_SECONDARY}}>{label}</label>
    <select
      id={id}
      name={id}
      value={value}
      onChange={onChange}
      disabled={disabled}
      className="w-full p-2.5 border rounded-md shadow-sm text-sm focus:ring-2 focus:ring-opacity-50 disabled:bg-slate-100 disabled:text-slate-500 disabled:cursor-not-allowed"
      style={{
        borderColor: BORDER_COLOR,
        color: disabled ? TEXT_COLOR_SECONDARY : TEXT_COLOR_PRIMARY,
        backgroundColor: disabled ? '#F1F5F9' : PANEL_BACKGROUND, // Tailwind slate-100
        outlineColor: DUKE_BLUE,
      }}
    >
      {options.map(opt => <option key={opt.value} value={opt.value}>{opt.label}</option>)}
    </select>
  </div>
);
