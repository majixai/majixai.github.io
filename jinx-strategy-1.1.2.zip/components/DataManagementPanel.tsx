
import React from 'react';
import { GitHubExportSettings } from '../types';
import { ClearIcon, ExportIcon, DatabaseIcon } from '../constants';
import { InputField } from './SharedControls';

interface DataManagementPanelProps {
    githubSettings: GitHubExportSettings;
    onGitHubSettingsChange: (field: keyof GitHubExportSettings, value: string) => void;
    onExportData: () => Promise<void>;
    onClearForm: () => void;
    anyAppLoading: boolean;
    isExporting: boolean;
}

const DataManagementPanel: React.FC<DataManagementPanelProps> = ({
    githubSettings, onGitHubSettingsChange, onExportData, onClearForm, anyAppLoading, isExporting
}) => {
    return (
        <>
            <h3 className="text-lg font-semibold text-[#00407A] mb-3">Data Management</h3>
            <button onClick={onClearForm} disabled={anyAppLoading}
                className="w-full flex items-center justify-center bg-red-500 hover:bg-red-600 text-white text-sm font-medium py-2 px-3 rounded-md shadow-sm disabled:opacity-50 transition-all mb-6">
                <ClearIcon /> Clear All Data & Reset Form
            </button>

            <div className="mt-4">
                <h4 className="text-md font-semibold text-[#00539B] mb-2">GitHub Export Settings (Simulated)</h4>
                <InputField label="Personal Access Token (PAT)" id="githubPat" type="password" value={githubSettings.pat} onChange={e => onGitHubSettingsChange('pat', e.target.value)} placeholder="ghp_YourTokenHere" disabled={anyAppLoading || isExporting} />
                <InputField label="GitHub Username" id="githubUsername" value={githubSettings.username} onChange={e => onGitHubSettingsChange('username', e.target.value)} placeholder="your-github-username" disabled={anyAppLoading || isExporting} />
                <InputField label="Repository Name" id="githubRepoName" value={githubSettings.repoName} onChange={e => onGitHubSettingsChange('repoName', e.target.value)} placeholder="your-repo-name" disabled={anyAppLoading || isExporting} />
                <InputField label="File Path in Repo" id="githubFilePath" value={githubSettings.filePath} onChange={e => onGitHubSettingsChange('filePath', e.target.value)} placeholder="path/to/your/config.json" disabled={anyAppLoading || isExporting} />
                <button onClick={onExportData} disabled={anyAppLoading || isExporting || !githubSettings.pat || !githubSettings.username || !githubSettings.repoName}
                    className="mt-3 w-full flex items-center justify-center bg-gray-600 hover:bg-gray-700 text-white text-sm font-medium py-2 px-3 rounded-md shadow-sm disabled:opacity-50 transition-all">
                    {isExporting ? <span className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></span> : <ExportIcon />}
                    {isExporting ? 'Exporting...' : 'Export Data to GitHub (Simulated)'}
                </button>
            </div>
        </>
    );
};

export default DataManagementPanel;
