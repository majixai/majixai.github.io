
import React, { useEffect, useState, useCallback } from 'react';
import { StockInsightModalData, PriceProjectionDetail, OutlookHorizon, StoredBullishStockSuggestion, HistoricalBullishSuggestionEntry, ChartPatternInfo, BarPlayAnalysisInfo, FMHistoricalPrice, GeminiSuggestedHistoricalOption, ChartData, OptionLeg, Action, OptionType, PlotOptions } from '../types';
import TradingViewWidget from './TradingViewWidget'; 
import FMPPlotlyChart from './FMPPlotlyChart'; // Import the new chart component
import PayoffChart from './PayoffChart'; // For historical option payoff
import { generatePlotData } from '../services/optionCalculationService'; // For historical option payoff
import { getHistoricalCandlesFMP } from '../services/fmpService'; // Import FMP service
import { fetchAISuggestedHistoricalOption } from '../services/geminiService';
import { generateMarkdownFromInsightData, generatePdfFromInsightData } from '../utils/exportUtils'; // Import export utils
import { isValidTicker } from '../utils/validationUtils'; // Import ticker validation
import { BrainIcon, MessageIcon, STANFORD_CARDINAL_RED, DUKE_BLUE, OREGON_GREEN, OREGON_YELLOW, TEXT_COLOR_PRIMARY, TEXT_COLOR_SECONDARY, BORDER_COLOR, DownloadIcon, PANEL_BACKGROUND, LoadingSpinner } from '../constants';
import { formatDate, formatPrice, generateUniqueId } from '../../utils/miscUtils'; // Import utility functions

interface StockInsightModalProps {
  isOpen: boolean;
  onClose: () => void;
  modalData: StockInsightModalData | null;
  onSetHistoricalContextForStrategy?: (historicalSuggestion: HistoricalBullishSuggestionEntry, historicalOptionPlay: GeminiSuggestedHistoricalOption | null) => void;
}

const StockInsightModal: React.FC<StockInsightModalProps> = ({ isOpen, onClose, modalData, onSetHistoricalContextForStrategy }) => {
  const [fmpChartData, setFmpChartData] = useState<{ daily?: FMHistoricalPrice[], intraday?: FMHistoricalPrice[] }>({});
  const [isLoadingFMPCharts, setIsLoadingFMPCharts] = useState(false);
  const [chartError, setChartError] = useState<string | null>(null);
  
  const [suggestedHistoricalOptionData, setSuggestedHistoricalOptionData] = useState<GeminiSuggestedHistoricalOption | null>(null);
  const [isLoadingSuggestedHistoricalOptionData, setIsLoadingSuggestedHistoricalOptionData] = useState(false);
  const [historicalOptionStrategyChartData, setHistoricalOptionStrategyChartData] = useState<ChartData | null>(null);
  const [isHistoricalOptionChartVisible, setIsHistoricalOptionChartVisible] = useState(false);


  const fetchAllModalData = useCallback(async (currentModalData: StockInsightModalData) => {
    if (!currentModalData || !currentModalData.suggestion) return;
    
    const ticker = currentModalData.suggestion.ticker;
    if (!isValidTicker(ticker)) {
        console.error(`StockInsightModal: Invalid ticker "${ticker}" provided.`);
        setChartError(`Invalid ticker symbol: ${ticker}. Cannot load charts or suggestions.`);
        setIsLoadingFMPCharts(false);
        setIsLoadingSuggestedHistoricalOptionData(false);
        setFmpChartData({});
        setSuggestedHistoricalOptionData(null);
        setHistoricalOptionStrategyChartData(null);
        return;
    }

    setIsLoadingFMPCharts(true);
    setIsLoadingSuggestedHistoricalOptionData(currentModalData.isHistorical);
    setFmpChartData({}); 
    setSuggestedHistoricalOptionData(null);
    setHistoricalOptionStrategyChartData(null);
    setChartError(null);

    const { suggestion, isHistorical } = currentModalData;
    const analysisOrSuggestionDate = suggestion.analysisTimestamp || (suggestion as HistoricalBullishSuggestionEntry).initialTimestamp || Date.now();
    
    const toDate = new Date(analysisOrSuggestionDate);
    const fromDateDaily = new Date(toDate);
    fromDateDaily.setMonth(fromDateDaily.getMonth() - 6); 

    const dailyDataPromise = getHistoricalCandlesFMP(
        ticker, 
        fromDateDaily.toISOString().split('T')[0], 
        toDate.toISOString().split('T')[0], 
        '1day'
    );

    let intradayDataPromise: Promise<FMHistoricalPrice[] | null> = Promise.resolve(null);
    if (suggestion.outlookHorizon === OutlookHorizon.ShortTerm || (currentModalData.deepDiveAnalysis?.barPlayAnalysis && currentModalData.deepDiveAnalysis.barPlayAnalysis.length > 0)) {
        const fromDateIntraday = new Date(toDate);
        fromDateIntraday.setDate(fromDateIntraday.getDate() - (suggestion.outlookHorizon === OutlookHorizon.ShortTerm ? 2 : 1)); 
        
        if (isHistorical || suggestion.outlookHorizon === OutlookHorizon.ShortTerm) {
             await new Promise(resolve => setTimeout(resolve, 4000)); // Increased delay: Stagger intraday call
        }

        intradayDataPromise = getHistoricalCandlesFMP(
            ticker,
            fromDateIntraday.toISOString().split('T')[0],
            toDate.toISOString().split('T')[0],
            '5min' 
        );
    }

    let historicalOptionPromise: Promise<GeminiSuggestedHistoricalOption | null> = Promise.resolve(null);
    if (isHistorical && suggestion) {
        const histSuggestion = suggestion as HistoricalBullishSuggestionEntry;
        if (histSuggestion.priceAtSuggestion && histSuggestion.reasoning) {
            historicalOptionPromise = fetchAISuggestedHistoricalOption(
                histSuggestion.ticker,
                histSuggestion.priceAtSuggestion,
                histSuggestion.reasoning,
                new Date(histSuggestion.initialTimestamp).toISOString()
            );
        }
    }
    
    try {
        const [dailyResult, intradayResult, historicalOptionResult] = await Promise.all([dailyDataPromise, intradayDataPromise, historicalOptionPromise]);
        
        if (dailyResult === null && intradayResult === null) {
             setChartError(`Failed to load historical chart data for ${ticker}. API limit may be reached or data unavailable.`);
        }
        setFmpChartData({ daily: dailyResult || undefined, intraday: intradayResult || undefined });

        if (isHistorical) {
            if (historicalOptionResult && !historicalOptionResult.error) {
                setSuggestedHistoricalOptionData(historicalOptionResult);
                if (historicalOptionResult.legs && historicalOptionResult.legs.length > 0) {
                    const histSugg = suggestion as HistoricalBullishSuggestionEntry;
                    const tempLegs: OptionLeg[] = historicalOptionResult.legs.map(aiLeg => {
                        let premiumValue = "0.00";
                        let premiumIsMissing = true;
                         // Use estimatedNetCostOrCredit if it's a single leg strategy.
                        if (historicalOptionResult.legs!.length === 1 && historicalOptionResult.estimatedNetCostOrCredit !== undefined && historicalOptionResult.estimatedNetCostOrCredit !== null) {
                            if (aiLeg.action === Action.Buy && historicalOptionResult.estimatedNetCostOrCredit < 0) {
                                premiumValue = Math.abs(historicalOptionResult.estimatedNetCostOrCredit).toFixed(2);
                                premiumIsMissing = false;
                            } else if (aiLeg.action === Action.Sell && historicalOptionResult.estimatedNetCostOrCredit > 0) {
                                premiumValue = historicalOptionResult.estimatedNetCostOrCredit.toFixed(2);
                                premiumIsMissing = false;
                            } else if (historicalOptionResult.estimatedNetCostOrCredit === 0) {
                                premiumValue = "0.00";
                                premiumIsMissing = false;
                            } else { // Default for ambiguity
                                premiumValue = aiLeg.action === Action.Buy ? "0.01" : "0.00";
                                premiumIsMissing = true;
                            }
                        } else { // Multi-leg or no estimatedNetCostOrCredit
                             premiumValue = aiLeg.action === Action.Buy ? "0.01" : "0.00"; // Placeholder
                             premiumIsMissing = true;
                        }
                        return {
                            id: generateUniqueId(),
                            type: aiLeg.type,
                            action: aiLeg.action,
                            strike: aiLeg.strike.toString(),
                            premium: premiumValue,
                            quantity: "1",
                            role: aiLeg.role || `Hist Leg ${aiLeg.strike}`,
                            premiumMissing: premiumIsMissing
                        };
                    });
                    
                    const tempPlotOptions: PlotOptions = {
                        id: 'historical-modal-plot',
                        underlyingName: histSugg.ticker,
                        currentS: histSugg.priceAtSuggestion?.toString() || '',
                        pointValue: '100', numPoints: '100', minST: '', maxST: '',
                        showIndividualLegs: false // Keep simple for modal
                    };
                    const payoffResult = generatePlotData(tempLegs, tempPlotOptions);
                    if ('error' in payoffResult) {
                        console.warn("Error generating historical option payoff chart:", payoffResult.error);
                        setHistoricalOptionStrategyChartData(null);
                    } else {
                        setHistoricalOptionStrategyChartData(payoffResult);
                    }
                }
            } else if (historicalOptionResult?.error) {
                console.warn(`Error fetching historical option suggestion for ${ticker}: ${historicalOptionResult.error}`);
                setChartError(prev => prev ? `${prev} Historical option suggestion failed.` : `Historical option suggestion failed for ${ticker}.`);
            }
        }
    } catch (error) {
        console.error("Error fetching modal data (charts/historical option):", error);
        setChartError(`Error fetching data for ${ticker}: ${error instanceof Error ? error.message : "Unknown error"}`);
        setFmpChartData({ daily: undefined, intraday: undefined }); 
        setSuggestedHistoricalOptionData(null);
        setHistoricalOptionStrategyChartData(null);
    } finally {
        setIsLoadingFMPCharts(false);
        setIsLoadingSuggestedHistoricalOptionData(false);
    }
  }, []);

  useEffect(() => {
    if (isOpen && modalData) {
      fetchAllModalData(modalData);
    }
  }, [isOpen, modalData, fetchAllModalData]);


  if (!isOpen || !modalData) return null;

  const { suggestion, isHistorical, deepDiveAnalysis, isLoadingDeepDive } = modalData;
  const ticker = suggestion.ticker;
  const currentPrice = isHistorical 
    ? (suggestion as HistoricalBullishSuggestionEntry).priceAtSuggestion 
    : (suggestion as StoredBullishStockSuggestion).currentPrice;

  const handleSaveMarkdown = () => {
    const markdownContent = generateMarkdownFromInsightData(modalData);
    const blob = new Blob([markdownContent], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${ticker}_StockAnalysis_${new Date().toISOString().split('T')[0]}.md`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleSavePdf = async () => {
    await generatePdfFromInsightData(modalData);
  };

  const handleSetContextAndClose = () => {
    if (onSetHistoricalContextForStrategy && isHistorical) {
        onSetHistoricalContextForStrategy(suggestion as HistoricalBullishSuggestionEntry, suggestedHistoricalOptionData);
    }
    onClose();
  };

  const renderDetailSection = (title: string, content?: string, titleColor: string = TEXT_COLOR_PRIMARY) => {
    if (!content || content.trim() === '') return null;
    return (
      <div className="mb-4">
        <h4 className={`text-sm font-semibold ${titleColor} mb-1 border-b pb-1`} style={{borderColor: BORDER_COLOR}}>{title}</h4>
        <p className="text-xs whitespace-pre-wrap" style={{color: TEXT_COLOR_SECONDARY}}>{content}</p>
      </div>
    );
  };

  const renderPriceProjections = (projections?: PriceProjectionDetail[]) => {
    if (!projections || projections.length === 0) return null;
    return (
      <div className="mb-3">
        <h4 className="text-sm font-semibold mb-1.5 border-b pb-1" style={{color: OREGON_GREEN, borderColor: BORDER_COLOR}}>Price Projections</h4>
        <div className="space-y-2">
          {projections.map((p, idx) => (
            <div key={idx} className="p-2 border rounded-md" style={{borderColor: `${OREGON_GREEN}4D`, backgroundColor: `${OREGON_GREEN}1A`}}>
              <p className="text-xs font-medium" style={{color: OREGON_GREEN}}>
                Target: ${p.targetPrice.toFixed(2)} (+{p.projectedPriceChangePercent.toFixed(1)}%)
              </p>
              <p className="text-xs" style={{color: `${OREGON_GREEN}B3`}}>Timeline: {p.timelineDetail} (Prob: {p.probabilityEstimate || 'N/A'})</p>
              {p.reasoning && <p className="text-xs italic mt-0.5" style={{color: `${OREGON_GREEN}99`}}> &Lrarr; {p.reasoning}</p>}
            </div>
          ))}
        </div>
      </div>
    );
  };

  const renderChartPatterns = (patterns?: ChartPatternInfo[]) => {
    if (!patterns || patterns.length === 0) return null;
    return (
      <div className="mb-3">
        <h4 className="text-sm font-semibold mb-1.5 border-b pb-1" style={{color: DUKE_BLUE, borderColor: BORDER_COLOR}}>Current Intraday Chart Patterns</h4>
        <div className="space-y-2">
          {patterns.map((p, idx) => (
            <div key={idx} className="p-2 border rounded-md" style={{borderColor: `${DUKE_BLUE}4D`, backgroundColor: `${DUKE_BLUE}1A`}}>
              <p className="text-xs font-medium" style={{color: DUKE_BLUE}}>
                {p.patternName || 'N/A'} <span style={{color: `${DUKE_BLUE}B3`}}>({p.timeframe || 'N/A'})</span> - Status: <span className="font-normal">{p.status || 'N/A'}</span>
              </p>
              {p.keyLevels && <p className="text-xs" style={{color: `${DUKE_BLUE}CC`}}>Levels: {p.keyLevels}</p>}
              <p className="text-xs italic mt-0.5" style={{color: `${DUKE_BLUE}99`}}>{p.description || 'No description.'}</p>
            </div>
          ))}
        </div>
      </div>
    );
  };
  
  const renderBarPlays = (plays?: BarPlayAnalysisInfo[]) => {
    if (!plays || plays.length === 0) return null;
    return (
      <div className="mb-3">
        <h4 className="text-sm font-semibold mb-1.5 border-b pb-1" style={{color: OREGON_YELLOW, borderColor: BORDER_COLOR}}>Short-Term Bar Play Analysis</h4>
        <div className="space-y-2">
          {plays.map((p, idx) => (
            <div key={idx} className="p-2 border rounded-md" style={{borderColor: `${OREGON_YELLOW}4D`, backgroundColor: `${OREGON_YELLOW}1A`}}>
              <p className="text-xs font-medium" style={{color: OREGON_YELLOW}}>
                {p.playType || 'N/A'} <span style={{color: `${OREGON_YELLOW}B3`}}>({p.relevantTimeframe || 'N/A'})</span>
              </p>
              <p className="text-xs" style={{color: `${OREGON_YELLOW}CC`}}>Outcome: {p.outcome || 'N/A'} (Confidence: {p.confidence || 'N/A'})</p>
              <p className="text-xs italic mt-0.5" style={{color: `${OREGON_YELLOW}99`}}>{p.description || 'No description.'}</p>
            </div>
          ))}
        </div>
      </div>
    );
  };

 const renderHistoricalOptionSuggestionAndChart = () => {
    if (isLoadingSuggestedHistoricalOptionData) {
        return (
            <div className="flex items-center justify-center my-3 p-2 text-xs border rounded-md" style={{backgroundColor: `${DUKE_BLUE}0D`, borderColor: `${DUKE_BLUE}33`, color: `${DUKE_BLUE}CC`}}>
                 <LoadingSpinner className="h-4 w-4 mr-2" /> Fetching AI example historical option...
            </div>
        );
    }
    if (!suggestedHistoricalOptionData || !suggestedHistoricalOptionData.legs || suggestedHistoricalOptionData.legs.length === 0) {
        if (suggestedHistoricalOptionData?.error) {
            return (
                 <div className="my-3 p-2 text-xs border rounded-md" style={{backgroundColor: `${STANFORD_CARDINAL_RED}0D`, borderColor: `${STANFORD_CARDINAL_RED}33`, color: `${STANFORD_CARDINAL_RED}CC`}}>
                    Error fetching historical option: {suggestedHistoricalOptionData.error}
                </div>
            );
        }
        return null;
    }
    return (
        <div className="mb-3 p-2 border rounded-md" style={{backgroundColor: `${DUKE_BLUE}0D`, borderColor: `${DUKE_BLUE}33`}}>
            <div className="flex justify-between items-center">
                <h4 className="text-sm font-semibold" style={{color: DUKE_BLUE}}>AI Example Historical Payoff</h4>
                <button 
                    onClick={() => setIsHistoricalOptionChartVisible(prev => !prev)}
                    className="text-xs px-2 py-1 rounded"
                    style={{color: DUKE_BLUE, backgroundColor: `${DUKE_BLUE}26`}}
                >
                    {isHistoricalOptionChartVisible ? 'Hide Chart' : 'View Chart'}
                </button>
            </div>
            <div className="space-y-1 mt-1.5 mb-1.5">
                {suggestedHistoricalOptionData.legs.map((leg, idx) => (
                    <p key={idx} className="text-xs" style={{color: DUKE_BLUE}}>
                        Leg {idx + 1}: {leg.action.toUpperCase()} {leg.type.toUpperCase()} @ {leg.strike} ({leg.role || 'N/A'})
                    </p>
                ))}
                 {suggestedHistoricalOptionData.estimatedNetCostOrCredit !== undefined && (
                    <p className="text-xs" style={{color: DUKE_BLUE}}>Est. Net Cost/Credit: {formatPrice(suggestedHistoricalOptionData.estimatedNetCostOrCredit)}</p>
                )}
            </div>
            {suggestedHistoricalOptionData.reasoningForOptionChoice && (
                <p className="text-xs italic mt-1" style={{color: `${DUKE_BLUE}99`}}>AI Reasoning: {suggestedHistoricalOptionData.reasoningForOptionChoice}</p>
            )}
             {suggestedHistoricalOptionData.dataComment && (
                <p className="text-xs italic mt-1" style={{color: `${DUKE_BLUE}77`}}>AI Comment: {suggestedHistoricalOptionData.dataComment}</p>
            )}

            {isHistoricalOptionChartVisible && historicalOptionStrategyChartData && (
                 <div className="mt-2 -mx-2 sm:mx-0"> {/* Negative margin to expand on small screens if modal padding is tight */}
                    <PayoffChart chartData={historicalOptionStrategyChartData} showIndividualLegs={false} />
                </div>
            )}
            {isHistoricalOptionChartVisible && !historicalOptionStrategyChartData && (
                <p className="text-xs text-center mt-2" style={{color: `${DUKE_BLUE}99`}}>Chart data for historical option play could not be generated.</p>
            )}
        </div>
    );
};
  
  let widgetInterval = "D"; 
  if (suggestion.outlookHorizon === OutlookHorizon.ShortTerm) {
    widgetInterval = "60"; 
  } else if (suggestion.outlookHorizon === OutlookHorizon.MidTerm) {
    widgetInterval = "240"; 
  }

  return (
    <div 
        className="fixed inset-0 bg-black bg-opacity-70 backdrop-blur-md flex justify-center items-center z-[70] p-2 sm:p-4"
        onClick={onClose} 
        aria-modal="true"
        role="dialog"
        aria-labelledby="stock-insight-modal-title"
    >
      <div 
        className="bg-slate-50 rounded-xl shadow-2xl w-full max-w-5xl h-[95vh] max-h-[1000px] flex flex-col transform transition-all duration-300 scale-100 opacity-100"
        onClick={(e) => e.stopPropagation()} 
        id="stockInsightModalContent" // ID for potential html2canvas
      >
        <div className="flex justify-between items-center p-3 sm:p-4 border-b rounded-t-xl" style={{borderColor: BORDER_COLOR, backgroundColor: `${DUKE_BLUE}1A`}}>
          <div>
            <h2 id="stock-insight-modal-title" className="text-lg sm:text-xl font-bold" style={{color: DUKE_BLUE}}>
              {ticker.toUpperCase()} - Detailed Analysis
            </h2>
            <p className="text-xs" style={{color: TEXT_COLOR_SECONDARY}}>
              Current Price (at suggestion): ${currentPrice?.toFixed(2) || 'N/A'}
              {isHistorical && ` (Suggested on: ${formatDate((suggestion as HistoricalBullishSuggestionEntry).initialTimestamp)})`}
            </p>
          </div>
          <div className="flex items-center space-x-2">
            <button
              onClick={handleSaveMarkdown}
              title="Save as Markdown"
              className="p-1.5 rounded-md hover:bg-opacity-20 focus:outline-none focus:ring-2"
              style={{color: DUKE_BLUE, backgroundColor: `${DUKE_BLUE}1A`, outlineColor: DUKE_BLUE }}
            >
              <DownloadIcon className="w-4 h-4" /> <span className="sr-only">Save MD</span>
            </button>
            <button
              onClick={handleSavePdf}
              title="Save as PDF"
              className="p-1.5 rounded-md hover:bg-opacity-20 focus:outline-none focus:ring-2"
              style={{color: DUKE_BLUE, backgroundColor: `${DUKE_BLUE}1A`, outlineColor: DUKE_BLUE }}
            >
              <DownloadIcon className="w-4 h-4" /> <span className="sr-only">Save PDF</span>
            </button>
            <button
              onClick={onClose}
              className="p-1 rounded-full focus:outline-none focus:ring-2"
              style={{color: TEXT_COLOR_SECONDARY, outlineColor: DUKE_BLUE}}
              aria-label="Close detailed insight modal"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 sm:h-7 sm:w-7" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
        </div>

        <div className="flex flex-col md:flex-row flex-grow overflow-hidden">
          {/* Left Side: TradingView and FMP Charts */}
          <div className="w-full md:w-3/5 h-1/2 md:h-full border-b md:border-b-0 md:border-r flex flex-col overflow-y-auto" style={{borderColor: BORDER_COLOR}}>
            <div className="h-1/2 md:h-2/5 border-b" style={{borderColor: BORDER_COLOR}}>
                {typeof ticker === 'string' && isValidTicker(ticker) ? (
                    <TradingViewWidget 
                        symbol={ticker} 
                        interval={widgetInterval}
                        range={suggestion.outlookHorizon === OutlookHorizon.ShortTerm ? "5D" : "6M"} 
                    />
                ) : (
                    <div className="flex items-center justify-center h-full" style={{color: TEXT_COLOR_SECONDARY}}>Invalid Ticker for TradingView Chart.</div>
                )}
            </div>
            <div className="flex-grow p-2 space-y-2 overflow-y-auto">
                <h4 className="text-sm font-semibold text-center sticky top-0 bg-slate-100 py-1 z-10" style={{color: DUKE_BLUE}}>Historical Context (FMP Data)</h4>
                {chartError && (
                    <div className="p-2 text-xs text-center text-red-600 bg-red-50 border border-red-200 rounded-md">{chartError}</div>
                )}
                 <FMPPlotlyChart 
                    prices={fmpChartData.daily} 
                    title={`${ticker} Daily Chart (6 Months Prior)`} 
                    ticker={ticker}
                    isLoading={isLoadingFMPCharts && !chartError} 
                />
                {fmpChartData.intraday && fmpChartData.intraday.length > 0 && (
                    <FMPPlotlyChart 
                        prices={fmpChartData.intraday} 
                        title={`${ticker} Intraday Chart (5-min)`} 
                        ticker={ticker}
                        isLoading={isLoadingFMPCharts && !chartError}
                    />
                )}
                 {isLoadingFMPCharts && !chartError && (!fmpChartData.daily && !fmpChartData.intraday) && (
                     <div className="flex items-center justify-center h-24 text-sm" style={{color: TEXT_COLOR_SECONDARY}}>
                        <LoadingSpinner className="h-5 w-5 mr-2" />
                        Loading FMP charts...
                    </div>
                 )}
            </div>
          </div>

          {/* Right Side: Analysis Details */}
          <div className="w-full md:w-2/5 h-1/2 md:h-full overflow-y-auto p-3 sm:p-4">
            {isLoadingDeepDive && !deepDiveAnalysis && (
              <div className="flex flex-col items-center justify-center h-full">
                <LoadingSpinner className="h-10 w-10 mb-3" />
                <p style={{color: DUKE_BLUE}} className="text-sm">Loading detailed AI analysis for {ticker}...</p>
              </div>
            )}
            {!isLoadingDeepDive && deepDiveAnalysis?.error && (
              <div className="p-3 border rounded-md text-sm" style={{backgroundColor: `${STANFORD_CARDINAL_RED}1A`, borderColor: `${STANFORD_CARDINAL_RED}4D`, color: STANFORD_CARDINAL_RED}}>
                <p className="font-semibold">Error loading detailed analysis:</p>
                <p>{deepDiveAnalysis.error}</p>
              </div>
            )}
            {!isLoadingDeepDive && !deepDiveAnalysis?.error && (
              <>
                {deepDiveAnalysis?.dataComment && (
                    <div className="mb-3 p-2 text-xs border rounded-md italic" style={{backgroundColor: `${DUKE_BLUE}0D`, borderColor: `${DUKE_BLUE}33`, color: `${DUKE_BLUE}CC`}}>
                        <MessageIcon className="inline w-3 h-3 mr-1"/> {deepDiveAnalysis.dataComment}
                    </div>
                )}
                {isHistorical && renderHistoricalOptionSuggestionAndChart()}
                {renderChartPatterns(deepDiveAnalysis?.currentChartPatterns || suggestion.currentChartPatterns)}
                {renderBarPlays(deepDiveAnalysis?.barPlayAnalysis || suggestion.barPlayAnalysis)}
                {renderPriceProjections(deepDiveAnalysis?.priceProjectionDetails || suggestion.priceProjectionDetails)}
                {renderDetailSection("Detailed Reasoning", deepDiveAnalysis?.detailedReasoning || suggestion.detailedReasoning, DUKE_BLUE)}
                {renderDetailSection("Microstructure Insights", deepDiveAnalysis?.microstructureInsights || (suggestion as StoredBullishStockSuggestion).microstructureInsights, DUKE_BLUE)}
                {renderDetailSection("Covariance Considerations", deepDiveAnalysis?.covarianceConsiderations || (suggestion as StoredBullishStockSuggestion).covarianceConsiderations, DUKE_BLUE)}
                {renderDetailSection("Advanced Model References", deepDiveAnalysis?.advancedModelReferences || (suggestion as StoredBullishStockSuggestion).advancedModelReferences, DUKE_BLUE)}
                
                {/* Fallback to initial reasoning if deep dive didn't provide one */}
                {(!deepDiveAnalysis?.detailedReasoning && !(suggestion as HistoricalBullishSuggestionEntry).detailedReasoning && suggestion.reasoning) && 
                    renderDetailSection("Initial Reasoning (Fallback)", suggestion.reasoning, TEXT_COLOR_PRIMARY)
                }

                {deepDiveAnalysis?.sources && deepDiveAnalysis.sources.length > 0 && (
                    <div className="mt-3 pt-2 border-t" style={{borderColor: BORDER_COLOR}}>
                        <h5 className="text-xs font-semibold mb-1" style={{color: TEXT_COLOR_SECONDARY}}>AI Sources:</h5>
                        <ul className="list-disc list-inside text-xs space-y-0.5" style={{color: TEXT_COLOR_SECONDARY}}>
                        {deepDiveAnalysis.sources.map((s, i) => (
                            <li key={i} className="truncate">
                                <a href={s.uri} target="_blank" rel="noopener noreferrer" className="hover:underline" style={{color: DUKE_BLUE}} title={s.title}>
                                    {s.title || new URL(s.uri).hostname}
                                </a>
                            </li>
                        ))}
                        </ul>
                    </div>
                )}
              </>
            )}
          </div>
        </div>
        
        <div className="p-3 border-t flex justify-between items-center rounded-b-xl" style={{borderColor: BORDER_COLOR, backgroundColor: `${DUKE_BLUE}0A`}}>
            {isHistorical && onSetHistoricalContextForStrategy && (
                 <button
                    onClick={handleSetContextAndClose}
                    className="font-semibold py-2 px-4 rounded-md shadow-sm transition-colors text-sm"
                    style={{backgroundColor: OREGON_GREEN, color: 'white'}}
                >
                    Use Historical Context in Main App
                </button>
            )}
             <button
                onClick={onClose}
                className={`font-semibold py-2 px-4 rounded-md shadow-sm transition-colors ${!isHistorical || !onSetHistoricalContextForStrategy ? 'ml-auto' : ''}`}
                style={{backgroundColor: DUKE_BLUE, color: 'white'}}
            >
                Close
            </button>
        </div>

      </div>
    </div>
  );
};

export default StockInsightModal;