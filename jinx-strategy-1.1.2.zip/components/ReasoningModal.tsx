
import React from 'react';
import { ReasoningModalInfo } from '../types'; // Adjust path as necessary
import { PANEL_BACKGROUND, BORDER_COLOR, DUKE_BLUE, TEXT_COLOR_SECONDARY, TEXT_COLOR_PRIMARY } from '../constants'; // Adjust path as necessary

interface ReasoningModalProps {
    info: ReasoningModalInfo | null;
    onClose: () => void;
}

const ReasoningModal: React.FC<ReasoningModalProps> = ({ info, onClose }) => {
  if (!info) return null;
  return (
    <div className="fixed inset-0 bg-black bg-opacity-75 backdrop-blur-sm flex justify-center items-center z-[60] p-4">
      <div style={{backgroundColor: PANEL_BACKGROUND}} className="rounded-lg shadow-xl w-full max-w-lg max-h-[80vh] flex flex-col">
        <div style={{borderColor: BORDER_COLOR}} className="flex justify-between items-center p-4 border-b">
          <h3 style={{color: DUKE_BLUE}} className="text-lg font-semibold truncate">{info.title}</h3>
          <button onClick={onClose} style={{color: TEXT_COLOR_SECONDARY}} className="hover:text-red-600 p-1 rounded-full">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
        <div className="p-4 overflow-y-auto">
          <p style={{color: TEXT_COLOR_PRIMARY}} className="text-sm whitespace-pre-wrap">{info.reasoning}</p>
        </div>
        <div style={{borderColor: BORDER_COLOR}} className="p-3 border-t flex justify-end">
          <button
            onClick={onClose}
            style={{backgroundColor: DUKE_BLUE}}
            className="hover:opacity-90 text-white font-semibold py-2 px-4 rounded-md shadow-sm"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};

export default ReasoningModal;
