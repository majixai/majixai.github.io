
import React from 'react';
import { OptionsChainData, OptionChainEntry, OptionType, Action, OptionLeg, TargetStrikeInfo, ModalPrimingLegInfo } from '../types';

interface OptionsChainModalProps {
  isOpen: boolean;
  onClose: () => void;
  optionsChain: OptionsChainData | null;
  currentUILegs: OptionLeg[]; // Corrected prop name
  targetStrikesFromAI: TargetStrikeInfo[] | null;
  onPremiumSelect: (legIdToUpdate: string, premium: number, strikePrice: number, optionType: OptionType) => void;
  underlyingName: string;
  currentStockPriceForChain?: number | null;
  primedLegForModal?: ModalPrimingLegInfo | null;
}

const OptionsChainModal: React.FC<OptionsChainModalProps> = ({
  isOpen,
  onClose,
  optionsChain,
  currentUILegs, // Corrected prop name
  targetStrikesFromAI,
  onPremiumSelect,
  underlyingName,
  currentStockPriceForChain,
  primedLegForModal,
}) => {
  if (!isOpen || !optionsChain) return null;

  const formatPrice = (price: number | null | undefined, defaultVal: string = 'N/A'): string => {
    if (price === null || price === undefined) return defaultVal;
    return price.toFixed(2);
  };

  const formatNumber = (num: number | null | undefined, defaultVal: string = 'N/A'): string => {
    if (num === null || num === undefined) return defaultVal;
    return num.toLocaleString();
  };

  const getHighlightClass = (strike: number, optionType: OptionType): string => {
    const isTargetAIStrike = targetStrikesFromAI?.some(ts => ts.targetStrike === strike);
    const isCurrentUILegStrike = currentUILegs.some(leg => parseFloat(leg.strike) === strike && leg.type === optionType); // Use corrected prop
    const isPrimedStrike = primedLegForModal?.strike === strike.toString() && primedLegForModal?.optionType === optionType;

    if (isPrimedStrike) return 'bg-yellow-100 border-l-4 border-yellow-500';
    if (isTargetAIStrike && isCurrentUILegStrike) return 'bg-teal-100 border-l-4 border-teal-500';
    if (isTargetAIStrike) return 'bg-blue-100 border-l-4 border-blue-500';
    if (isCurrentUILegStrike) return 'bg-green-100 border-l-4 border-green-500';
    return '';
  };

  const getPriceCellClass = (strike: number, optionType: OptionType, action: Action): string => {
    const relevantUILeg = currentUILegs.find(leg => // Use corrected prop
        parseFloat(leg.strike) === strike &&
        leg.type === optionType &&
        leg.action === action
    );
     const isPrimedForThisAction = primedLegForModal?.strike === strike.toString() &&
                                 primedLegForModal?.optionType === optionType &&
                                 (currentUILegs.find(l => l.id === primedLegForModal.legId)?.action === action); // Use corrected prop

    if (relevantUILeg || isPrimedForThisAction) return 'font-bold text-[#00539B]';
    return '';
  };


  const handlePriceClick = (strike: number, optionType: OptionType, price: number | null | undefined, priceType: 'bid' | 'ask' | 'mid') => {
    if (price === null || price === undefined) return;

    let legToUpdateId: string | undefined;

    if (primedLegForModal && primedLegForModal.strike === strike.toString() && primedLegForModal.optionType === optionType) {
        const primedLeg = currentUILegs.find(l => l.id === primedLegForModal.legId); // Use corrected prop
        if (primedLeg) {
            const impliedAction = (priceType === 'ask') ? Action.Buy : Action.Sell;
            if (priceType === 'mid' || primedLeg.action === impliedAction) {
                 legToUpdateId = primedLegForModal.legId;
            }
        }
    }

    if (!legToUpdateId) {
        const impliedAction = (priceType === 'ask') ? Action.Buy : (priceType === 'bid') ? Action.Sell :
                              (currentUILegs.find(leg => parseFloat(leg.strike) === strike && leg.type === optionType)?.action || Action.Buy); // Use corrected prop

        const legToUpdate = currentUILegs.find(leg => // Use corrected prop
            parseFloat(leg.strike) === strike &&
            leg.type === optionType &&
            leg.action === impliedAction
        );
        if (legToUpdate) {
            legToUpdateId = legToUpdate.id;
        } else {
            const anyMatchingLeg = currentUILegs.find(leg => parseFloat(leg.strike) === strike && leg.type === optionType); // Use corrected prop
            if (anyMatchingLeg) legToUpdateId = anyMatchingLeg.id;
        }
    }


    if (legToUpdateId) {
      onPremiumSelect(legToUpdateId, price, strike, optionType);
    } else {
      console.warn("No suitable leg found in UI to update for strike:", strike, "type:", optionType, "priceType:", priceType);
    }
  };

  const renderChainTable = (
    data: OptionChainEntry[],
    optionType: OptionType,
    title: string
  ) => (
    <div className="w-full lg:w-1/2 px-2 mb-6">
      <h3 className="text-lg font-semibold text-[#00407A] mb-2 text-center">{title}</h3>
      <div className="overflow-x-auto max-h-[60vh] border border-[#D1D5DB] rounded-md shadow-sm">
        <table className="min-w-full divide-y divide-[#E5E7EB] text-xs">
          <thead className="bg-[#E6F0F8] sticky top-0 z-10">
            <tr>
              {['Strike', 'Bid', 'Ask', 'Mid', 'Last', 'Parity', 'Vol', 'OI', 'Vol/OI'].map(header => (
                <th key={header} className="px-3 py-2 text-left font-medium text-[#00539B] tracking-wider">
                  {header}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-[#E5E7EB]">
            {(data && data.length > 0) ? data.map((opt, index) => {
              const volOiRatio = (opt.volume && opt.openInterest && opt.openInterest > 0) ? (opt.volume / opt.openInterest).toFixed(2) : 'N/A';
              const highlightClass = getHighlightClass(opt.strike, optionType);

              return (
                <tr key={`${optionType}-${opt.strike}-${index}`} className={`${highlightClass} hover:bg-slate-50 transition-colors`}>
                  <td className="px-3 py-2 whitespace-nowrap font-medium text-[#333333]">{formatPrice(opt.strike)}</td>
                  <td className={`px-3 py-2 whitespace-nowrap ${getPriceCellClass(opt.strike, optionType, Action.Sell)}`}>
                    <button onClick={() => handlePriceClick(opt.strike, optionType, opt.bid, 'bid')} className="hover:underline disabled:opacity-50 disabled:no-underline" disabled={opt.bid === null}>
                      {formatPrice(opt.bid)}
                    </button>
                  </td>
                  <td className={`px-3 py-2 whitespace-nowrap ${getPriceCellClass(opt.strike, optionType, Action.Buy)}`}>
                     <button onClick={() => handlePriceClick(opt.strike, optionType, opt.ask, 'ask')} className="hover:underline disabled:opacity-50 disabled:no-underline" disabled={opt.ask === null}>
                      {formatPrice(opt.ask)}
                    </button>
                  </td>
                  <td className="px-3 py-2 whitespace-nowrap">
                    <button onClick={() => handlePriceClick(opt.strike, optionType, opt.mid, 'mid')} className="hover:underline disabled:opacity-50 disabled:no-underline" disabled={opt.mid === null}>
                      {formatPrice(opt.mid)}
                    </button>
                  </td>
                  <td className="px-3 py-2 whitespace-nowrap">{formatPrice(opt.last)}</td>
                  <td className="px-3 py-2 whitespace-nowrap">{formatPrice(opt.parity)}</td>
                  <td className="px-3 py-2 whitespace-nowrap">{formatNumber(opt.volume)}</td>
                  <td className="px-3 py-2 whitespace-nowrap">{formatNumber(opt.openInterest)}</td>
                  <td className="px-3 py-2 whitespace-nowrap">{volOiRatio}</td>
                </tr>
              );
            }) : (
              <tr><td colSpan={9} className="text-center py-4 text-gray-500">No {optionType} data available.</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );

  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 backdrop-blur-sm flex justify-center items-center z-50 p-4 transition-opacity duration-300">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-5xl max-h-[90vh] flex flex-col p-6 transform transition-all duration-300 scale-100 opacity-100">
        <div className="flex justify-between items-center mb-4 border-b border-[#D1D5DB] pb-3">
          <div>
            <h2 className="text-xl font-semibold text-[#00407A]">
              Options Chain for {underlyingName.toUpperCase()}
            </h2>
            <p className="text-xs text-gray-500">
              Expiration: {optionsChain.expirationDate || 'N/A'} | Stock Price (at fetch): {formatPrice(currentStockPriceForChain, 'N/A')}
            </p>
             <p className="text-xs text-gray-500 mt-1">
                <span className="inline-block w-3 h-3 bg-yellow-100 border border-yellow-500 mr-1"></span> Primed Leg
                <span className="inline-block w-3 h-3 bg-blue-100 border border-blue-500 ml-2 mr-1"></span> AI Target
                <span className="inline-block w-3 h-3 bg-green-100 border border-green-500 ml-2 mr-1"></span> UI Leg
                <span className="inline-block w-3 h-3 bg-teal-100 border border-teal-500 ml-2 mr-1"></span> AI & UI
            </p>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-red-600 transition-colors p-1 rounded-full"
            aria-label="Close options chain modal"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-7 w-7" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        <div className="flex flex-col lg:flex-row flex-grow overflow-y-auto">
          {renderChainTable(optionsChain.calls || [], OptionType.Call, 'Calls')}
          {renderChainTable(optionsChain.puts || [], OptionType.Put, 'Puts')}
        </div>

        <div className="mt-6 pt-4 border-t border-[#D1D5DB] flex justify-end">
          <button
            onClick={onClose}
            className="bg-[#00539B] hover:bg-[#00407A] text-white font-semibold py-2 px-6 rounded-md shadow-sm transition-colors"
          >
            Apply Selections & Close
          </button>
        </div>
      </div>
    </div>
  );
};

export default OptionsChainModal;
