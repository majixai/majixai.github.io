import React, { useEffect, useRef } from 'react';
import { FMHistoricalPrice } from '../types';
import { DUKE_BLUE, OREGON_GREEN, STANFORD_CARDINAL_RED, TEXT_COLOR_SECONDARY, PANEL_BACKGROUND } from '../constants';

interface FMPPlotlyChartProps {
  prices: FMHistoricalPrice[] | undefined | null;
  title: string;
  ticker: string;
  isLoading: boolean;
}

const FMPPlotlyChart: React.FC<FMPPlotlyChartProps> = ({ prices, title, ticker, isLoading }) => {
  const chartRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!prices || prices.length === 0 || !chartRef.current || !window.Plotly) {
      if(chartRef.current) chartRef.current.innerHTML = ''; // Clear previous chart if no data
      return;
    }

    const trace = {
      x: prices.map(p => p.date),
      open: prices.map(p => p.open),
      high: prices.map(p => p.high),
      low: prices.map(p => p.low),
      close: prices.map(p => p.close),
      increasing: { line: { color: OREGON_GREEN, width: 2 }, fillcolor: OREGON_GREEN+'B3' },
      decreasing: { line: { color: STANFORD_CARDINAL_RED, width: 2 }, fillcolor: STANFORD_CARDINAL_RED+'B3' },
      type: 'candlestick',
      xaxis: 'x',
      yaxis: 'y',
      name: ticker,
    };

    const volumeTrace = {
      x: prices.map(p => p.date),
      y: prices.map(p => p.volume),
      type: 'bar',
      marker: {
        color: prices.map((p, i) => prices[i > 0 ? i-1 : 0].close < p.close ? OREGON_GREEN+'99' : STANFORD_CARDINAL_RED+'99')
      },
      yaxis: 'y2',
      name: 'Volume'
    };
    
    const layout = {
      dragmode: 'zoom',
      margin: { r: 10, t: 40, b: 40, l: 50 },
      showlegend: false,
      xaxis: {
        autorange: true,
        // domain: [0, 1], // Full width for price chart
        rangeslider: { visible: false }, // Keep rangeslider off for modal context
        type: 'date',
        tickfont: { color: TEXT_COLOR_SECONDARY, size: 10 },
        gridcolor: '#e5e7eb33',
      },
      yaxis: {
        autorange: true,
        // domain: [0.3, 1], // Price chart takes top 70%
        type: 'linear',
        title: { text: 'Price', font: {color: TEXT_COLOR_SECONDARY, size: 10}},
        tickfont: { color: TEXT_COLOR_SECONDARY, size: 10 },
        gridcolor: '#e5e7eb33',
      },
      yaxis2: {
        autorange: true,
        // domain: [0, 0.25], // Volume chart takes bottom 25%
        type: 'linear',
        showticklabels: false, // Hide volume tick labels to save space
        gridcolor: '#e5e7eb33',
      },
      plot_bgcolor: PANEL_BACKGROUND,
      paper_bgcolor: PANEL_BACKGROUND,
      title: { 
        text: title, 
        font: { size: 14, color: DUKE_BLUE },
        x: 0.05,
        xanchor: 'left'
      },
      shapes: [], // For future annotations
      annotations: [], // For future annotations
      // Remove range selector buttons for modal to save space
      xaxis_rangeslider_visible: false,
      // modebar: { orientation: 'v', bgcolor: 'rgba(255,255,255,0.5)'},
    };

    window.Plotly.newPlot(chartRef.current, [trace, volumeTrace], layout, { responsive: true, displaylogo: false, modeBarButtonsToRemove: ['sendDataToCloud', 'select2d', 'lasso2d', 'zoomIn2d', 'zoomOut2d', 'autoScale2d', 'resetScale2d', 'toggleSpikelines'] });

  }, [prices, title, ticker]);

  if (isLoading) {
    return (
        <div className="flex items-center justify-center h-40 text-sm" style={{color: TEXT_COLOR_SECONDARY}}>
            <span className="animate-spin rounded-full h-5 w-5 border-b-2 mr-2" style={{borderColor: DUKE_BLUE}}></span>
            Loading chart data for {ticker}...
        </div>
    );
  }

  if (!prices || prices.length === 0) {
    return <div className="flex items-center justify-center h-40 text-sm" style={{color: TEXT_COLOR_SECONDARY}}>No historical data available for {title}.</div>;
  }

  return <div ref={chartRef} style={{ width: '100%', height: '250px' }} />;
};

export default FMPPlotlyChart;