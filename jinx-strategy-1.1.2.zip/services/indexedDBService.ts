// services/indexedDBService.ts
import { openDB, IDBPDatabase, DBSchema, StoreNames, StoreKey } from 'idb';
import {
    DB_NAME, DB_VERSION, PLOT_OPTIONS_STORE_NAME, LEGS_STORE_NAME,
    APP_STATE_STORE_NAME, GITHUB_SETTINGS_STORE_NAME, HISTORICAL_BULLISH_SUGGESTIONS_STORE_NAME,
    SQLITE_DB_STORE_NAME, FMP_CACHE_STORE_NAME, FMP_HISTORICAL_CACHE_STORE_NAME, // Added FMP_HISTORICAL_CACHE_STORE_NAME
    SINGLE_ITEM_KEY, SQLITE_DB_FILE_KEY as SQLITE_DB_FILE_KEY_CONST, 
    PREDEFINED_STRATEGIES, DEFAULT_POINT_VALUE, DEFAULT_NUM_POINTS
} from '../constants';
import {
    PlotOptions, OptionLeg, AppDBState, GitHubExportSettings,
    InsightTabKey, HistoricalBullishSuggestionEntry,
    CachedFMPProfile, CachedFMPQuote, FMPCacheHistoricalEntry, FMHistoricalPrice // Added FMPCacheHistoricalEntry
} from '../types';


interface OptionPlotterDB extends DBSchema {
  [PLOT_OPTIONS_STORE_NAME]: {
    key: string;
    value: PlotOptions;
  };
  [LEGS_STORE_NAME]: {
    key: string;
    value: OptionLeg;
  };
  [APP_STATE_STORE_NAME]: {
    key: string;
    value: AppDBState;
  };
  [GITHUB_SETTINGS_STORE_NAME]: {
    key: string;
    value: GitHubExportSettings;
  };
  [HISTORICAL_BULLISH_SUGGESTIONS_STORE_NAME]: {
    key: string;
    value: HistoricalBullishSuggestionEntry;
    indexes: { 'ticker': string, 'initialTimestamp': number };
  };
  [SQLITE_DB_STORE_NAME]: { 
    key: string; 
    value: Uint8Array;
  };
  [FMP_CACHE_STORE_NAME]: { 
    key: string; 
    value: CachedFMPProfile | CachedFMPQuote;
  };
  [FMP_HISTORICAL_CACHE_STORE_NAME]: { // New store definition
    key: string;
    value: FMPCacheHistoricalEntry;
  };
}

let dbPromise: Promise<IDBPDatabase<OptionPlotterDB>>;

const initDB = () => {
  if (!dbPromise) {
    dbPromise = openDB<OptionPlotterDB>(DB_NAME, DB_VERSION, {
      upgrade(db, oldVersion, newVersion, transaction) {
        console.log(`Upgrading DB from version ${oldVersion} to ${newVersion}`);
        if (oldVersion < 1) {
            if (!db.objectStoreNames.contains(PLOT_OPTIONS_STORE_NAME)) {
            db.createObjectStore(PLOT_OPTIONS_STORE_NAME, { keyPath: 'id' });
            }
            if (!db.objectStoreNames.contains(LEGS_STORE_NAME)) {
            db.createObjectStore(LEGS_STORE_NAME, { keyPath: 'id' });
            }
            if (!db.objectStoreNames.contains(APP_STATE_STORE_NAME)) {
            db.createObjectStore(APP_STATE_STORE_NAME, { keyPath: 'id' });
            }
            if (!db.objectStoreNames.contains(GITHUB_SETTINGS_STORE_NAME)) {
            db.createObjectStore(GITHUB_SETTINGS_STORE_NAME, { keyPath: 'id' });
            }
        }
        if (oldVersion < 2) {
            if (!db.objectStoreNames.contains(HISTORICAL_BULLISH_SUGGESTIONS_STORE_NAME)) {
                const store = db.createObjectStore(HISTORICAL_BULLISH_SUGGESTIONS_STORE_NAME, { keyPath: 'id' });
                store.createIndex('ticker', 'ticker');
                store.createIndex('initialTimestamp', 'initialTimestamp');
            }
        }
        if (oldVersion < 3) { 
            if (!db.objectStoreNames.contains(SQLITE_DB_STORE_NAME)) {
                db.createObjectStore(SQLITE_DB_STORE_NAME);
            }
        }
        if (oldVersion < 4) { 
            if (!db.objectStoreNames.contains(FMP_CACHE_STORE_NAME)) {
                db.createObjectStore(FMP_CACHE_STORE_NAME, { keyPath: 'id' });
            }
        }
        if (oldVersion < 5) { // New upgrade step for historical cache
            if (!db.objectStoreNames.contains(FMP_HISTORICAL_CACHE_STORE_NAME)) {
                db.createObjectStore(FMP_HISTORICAL_CACHE_STORE_NAME, { keyPath: 'id' });
            }
        }
      },
    });
  }
  return dbPromise;
};

const isPlainEmptyObject = (value: any): boolean => {
    return value && typeof value === 'object' && Object.keys(value).length === 0 && Object.getPrototypeOf(value) === Object.prototype;
};

async function getItemFromStore<StoreName extends StoreNames<OptionPlotterDB>>(
    storeName: StoreName,
    key: StoreKey<OptionPlotterDB, StoreName>
): Promise<OptionPlotterDB[StoreName]['value'] | undefined> {
  const db = await initDB();
  return db.get(storeName, key);
}

async function setItemInStore<StoreName extends StoreNames<OptionPlotterDB>>(
  storeName: StoreName,
  item: OptionPlotterDB[StoreName]['value'],
  key?: StoreKey<OptionPlotterDB, StoreName> 
): Promise<StoreKey<OptionPlotterDB, StoreName>> {
  const db = await initDB();
  const keyResult = key !== undefined ? await db.put(storeName, item, key) : await db.put(storeName, item);
  return keyResult;
}

// Helper for stores that expect an object with an 'id' property.
async function getStructuredItemFromStore<TValue extends { id: string }>(
    storeName: StoreNames<OptionPlotterDB>, // Keep StoreNames for db.get validation
    key: string, // Assuming key is always string for these single-item stores
    typeName: string // For logging
): Promise<TValue | undefined> {
    const result = await getItemFromStore(storeName, key as any); // Cast key as any for compatibility with StoreKey

    if (result === undefined) {
        return undefined;
    }

    if (isPlainEmptyObject(result)) {
        console.warn(`IndexedDB: Retrieved plain empty object for ${typeName} with key '${String(key)}', treating as undefined.`);
        return undefined;
    }

    // Check for a minimal structural validity, e.g., presence of an 'id' field.
    if (typeof (result as any).id === 'string') {
        return result as unknown as TValue; // Corrected type assertion
    } else {
        console.warn(`IndexedDB: Retrieved object for ${typeName} with key '${String(key)}' is missing 'id' or has unexpected structure, treating as undefined. Object:`, result);
        return undefined;
    }
}


export const getPlotOptionsFromDB = async (): Promise<PlotOptions | undefined> => {
    return getStructuredItemFromStore<PlotOptions>(PLOT_OPTIONS_STORE_NAME, SINGLE_ITEM_KEY, "PlotOptions");
};
export const savePlotOptionsToDB = async (options: PlotOptions): Promise<string> => {
    const itemToSave: PlotOptions = {...options, id: SINGLE_ITEM_KEY};
    return setItemInStore(PLOT_OPTIONS_STORE_NAME, itemToSave) as Promise<string>;
};

export const getLegsFromDB = async (): Promise<OptionLeg[]> => {
  const db = await initDB();
  return db.getAll(LEGS_STORE_NAME);
};

export const saveLegsToDB = async (legs: OptionLeg[]): Promise<void> => {
  const db = await initDB();
  const tx = db.transaction(LEGS_STORE_NAME, 'readwrite');
  await tx.objectStore(LEGS_STORE_NAME).clear();
  await Promise.all(legs.map(leg => tx.objectStore(LEGS_STORE_NAME).put(leg)));
  await tx.done;
};

export const getAppStateFromDB = async (): Promise<AppDBState | undefined> => {
    return getStructuredItemFromStore<AppDBState>(APP_STATE_STORE_NAME, SINGLE_ITEM_KEY, "AppDBState");
};
export const saveAppStateToDB = async (state: AppDBState): Promise<string> => {
    const itemToSave: AppDBState = {...state, id: SINGLE_ITEM_KEY};
    return setItemInStore(APP_STATE_STORE_NAME, itemToSave) as Promise<string>;
};

export const getGitHubSettingsFromDB = async (): Promise<GitHubExportSettings | undefined> => {
    return getStructuredItemFromStore<GitHubExportSettings>(GITHUB_SETTINGS_STORE_NAME, SINGLE_ITEM_KEY, "GitHubSettings");
};
export const saveGitHubSettingsToDB = async (settings: GitHubExportSettings): Promise<string> => {
    const itemToSave: GitHubExportSettings = {...settings, id: SINGLE_ITEM_KEY};
    return setItemInStore(GITHUB_SETTINGS_STORE_NAME, itemToSave) as Promise<string>;
};

export const saveHistoricalBullishSuggestionToDB = async (suggestion: HistoricalBullishSuggestionEntry): Promise<string> => {
    return setItemInStore(HISTORICAL_BULLISH_SUGGESTIONS_STORE_NAME, suggestion) as Promise<string>;
};

export const getHistoricalBullishSuggestionsFromDB = async (): Promise<HistoricalBullishSuggestionEntry[]> => {
  const db = await initDB();
  return db.getAll(HISTORICAL_BULLISH_SUGGESTIONS_STORE_NAME);
};

export const getHistoricalSuggestionsByTickerFromDB = async (ticker: string): Promise<HistoricalBullishSuggestionEntry[]> => {
    const db = await initDB();
    return db.getAllFromIndex(HISTORICAL_BULLISH_SUGGESTIONS_STORE_NAME, 'ticker', ticker);
};

export const saveSQLiteDBFile = async (dbFile: Uint8Array): Promise<string> => {
    await setItemInStore(SQLITE_DB_STORE_NAME, dbFile, SQLITE_DB_FILE_KEY_CONST);
    return SQLITE_DB_FILE_KEY_CONST; 
};

export const loadSQLiteDBFile = async (): Promise<Uint8Array | undefined> => {
    // Treat the raw result from the DB as 'unknown' to handle potential data corruption
    // or types not strictly matching Uint8Array | undefined.
    const rawResult: unknown = await getItemFromStore(SQLITE_DB_STORE_NAME, SQLITE_DB_FILE_KEY_CONST);

    if (rawResult === undefined) {
        return undefined;
    }
    
    // Now, safely check if rawResult is an instance of Uint8Array.
    if (rawResult instanceof Uint8Array) {
        // Optional: Add a check for empty Uint8Array if it's an invalid state,
        // for example, if sql.js cannot initialize with an empty array.
        // if (rawResult.length === 0) {
        //     console.warn(`IndexedDB: Retrieved empty Uint8Array for SQLite DB file. Treating as undefined.`);
        //     return undefined;
        // }
        return rawResult;
    }
    
    // If rawResult is not undefined and not a Uint8Array, log a warning and return undefined.
    // This covers cases like rawResult being {} or any other unexpected type.
    console.warn(`IndexedDB: Retrieved non-Uint8Array value for SQLite DB file (key: ${SQLITE_DB_FILE_KEY_CONST}). Type: ${typeof rawResult}. Value:`, rawResult, ". Treating as undefined.");
    return undefined;
};


// FMP Cache functions
export const getFMPCacheFromDB = async <T extends CachedFMPProfile | CachedFMPQuote>(cacheKey: string): Promise<T | undefined> => {
    // Use getStructuredItemFromStore as FMPCacheEntry also has an 'id' field.
    const result = await getStructuredItemFromStore<T>(FMP_CACHE_STORE_NAME, cacheKey, "FMPCacheEntry");
    return result;
};

export const saveFMPCacheToDB = async <T extends CachedFMPProfile | CachedFMPQuote>(cacheEntry: T): Promise<string> => {
    return setItemInStore(FMP_CACHE_STORE_NAME, cacheEntry) as Promise<string>;
};

// FMP Historical Cache Functions
export const getFMPHistoricalCacheFromDB = async (cacheKey: string): Promise<FMPCacheHistoricalEntry | undefined> => {
    return getStructuredItemFromStore<FMPCacheHistoricalEntry>(FMP_HISTORICAL_CACHE_STORE_NAME, cacheKey, "FMPHistoricalCacheEntry");
};

export const saveFMPHistoricalCacheToDB = async (cacheEntry: FMPCacheHistoricalEntry): Promise<string> => {
    return setItemInStore(FMP_HISTORICAL_CACHE_STORE_NAME, cacheEntry) as Promise<string>;
};


export const getAllDataForExport = async (): Promise<{
    plotOptions: PlotOptions;
    legs: OptionLeg[];
    appState: AppDBState;
    historicalBullishSuggestions?: HistoricalBullishSuggestionEntry[];
    exportedAt: string;
}> => {
    const plotOptionsData = await getPlotOptionsFromDB();
    const legsData = await getLegsFromDB();
    const appStateData = await getAppStateFromDB();
    const historicalSuggestionsData = await getHistoricalBullishSuggestionsFromDB();

    const defaultPlotOptions: PlotOptions = {
        id: SINGLE_ITEM_KEY,
        underlyingName: 'SPY',
        currentS: '',
        pointValue: DEFAULT_POINT_VALUE,
        minST: '',
        maxST: '',
        numPoints: DEFAULT_NUM_POINTS,
        showIndividualLegs: true,
        initialTTEForSimulation: 45 / 365,
        simulationSigma: '0.20',
        simulationR: '0.05',
    };

    const defaultAppState: AppDBState = {
        id: SINGLE_ITEM_KEY,
        selectedStrategyName: PREDEFINED_STRATEGIES[0].name,
        showBlackScholes: false,
        currentAIStrategySuggestions: null,
        lastUnderlyingForStrategySuggestions: null,
        currentAIBullishStockSuggestions: null,
        lastFetchedBullishStocksTimestamp: null,
        allAccumulatedAISources: null,
        activeInsightTab: InsightTabKey.Status,
        aiCallDurations: {},
        showAnalyticsPanel: false,
    };

    return {
        plotOptions: plotOptionsData || defaultPlotOptions,
        legs: legsData || [],
        appState: appStateData || defaultAppState,
        historicalBullishSuggestions: historicalSuggestionsData || [],
        exportedAt: new Date().toISOString(),
    };
}

initDB();
