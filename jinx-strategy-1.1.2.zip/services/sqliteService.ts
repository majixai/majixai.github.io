
// services/sqliteService.ts
import { 
    AI_INTERACTIONS_TABLE_NAME, SQLITE_DB_FILE_KEY, SINGLE_ITEM_KEY as SINGLE_ITEM_KEY_CONST,
    FMP_PROFILES_TABLE_NAME, FMP_QUOTES_TABLE_NAME // Import FMP table names
} from '../constants'; 
import { 
    PlotOptions, OptionLeg, AppDBState, GitHubExportSettings, 
    HistoricalBullishSuggestionEntry, AIInteractionLogEntry, AICallType,
    OptionType, Action, FMPProfile, FMPQuote // Added FMP types
} from '../types';
import { saveSQLiteDBFile, loadSQLiteDBFile } from './indexedDBService';

let db: any = null; 
let sqlJsInstancePromise: Promise<any> | null = null; 

const serializeComplex = (data: any): string | null => {
    if (data === undefined || data === null) return null;
    try {
        return JSON.stringify(data);
    } catch (e) {
        console.error("Serialization error:", e);
        return null;
    }
};

const deserializeComplex = <T>(jsonString: string | null | undefined): T | null => {
    if (jsonString === undefined || jsonString === null) return null;
    try {
        return JSON.parse(jsonString) as T;
    } catch (e) {
        console.error("Deserialization error:", e, "String was:", jsonString);
        return null;
    }
};

async function getSqlJs() {
    if (sqlJsInstancePromise) return sqlJsInstancePromise;

    sqlJsInstancePromise = new Promise(async (resolve, reject) => {
        let initSqlJsFunction = (window as any).initSqlJs;
        
        if (!initSqlJsFunction) {
            console.warn("sql.js not immediately available on window.initSqlJs. Retrying for a short period...");
            let attempts = 0;
            const maxAttempts = 20; 
            
            const tryToInitialize = async () => {
                initSqlJsFunction = (window as any).initSqlJs;
                if (initSqlJsFunction) {
                    try {
                        const instance = await initSqlJsFunction({ locateFile: (file: string) => `https://cdnjs.cloudflare.com/ajax/libs/sql.js/1.10.3/${file}` });
                        resolve(instance);
                    } catch (e) {
                        reject(e);
                    }
                } else if (attempts < maxAttempts) {
                    attempts++;
                    setTimeout(tryToInitialize, 100);
                } else {
                    reject(new Error("sql.js failed to load on window.initSqlJs after multiple attempts."));
                }
            };
            await tryToInitialize();
        } else {
            try {
                const instance = await initSqlJsFunction({ locateFile: (file: string) => `https://cdnjs.cloudflare.com/ajax/libs/sql.js/1.10.3/${file}` });
                resolve(instance);
            } catch (e) {
                reject(e);
            }
        }
    });
    return sqlJsInstancePromise;
}

export const initSqlJsDb = async (): Promise<boolean> => {
    if (db) return true;
    try {
        const sqlJs = await getSqlJs(); 
        
        const dbFile = await loadSQLiteDBFile();
        if (dbFile) {
            db = new sqlJs.Database(dbFile);
            console.log("SQLite DB loaded from IndexedDB.");
        } else {
            db = new sqlJs.Database();
            console.log("New SQLite DB created.");
        }

        db.exec(`
            CREATE TABLE IF NOT EXISTS plot_options (
                id TEXT PRIMARY KEY, underlyingName TEXT, currentS TEXT, pointValue TEXT, minST TEXT,
                maxST TEXT, numPoints TEXT, showIndividualLegs INTEGER, initialTTEForSimulation REAL,
                simulationSigma TEXT, simulationR TEXT
            );
            CREATE TABLE IF NOT EXISTS option_legs (
                id TEXT PRIMARY KEY, type TEXT, action TEXT, strike TEXT, premium TEXT, quantity TEXT,
                role TEXT, premiumMissing INTEGER
            );
            CREATE TABLE IF NOT EXISTS app_state (
                id TEXT PRIMARY KEY, selectedStrategyName TEXT, showBlackScholes INTEGER,
                currentAIStrategySuggestions TEXT, lastUnderlyingForStrategySuggestions TEXT,
                currentAIBullishStockSuggestions TEXT, lastFetchedBullishStocksTimestamp INTEGER,
                allAccumulatedAISources TEXT, activeInsightTab TEXT, aiCallDurations TEXT,
                showAnalyticsPanel INTEGER DEFAULT 0 
            );
            CREATE TABLE IF NOT EXISTS github_settings (
                id TEXT PRIMARY KEY, pat TEXT, username TEXT, repoName TEXT, filePath TEXT
            );
            CREATE TABLE IF NOT EXISTS historical_bullish_suggestions (
                id TEXT PRIMARY KEY, ticker TEXT, priceAtSuggestion REAL, initialTimestamp INTEGER,
                projectedPriceChangePercentMin REAL, projectedPriceChangePercentMax REAL,
                projectedTimeline TEXT, priceCategory TEXT, outlookHorizon TEXT, reasoning TEXT,
                detailedReasoning TEXT, analysisTimestamp INTEGER, priceProjectionDetails TEXT
            );
            CREATE TABLE IF NOT EXISTS ${AI_INTERACTIONS_TABLE_NAME} (
                id TEXT PRIMARY KEY, timestamp INTEGER NOT NULL, call_type TEXT NOT NULL,
                underlying_name TEXT, strategy_name TEXT, fmp_data_used INTEGER DEFAULT 0,
                prompt_token_count INTEGER, candidates_token_count INTEGER, total_token_count INTEGER,
                error_present INTEGER DEFAULT 0, duration_ms INTEGER
            );
            CREATE TABLE IF NOT EXISTS ${FMP_PROFILES_TABLE_NAME} (
                symbol TEXT PRIMARY KEY, data TEXT, timestamp INTEGER
            );
            CREATE TABLE IF NOT EXISTS ${FMP_QUOTES_TABLE_NAME} (
                symbol TEXT PRIMARY KEY, data TEXT, timestamp INTEGER
            );
        `);
        console.log(`SQLite tables ensured, including FMP tables.`);
        return true;
    } catch (error) {
        console.error("Failed to initialize SQLite DB:", error);
        db = null; 
        sqlJsInstancePromise = null; 
        return false;
    }
};

const persistSQLiteDB = async () => {
    if (!db) { 
      const initialized = await initSqlJsDb();
      if (!initialized || !db) {
        console.error("Cannot persist: SQLite DB not initialized.");
        return;
      }
    }
    const binaryArray = db.export();
    await saveSQLiteDBFile(binaryArray);
};

const generateUUID = (): string => {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
        var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
        return v.toString(16);
    });
}

export const logAIInteraction = async (logEntry: Omit<AIInteractionLogEntry, 'id' | 'timestamp'>): Promise<void> => {
    if (!db) { 
        const initialized = await initSqlJsDb(); 
        if (!initialized || !db) { 
            console.error("SQLite DB not initialized, cannot log AI interaction."); return; 
        } 
    }
    const entry: AIInteractionLogEntry = { id: generateUUID(), timestamp: Date.now(), ...logEntry };
    try {
        db.run(`INSERT INTO ${AI_INTERACTIONS_TABLE_NAME} VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [ entry.id, entry.timestamp, entry.call_type, entry.underlying_name || null,
              entry.strategy_name || null, entry.fmp_data_used, entry.prompt_token_count || null,
              entry.candidates_token_count || null, entry.total_token_count || null,
              entry.error_present, entry.duration_ms ]);
        await persistSQLiteDB();
    } catch (error) { console.error("Error logging AI interaction to SQLite:", error); }
};

export const savePlotOptionsToSQLite = async (options: PlotOptions): Promise<void> => {
    if (!db) { await initSqlJsDb(); if (!db) return; }
    db.run("INSERT OR REPLACE INTO plot_options VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [
        options.id, options.underlyingName, options.currentS, options.pointValue, options.minST,
        options.maxST, options.numPoints, options.showIndividualLegs ? 1 : 0,
        options.initialTTEForSimulation, options.simulationSigma, options.simulationR
    ]);
    await persistSQLiteDB();
};

export const getPlotOptionsFromSQLite = async (): Promise<PlotOptions | undefined> => {
    if (!db) { await initSqlJsDb(); if (!db) return undefined; }
    const stmt = db.prepare("SELECT * FROM plot_options WHERE id = ?");
    const result = stmt.getAsObject({ '?': SINGLE_ITEM_KEY_CONST }); 
    stmt.free();
    if (result.id) {
        return { ...result, showIndividualLegs: Boolean(result.showIndividualLegs) } as PlotOptions;
    }
    return undefined;
};

export const saveLegsToSQLite = async (legs: OptionLeg[]): Promise<void> => {
    if (!db) { await initSqlJsDb(); if (!db) return; }
    db.exec("DELETE FROM option_legs");
    legs.forEach(leg => {
        db.run("INSERT INTO option_legs VALUES (?, ?, ?, ?, ?, ?, ?, ?)", [
            leg.id, leg.type, leg.action, leg.strike, leg.premium, leg.quantity, leg.role, leg.premiumMissing ? 1 : 0
        ]);
    });
    await persistSQLiteDB();
};

export const getLegsFromSQLite = async (): Promise<OptionLeg[]> => {
    if (!db) { await initSqlJsDb(); if (!db) return []; }
    const results = db.exec("SELECT * FROM option_legs");
    if (results.length > 0 && results[0].values) {
        return results[0].values.map((row: any[]) => ({
            id: row[0] as string, type: row[1] as OptionType, action: row[2] as Action,
            strike: row[3] as string, premium: row[4] as string, quantity: row[5] as string,
            role: row[6] as string, premiumMissing: Boolean(row[7])
        }));
    }
    return [];
};

export const saveAppStateToSQLite = async (state: AppDBState): Promise<void> => {
    if (!db) { await initSqlJsDb(); if (!db) return; }
    db.run("INSERT OR REPLACE INTO app_state VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [
        state.id, state.selectedStrategyName, state.showBlackScholes ? 1 : 0,
        serializeComplex(state.currentAIStrategySuggestions),
        state.lastUnderlyingForStrategySuggestions,
        serializeComplex(state.currentAIBullishStockSuggestions),
        state.lastFetchedBullishStocksTimestamp,
        serializeComplex(state.allAccumulatedAISources),
        state.activeInsightTab,
        serializeComplex(state.aiCallDurations),
        state.showAnalyticsPanel ? 1 : 0
    ]);
    await persistSQLiteDB();
};

export const getAppStateFromSQLite = async (): Promise<AppDBState | undefined> => {
    if (!db) { await initSqlJsDb(); if (!db) return undefined; }
    const stmt = db.prepare("SELECT * FROM app_state WHERE id = ?");
    const result = stmt.getAsObject({ '?': SINGLE_ITEM_KEY_CONST });
    stmt.free();
    if (result.id) {
        return {
            ...result,
            showBlackScholes: Boolean(result.showBlackScholes),
            currentAIStrategySuggestions: deserializeComplex(result.currentAIStrategySuggestions as string),
            currentAIBullishStockSuggestions: deserializeComplex(result.currentAIBullishStockSuggestions as string),
            allAccumulatedAISources: deserializeComplex(result.allAccumulatedAISources as string),
            aiCallDurations: deserializeComplex(result.aiCallDurations as string),
            showAnalyticsPanel: Boolean(result.showAnalyticsPanel)
        } as AppDBState;
    }
    return undefined;
};

export const saveHistoricalBullishSuggestionToSQLite = async (suggestion: HistoricalBullishSuggestionEntry): Promise<void> => {
    if (!db) { await initSqlJsDb(); if (!db) return; }
    db.run("INSERT OR REPLACE INTO historical_bullish_suggestions VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [
        suggestion.id, suggestion.ticker, suggestion.priceAtSuggestion, suggestion.initialTimestamp,
        suggestion.projectedPriceChangePercentMin, suggestion.projectedPriceChangePercentMax,
        suggestion.projectedTimeline, suggestion.priceCategory, suggestion.outlookHorizon,
        suggestion.reasoning || null, suggestion.detailedReasoning || null, 
        suggestion.analysisTimestamp || null, serializeComplex(suggestion.priceProjectionDetails) 
    ]);
    await persistSQLiteDB();
};

export const getHistoricalBullishSuggestionsFromSQLite = async (): Promise<HistoricalBullishSuggestionEntry[]> => {
    if (!db) { await initSqlJsDb(); if (!db) return []; }
    const results = db.exec("SELECT * FROM historical_bullish_suggestions ORDER BY initialTimestamp DESC");
    if (results.length > 0 && results[0].values) {
        return results[0].values.map((row: any[]) => ({
            id: row[0] as string, ticker: row[1] as string, priceAtSuggestion: row[2] as number | null,
            initialTimestamp: row[3] as number, projectedPriceChangePercentMin: row[4] as number | null,
            projectedPriceChangePercentMax: row[5] as number | null, projectedTimeline: row[6] as string | null,
            priceCategory: row[7] as any, outlookHorizon: row[8] as any, reasoning: row[9] as string | undefined,
            detailedReasoning: row[10] as string | undefined, analysisTimestamp: row[11] as number | undefined,
            priceProjectionDetails: deserializeComplex(row[12] as string)
        }));
    }
    return [];
};

export const saveGitHubSettingsToSQLite = async (settings: GitHubExportSettings): Promise<void> => {
    if (!db) { await initSqlJsDb(); if (!db) return; }
    db.run("INSERT OR REPLACE INTO github_settings VALUES (?, ?, ?, ?, ?)", [
        settings.id, settings.pat, settings.username, settings.repoName, settings.filePath
    ]);
    await persistSQLiteDB();
};

export const getGitHubSettingsFromSQLite = async (): Promise<GitHubExportSettings | undefined> => {
    if (!db) { await initSqlJsDb(); if (!db) return undefined; }
    const stmt = db.prepare("SELECT * FROM github_settings WHERE id = ?");
    const result = stmt.getAsObject({ '?': SINGLE_ITEM_KEY_CONST }); 
    stmt.free();
    return result.id ? result as GitHubExportSettings : undefined;
};

// FMP Data Sync to SQLite
export const saveFMPProfileToSQLite = async (symbol: string, profile: FMPProfile, timestamp: number): Promise<void> => {
    if (!db) { await initSqlJsDb(); if (!db) return; }
    db.run(`INSERT OR REPLACE INTO ${FMP_PROFILES_TABLE_NAME} (symbol, data, timestamp) VALUES (?, ?, ?)`, 
        [symbol, serializeComplex(profile), timestamp]);
    await persistSQLiteDB();
};

export const getFMPProfileFromSQLite = async (symbol: string): Promise<FMPProfile | null> => {
    if (!db) { await initSqlJsDb(); if (!db) return null; }
    const stmt = db.prepare(`SELECT data FROM ${FMP_PROFILES_TABLE_NAME} WHERE symbol = ?`);
    const result = stmt.getAsObject({ '?': symbol });
    stmt.free();
    return result.data ? deserializeComplex<FMPProfile>(result.data as string) : null;
};

export const saveFMPQuoteToSQLite = async (symbol: string, quote: FMPQuote, timestamp: number): Promise<void> => {
    if (!db) { await initSqlJsDb(); if (!db) return; }
    db.run(`INSERT OR REPLACE INTO ${FMP_QUOTES_TABLE_NAME} (symbol, data, timestamp) VALUES (?, ?, ?)`, 
        [symbol, serializeComplex(quote), timestamp]);
    await persistSQLiteDB();
};

export const getFMPQuoteFromSQLite = async (symbol: string): Promise<FMPQuote | null> => {
    if (!db) { await initSqlJsDb(); if (!db) return null; }
    const stmt = db.prepare(`SELECT data FROM ${FMP_QUOTES_TABLE_NAME} WHERE symbol = ?`);
    const result = stmt.getAsObject({ '?': symbol });
    stmt.free();
    return result.data ? deserializeComplex<FMPQuote>(result.data as string) : null;
};


export const getDatabaseFile = (): Uint8Array | null => {
    if (!db) {
      console.warn("Attempted to get database file before DB was initialized.");
      return null;
    }
    return db.export();
};
