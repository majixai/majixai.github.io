// services/externalApiService.ts
import { PolygonAggregateResponse } from '../types';

const POLYGON_API_BASE_URL = "https://api.polygon.io"; // Example base URL

/**
 * Fetches stock aggregate data from an external API (e.g., Polygon.io).
 * IMPORTANT: This function assumes POLY_API_KEY is available via process.env.
 * Using API keys directly on the client-side is a security risk for production applications.
 * Ensure the target API supports CORS for client-side requests.
 *
 * @param ticker The stock ticker symbol.
 * @param multiplier The size of the timespan multiplier.
 * @param timespan The timespan for aggregates (e.g., "minute", "hour", "day").
 * @param from The start date for aggregates (YYYY-MM-DD).
 * @param to The end date for aggregates (YYYY-MM-DD).
 * @param limit The maximum number of base aggregates to aggregate.
 * @returns A promise that resolves to the API response or an error object.
 */
export async function fetchStockAggregates(
  ticker: string,
  multiplier: number,
  timespan: string,
  from: string,
  to: string,
  limit: number = 5000
): Promise<PolygonAggregateResponse | { error: string }> {
  const apiKey = process.env.POLY_API_KEY;

  if (!apiKey) {
    console.error("External API Key (POLY_API_KEY) is not configured in the environment.");
    return { error: "External API Key (POLY_API_KEY) is not configured." };
  }

  // Example URL structure for Polygon.io aggregates
  const url = `${POLYGON_API_BASE_URL}/v2/aggs/ticker/${ticker}/range/${multiplier}/${timespan}/${from}/${to}?adjusted=true&sort=asc&limit=${limit}`;

  try {
    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${apiKey}`
        // Add other headers if required by the API
      }
    });

    if (!response.ok) {
      let errorData;
      try {
        errorData = await response.json();
      } catch (e) {
        // If response is not JSON or fails to parse
        return { error: `External API request failed for ${ticker} with status ${response.status}: ${response.statusText}` };
      }
      // Try to extract a more specific error message from the API's JSON response
      const errorMessage = errorData?.message || errorData?.error || `External API request failed for ${ticker} with status ${response.status}`;
      console.error(`External API Error (${response.status}) for ${ticker}:`, errorMessage, errorData);
      return { error: `External API Error (${ticker}): ${errorMessage}` };
    }

    const data: PolygonAggregateResponse = await response.json();

    // Some APIs might return a 200 OK but still have an error in the body
    if (data.status === "ERROR" || data.error) {
        console.error(`External API returned an error status for ${ticker}:`, data.error || data.status);
        return { error: `External API Error (${ticker}): ${data.error || "Unknown error from API status."}` };
    }
    
    return data;

  } catch (error) {
    console.error(`Network or parsing error fetching external data for ${ticker}:`, error);
    const message = error instanceof Error ? error.message : `Unknown network error during fetch for ${ticker}.`;
    return { error: `Network error with External API (${ticker}): ${message}` };
  }
}

// Example of how this might be called (do not uncomment here, call from App.tsx or other components):
/*
async function exampleUsage() {
  const tickerData = await fetchStockAggregates("AAPL", 1, "day", "2023-01-01", "2023-01-10");
  if ('error' in tickerData) {
    console.error("Failed to fetch AAPL data:", tickerData.error);
  } else {
    console.log("AAPL Data:", tickerData.results);
  }
}
*/
