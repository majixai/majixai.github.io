
import { useState, useCallback, useEffect } from 'react'; // Added useEffect
import {
    GeminiStrategyDataResponse,
    GeminiBlackScholesInputsResponse,
    GeminiStrategySuggestionResponse,
    GeminiBullishStockSuggestionResponse,
    GeminiDeeperAnalysisResponse,
    GroundingSource,
    AICallType,
    GeneralStatusMessage,
    AppDBState,
    OptionType,
    OptionChainEntry,
    OptionsChainData, // Added
    BullishStockSuggestion,
    StoredBullishStockSuggestion,
    StockPriceCategory,
    OutlookHorizon,
    PriceProjectionDetail,
    SuggestedStrategyInfo,
    FMPProfile,
    FMPQuote,
    GeminiSuggestedHistoricalOption // Added type
} from '../types';
import {
    executeAICall,
    parseJsonFromResponse,
    getStrategyDataPrompt,
    getStrategyExplanationPrompt,
    getBlackScholesInputsPrompt,
    getStrategySuggestionsPrompt,
    getBullishStockSuggestionsPrompt,
    getDeeperStockAnalysisPrompt,
    fetchAISuggestedHistoricalOption // Added function for type-checking, though not directly called by this hook
} from '../services/geminiService';
import { getCompanyProfileFMP, getQuoteFMP, getOptionsChainFMP } from '../services/fmpService'; // Added FMP
import { logAIInteraction, initSqlJsDb } from '../services/sqliteService'; // Added SQLite logging

interface UseGeminiServiceProps {
  showStatus: (text: string, type: GeneralStatusMessage['type'], aiCallType?: AICallType, durationMs?: number) => void;
  updateAppDBState: (updates: Partial<AppDBState>) => void;
  predefinedStrategyNames: string[];
}

export const useGeminiService = ({ showStatus, updateAppDBState, predefinedStrategyNames }: UseGeminiServiceProps) => {
  const [isFetchingStrategyData, setIsFetchingStrategyData] = useState(false);
  const [isFetchingBsInputs, setIsFetchingBsInputs] = useState(false); // Not used by BS Calculator directly anymore
  const [isFetchingStrategyExplanation, setIsFetchingStrategyExplanation] = useState(false);
  const [isFetchingAIStrategySuggestions, setIsFetchingAIStrategySuggestions] = useState(false);
  const [isFetchingAIBullishStocks, setIsFetchingAIBullishStocks] = useState(false);
  const [isFetchingDeeperAnalysis, setIsFetchingDeeperAnalysis] = useState(false);

  // Ensure SQLite DB is ready for logging
  useEffect(() => { 
    initSqlJsDb(); 
  }, []);


  const anyGeminiLoading = isFetchingStrategyData || isFetchingBsInputs || isFetchingStrategyExplanation || isFetchingAIStrategySuggestions || isFetchingAIBullishStocks || isFetchingDeeperAnalysis;

  const handleAiCallCompletion = useCallback(async (
        callType: AICallType, 
        durationMs: number | undefined, 
        sources: GroundingSource[] | undefined,
        fmpDataUsed: boolean,
        errorPresent: boolean,
        underlyingName?: string,
        strategyName?: string
    ) => {
        if (durationMs) {
            updateAppDBState({ aiCallDurations: { [callType]: durationMs } });
        }
        if (sources && sources.length > 0) {
            updateAppDBState({ allAccumulatedAISources: sources });
        }
        await logAIInteraction({
            call_type: callType,
            underlying_name: underlyingName,
            strategy_name: strategyName,
            fmp_data_used: fmpDataUsed ? 1 : 0,
            error_present: errorPresent ? 1 : 0,
            duration_ms: durationMs || 0
        });
  }, [updateAppDBState]);


  const fetchStrategyData = useCallback(async (underlyingName: string, strategyName: string, legRolesDescription: string): Promise<GeminiStrategyDataResponse> => {
    setIsFetchingStrategyData(true);
    showStatus(`Fetching FMP & AI data for ${underlyingName} - ${strategyName}...`, 'info', AICallType.StrategyData);
    let fmpDataUsed = false;
    let fmpErrorOccurred = false;
    
    const fmpProfilePromise = getCompanyProfileFMP(underlyingName);
    const fmpQuotePromise = getQuoteFMP(underlyingName);
    const fmpOptionsChainPromise = getOptionsChainFMP(underlyingName);

    const [fmpProfile, fmpQuote, fmpOptionsChainData] = await Promise.all([fmpProfilePromise, fmpQuotePromise, fmpOptionsChainPromise]);
    
    if (fmpProfile || fmpQuote || fmpOptionsChainData) fmpDataUsed = true;

    if (!fmpQuote && !fmpProfile) {
        const errorMsg = `FMP Error: Failed to fetch essential FMP profile/quote data for ${underlyingName}. Cannot reliably suggest strategy parameters.`;
        showStatus(errorMsg, 'error', AICallType.StrategyData);
        fmpErrorOccurred = true;
    }
    if (!fmpOptionsChainData) {
        const errorMsg = `FMP Error: Options chain data not found for ${underlyingName}. AI cannot select strikes or auto-fill legs.`;
        showStatus(errorMsg, 'error', AICallType.StrategyData); // Changed to error as it's critical
        fmpErrorOccurred = true;
    }

    if (fmpErrorOccurred) {
        setIsFetchingStrategyData(false);
        await handleAiCallCompletion(AICallType.StrategyData, 0, [], false, true, underlyingName, strategyName);
        return { error: `Critical FMP data missing for ${underlyingName}. Strategy auto-fill aborted. Please check FMP API status or ticker.`, fmpDataUsed: false };
    }
        
    const prompt = getStrategyDataPrompt(underlyingName, strategyName, legRolesDescription, fmpProfile, fmpQuote, fmpOptionsChainData);
    const result = await executeAICall<GeminiStrategyDataResponse>(AICallType.StrategyData, prompt, fmpDataUsed, "gemini-2.5-flash-preview-04-17", 0.0, parseJsonFromResponse);
    
    await handleAiCallCompletion(AICallType.StrategyData, result.durationMs, result.sources, fmpDataUsed, !!result.error, underlyingName, strategyName);

    if (result.error) {
      setIsFetchingStrategyData(false);
      return { ...result, fmpDataUsed }; // Ensure fmpDataUsed is part of the returned error object
    }
    if (!result) {
      setIsFetchingStrategyData(false);
      return { error: "No data returned from AI for strategy data.", durationMs: result.durationMs, fmpDataUsed };
    }

    const finalResponse: GeminiStrategyDataResponse = { ...result, fmpDataUsed };
    finalResponse.currentStockPrice = fmpQuote?.price || fmpProfile?.price || result.currentStockPrice || null;
    
    if (fmpOptionsChainData && finalResponse.currentStockPrice) {
        const stockP = finalResponse.currentStockPrice;
        fmpOptionsChainData.currentStockPriceForChain = stockP;
        fmpOptionsChainData.calls.forEach(o => { o.parity = parseFloat(Math.max(0, stockP - o.strike).toFixed(2)); });
        fmpOptionsChainData.puts.forEach(o => { o.parity = parseFloat(Math.max(0, o.strike - stockP).toFixed(2)); });
        finalResponse.optionsChain = fmpOptionsChainData;
    } else {
        finalResponse.optionsChain = null; 
    }

    if (finalResponse.targetStrikesByRole && !Array.isArray(finalResponse.targetStrikesByRole)) {
        console.warn("Parsed targetStrikesByRole from Gemini is not an array.", finalResponse.targetStrikesByRole);
        finalResponse.targetStrikesByRole = undefined; 
    }
    if (finalResponse.suggestedPointValue === undefined) finalResponse.suggestedPointValue = null;
    if (finalResponse.suggestedNumPoints === undefined) finalResponse.suggestedNumPoints = null;

    setIsFetchingStrategyData(false);
    return finalResponse;
  }, [showStatus, handleAiCallCompletion]);


  const fetchStrategyExplanation = useCallback(async (strategyName: string): Promise<{text?: string, error?: string, sources?: GroundingSource[], durationMs?: number}> => {
    setIsFetchingStrategyExplanation(true);
    showStatus(`Fetching explanation for ${strategyName}...`, 'info', AICallType.StrategyExplanation);

    const prompt = getStrategyExplanationPrompt(strategyName);
    const result = await executeAICall<{text?: string, error?: string, sources?: GroundingSource[], durationMs?: number}>(
      AICallType.StrategyExplanation, prompt, false, "gemini-2.5-flash-preview-04-17", 0.3
    );
    
    await handleAiCallCompletion(AICallType.StrategyExplanation, result.durationMs, result.sources, false, !!result.error, undefined, strategyName);

    if (result.error) {
        setIsFetchingStrategyExplanation(false);
        return result;
    }
    if (!result.text) {
        setIsFetchingStrategyExplanation(false);
        return { error: "AI returned an empty explanation.", sources: result.sources, durationMs: result.durationMs };
    }
    setIsFetchingStrategyExplanation(false);
    return result;
  }, [showStatus, handleAiCallCompletion]);

  const fetchAISuggestStrategies = useCallback(async (underlyingName: string): Promise<GeminiStrategySuggestionResponse> => {
    setIsFetchingAIStrategySuggestions(true);
    let fmpDataUsed = false;
    let fmpProfile: FMPProfile | null = null;
    let fmpQuote: FMPQuote | null = null;

    showStatus(`Fetching FMP data for ${underlyingName} to inform AI strategy suggestions...`, 'info', AICallType.StrategySuggestions);
    try {
        fmpProfile = await getCompanyProfileFMP(underlyingName);
        fmpQuote = await getQuoteFMP(underlyingName);
        if (fmpProfile || fmpQuote) fmpDataUsed = true;

        if (!fmpQuote && !fmpProfile) {
            showStatus(`Warning: Could not fetch FMP profile/quote for ${underlyingName}. AI suggestions will rely on general search and may be less targeted.`, 'warning', AICallType.StrategySuggestions);
        } else {
            showStatus(`FMP data fetched for ${underlyingName}. Proceeding with AI...`, 'info', AICallType.StrategySuggestions);
        }
    } catch (fmpError) {
        console.error("FMP Fetch Error in fetchAISuggestStrategies:", fmpError);
        showStatus(`FMP data fetch failed for ${underlyingName}. AI will proceed with limited context. Error: ${fmpError instanceof Error ? fmpError.message : String(fmpError)}`, 'warning', AICallType.StrategySuggestions);
        fmpDataUsed = false; // Ensure it's false if there was an error
    }
    
    const prompt = getStrategySuggestionsPrompt(underlyingName, predefinedStrategyNames, fmpProfile, fmpQuote);
    const result = await executeAICall<GeminiStrategySuggestionResponse>(AICallType.StrategySuggestions, prompt, fmpDataUsed, "gemini-2.5-flash-preview-04-17", 0.45, parseJsonFromResponse);
    
    await handleAiCallCompletion(AICallType.StrategySuggestions, result.durationMs, result.sources, fmpDataUsed, !!result.error, underlyingName);
    
    const finalResult = {...result, fmpDataUsed};

    if (finalResult.error) {
        setIsFetchingAIStrategySuggestions(false);
        return finalResult;
    }
    if (!finalResult || !finalResult.suggestedStrategies) {
        setIsFetchingAIStrategySuggestions(false);
        return { error: "AI returned an empty or unparsable response for strategy suggestions.", sources: finalResult?.sources, durationMs: finalResult?.durationMs, fmpDataUsed };
    }
    if (finalResult.suggestedStrategies) {
        finalResult.suggestedStrategies = finalResult.suggestedStrategies.filter((suggestion: SuggestedStrategyInfo) => 
            predefinedStrategyNames.includes(suggestion.name) && suggestion.reasoning && suggestion.reasoning.length > 50 
        );
    }
    setIsFetchingAIStrategySuggestions(false);
    return finalResult;
  }, [showStatus, predefinedStrategyNames, handleAiCallCompletion]);

  const fetchAIBullishStocks = useCallback(async (): Promise<GeminiBullishStockSuggestionResponse> => {
    setIsFetchingAIBullishStocks(true);
    showStatus('AI is searching for bullish stock suggestions (Initial Scan)...', 'info', AICallType.BullishStocksInitial);
    let fmpDataUsed = false; // FMP data is not directly injected into this general scan prompt

    const prompt = getBullishStockSuggestionsPrompt();
    const result = await executeAICall<GeminiBullishStockSuggestionResponse>(
        AICallType.BullishStocksInitial, 
        prompt, 
        fmpDataUsed, 
        "gemini-2.5-flash-preview-04-17", 
        0.1, // Reduced temperature
        parseJsonFromResponse
    );

    await handleAiCallCompletion(AICallType.BullishStocksInitial, result.durationMs, result.sources, fmpDataUsed, !!result.error);
    const finalResult = {...result, fmpDataUsed};

    if (finalResult.error) {
        setIsFetchingAIBullishStocks(false);
        // Check if the error is due to parsing but text was present
        if (result.error?.includes("AI returned an unparsable JSON response") || 
            (result.error?.includes("AI returned an empty or unparsable response") && result.error?.includes("despite receiving text"))) {
            return { 
                ...finalResult,
                error: "AI response format error for bullish stock suggestions. The AI did not return the expected JSON structure."
            };
        }
        return finalResult;
    }
    if (!finalResult || !finalResult.suggestedStocks || finalResult.suggestedStocks.length === 0) {
        setIsFetchingAIBullishStocks(false);
        // Check if it was an empty JSON object returned as requested by the prompt on failure.
        if (finalResult.suggestedStocks && Object.keys(finalResult.suggestedStocks).length === 0 && !Array.isArray(finalResult.suggestedStocks)) { // Check for {}
             return { error: "AI indicated it could not fulfill the bullish stock suggestion request in the required format.", sources: finalResult?.sources, durationMs: finalResult?.durationMs, fmpDataUsed };
        }
        return { error: "AI returned no valid bullish stock suggestions or an unparsable response for initial scan.", sources: finalResult?.sources, durationMs: finalResult?.durationMs, fmpDataUsed };
    }
    if (finalResult.suggestedStocks) {
        finalResult.suggestedStocks = finalResult.suggestedStocks
            .map((stock: BullishStockSuggestion) => {
                const currentPriceNum = typeof stock.currentPrice === 'number' && stock.currentPrice > 0 ? stock.currentPrice : null;
                return { 
                    ...stock, 
                    ticker: stock.ticker.toUpperCase().replace(/\s+/g, ''),
                    currentPrice: currentPriceNum,
                    projectedPriceChangePercentMin: typeof stock.projectedPriceChangePercentMin === 'number' ? stock.projectedPriceChangePercentMin : null,
                    projectedPriceChangePercentMax: typeof stock.projectedPriceChangePercentMax === 'number' ? stock.projectedPriceChangePercentMax : null,
                    projectedTimeline: typeof stock.projectedTimeline === 'string' && stock.projectedTimeline.length > 3 ? stock.projectedTimeline : null,
                    priceCategory: currentPriceNum !== null ? (currentPriceNum < 15 ? StockPriceCategory.Below15 : StockPriceCategory.AboveOrEqual15) : StockPriceCategory.AboveOrEqual15, 
                    outlookHorizon: Object.values(OutlookHorizon).includes(stock.outlookHorizon) ? stock.outlookHorizon : OutlookHorizon.MidTerm,
                };
            })
            .filter(stock => 
                stock.ticker.length > 0 && 
                stock.ticker.length < 7 && 
                /^[A-Z0-9.-]+$/.test(stock.ticker) && 
                stock.reasoning && stock.reasoning.length > 30 
            ); 
    }
    if(!finalResult.suggestedStocks || finalResult.suggestedStocks.length === 0) { 
        setIsFetchingAIBullishStocks(false);
        return { error: "AI suggestions (initial scan) did not meet formatting or detail requirements after filtering.", sources: finalResult.sources, durationMs: finalResult.durationMs, fmpDataUsed };
    }
    setIsFetchingAIBullishStocks(false);
    return finalResult;
  }, [showStatus, handleAiCallCompletion]);

  const fetchDeeperAnalysis = useCallback(async (ticker: string, currentPrice: number | null, initialSuggestionData: StoredBullishStockSuggestion): Promise<GeminiDeeperAnalysisResponse> => {
    setIsFetchingDeeperAnalysis(true);
    showStatus(`Fetching deeper analysis for ${ticker}... (includes FMP)`, 'info', AICallType.BullishStocksDeepDive);
    let fmpDataUsed = false;
    let fmpProfile: FMPProfile | null = null;
    let fmpQuote: FMPQuote | null = null;

    try {
        fmpProfile = await getCompanyProfileFMP(ticker);
        fmpQuote = await getQuoteFMP(ticker);
        if (fmpProfile || fmpQuote) {
            fmpDataUsed = true;
            showStatus(`FMP data fetched for ${ticker} for deeper analysis. Proceeding with AI...`, 'info', AICallType.BullishStocksDeepDive);
        } else {
             showStatus(`Warning: Could not fetch fresh FMP profile/quote for ${ticker}. AI deeper analysis will rely on initial context and general search.`, 'warning', AICallType.BullishStocksDeepDive);
        }
    } catch (fmpError) {
        console.error(`FMP Fetch Error in fetchDeeperAnalysis for ${ticker}:`, fmpError);
        showStatus(`FMP data fetch failed for ${ticker}. AI will proceed with limited context. Error: ${fmpError instanceof Error ? fmpError.message : String(fmpError)}`, 'warning', AICallType.BullishStocksDeepDive);
        fmpDataUsed = false;
    }

    const prompt = getDeeperStockAnalysisPrompt(ticker, currentPrice, initialSuggestionData, fmpProfile, fmpQuote);
    const result = await executeAICall<GeminiDeeperAnalysisResponse>(AICallType.BullishStocksDeepDive, prompt, fmpDataUsed, "gemini-2.5-flash-preview-04-17", 0.2, parseJsonFromResponse);

    await handleAiCallCompletion(AICallType.BullishStocksDeepDive, result.durationMs, result.sources, fmpDataUsed, !!result.error, ticker);
    const finalResult = {...result, fmpDataUsed, analysisTimestamp: Date.now()};
    
    if (finalResult.error) {
        setIsFetchingDeeperAnalysis(false);
        return finalResult;
    }
    if (!finalResult) {
        setIsFetchingDeeperAnalysis(false);
        return { error: `No data returned from AI for deeper analysis of ${ticker}.`, durationMs: finalResult.durationMs, fmpDataUsed };
    }
    if (finalResult.priceProjectionDetails && Array.isArray(finalResult.priceProjectionDetails)) {
        finalResult.priceProjectionDetails = finalResult.priceProjectionDetails.map((detail: PriceProjectionDetail) => ({
            targetPrice: typeof detail.targetPrice === 'number' ? detail.targetPrice : 0,
            probabilityEstimate: detail.probabilityEstimate,
            projectedPriceChangePercent: typeof detail.projectedPriceChangePercent === 'number' ? detail.projectedPriceChangePercent : 0,
            timelineDetail: detail.timelineDetail,
            reasoning: detail.reasoning,
            stdDevLevels: detail.stdDevLevels, 
        })).filter(detail => detail.targetPrice > 0 && detail.timelineDetail && detail.probabilityEstimate);
    } else {
        finalResult.priceProjectionDetails = undefined; 
    }
    setIsFetchingDeeperAnalysis(false);
    return finalResult;
  }, [showStatus, handleAiCallCompletion]);

  return {
    isFetchingStrategyData,
    isFetchingBsInputs,
    isFetchingStrategyExplanation,
    isFetchingAIStrategySuggestions,
    isFetchingAIBullishStocks,
    isFetchingDeeperAnalysis,
    anyGeminiLoading,
    fetchStrategyData,
    fetchStrategyExplanation,
    fetchAISuggestStrategies,
    fetchAIBullishStocks,
    fetchDeeperAnalysis,
  };
};