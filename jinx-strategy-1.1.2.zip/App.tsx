
import React, { useState, useEffect, useCallback } from 'react';
import { compressSync, type FlateError } from 'fflate'; 
import {
    OptionLeg, PlotOptions, ChartData, OptionType, Action, PredefinedStrategy,
    StrategyLegDefinition, GroundingSource,
    OptionsChainData, TargetStrikeInfo, StoredAISuggestion,
    AppDBState, GitHubExportSettings, StoredBullishStockSuggestion,
    ReasoningModalInfo, InsightTabKey, GeneralStatusMessage,
    ModalPrimingLegInfo, HistoricalBullishSuggestionEntry, AICallType,
    StockInsightModalData, StockPriceCategory, OutlookHorizon, GeminiSuggestedHistoricalOption 
} from './types';
import {
    MAX_LEGS, DEFAULT_POINT_VALUE, DEFAULT_NUM_POINTS, PREDEFINED_STRATEGIES, SINGLE_ITEM_KEY,
    PlusIcon, ChartIcon, TrashIcon, ClearIcon, FetchIcon, InfoIcon, AISuggestIcon,
    DatabaseIcon, BullishIcon, ExportIcon, EyeIcon, WalletIcon, MessageIcon, BrainIcon, ClipboardIcon, HistoryIcon,
    AnalyticsIcon, PREDEFINED_TICKERS_FOR_PREFETCH, FMP_PROFILE_CACHE_DURATION, FMP_QUOTE_CACHE_DURATION,
    DUKE_BLUE, STANFORD_CARDINAL_RED, OREGON_GREEN, OREGON_YELLOW, LIGHT_NEUTRAL_BACKGROUND, PANEL_BACKGROUND, TEXT_COLOR_PRIMARY, TEXT_COLOR_SECONDARY, BORDER_COLOR,
    LoadingSpinner
} from './constants';
import { generatePlotData, SimulationParams } from './services/optionCalculationService';
import {
    getPlotOptionsFromDB, savePlotOptionsToDB, getLegsFromDB, saveLegsToDB,
    getAppStateFromDB, saveAppStateToDB, getGitHubSettingsFromDB, saveGitHubSettingsToDB,
    getAllDataForExport, saveHistoricalBullishSuggestionToDB, getHistoricalBullishSuggestionsFromDB,
    getFMPCacheFromDB 
} from './services/indexedDBService';
import * as sqliteService from './services/sqliteService'; 
import * as fmpService from './services/fmpService'; 

import { useGeminiService } from './hooks/useGeminiService';
import ConfigurationPanel from './components/ConfigurationPanel';
import OptionLegsPanel from './components/OptionLegsPanel';
import TTESimulationPanel from './components/TTESimulationPanel';
import DataManagementPanel from './components/DataManagementPanel';
import DeveloperToolsPanel from './components/DeveloperToolsPanel';
import PanelSection from './components/PanelSection'; // Imported
import ReasoningModal from './components/ReasoningModal'; // Imported
import ChartSettingsDropdown from './components/ChartSettingsDropdown'; // Imported

import PayoffChart from './components/PayoffChart';
import BlackScholesCalculator from './components/BlackScholesCalculator';
import OptionsChainModal from './components/OptionsChainModal';
import StockInsightModal from './components/StockInsightModal';

import StatusTabContent from './components/insights_panel/StatusTabContent';
import TickersTabContent from './components/insights_panel/TickersTabContent';
import StrategiesTabContent from './components/insights_panel/StrategiesTabContent';
import HistoryTabContent from './components/insights_panel/HistoryTabContent';
import AnalyticsTabContent from './components/insights_panel/AnalyticsTabContent';

import { generateUniqueId } from './utils/miscUtils'; // Imported


const InsightsPanel: React.FC<{
    activeTab: InsightTabKey;
    setActiveTab: (tab: InsightTabKey) => void;
    generalStatusMessage: GeneralStatusMessage | null;
    bullishStockInsights: StoredBullishStockSuggestion[] | null;
    strategyInsights: StoredAISuggestion[] | null;
    historicalBullishSuggestions: HistoricalBullishSuggestionEntry[] | null;
    allLoggedErrors: string[]; 
    onCloseGeneralStatus: () => void;
    onOpenReasoningModal: (info: ReasoningModalInfo) => void;
    isLoading: boolean; 
    onApplyAIStrategySuggestion: (suggestion: StoredAISuggestion) => Promise<void>; 
    onTriggerStockInsightModal: (suggestion: StoredBullishStockSuggestion | HistoricalBullishSuggestionEntry, isHistorical: boolean) => Promise<void>;
    onCopyErrorsToClipboard: () => Promise<void>; 
    currentStockForInsightModal: StockInsightModalData | null;
    plotOptions: PlotOptions; // Added for StrategiesTabContent
    currentAIBullishStockSuggestions: StoredBullishStockSuggestion[] | null; // Added for StrategiesTabContent
}> = ({ 
    activeTab, setActiveTab, generalStatusMessage, 
    bullishStockInsights, strategyInsights, historicalBullishSuggestions, allLoggedErrors,
    onCloseGeneralStatus, onOpenReasoningModal, isLoading, 
    onApplyAIStrategySuggestion, onTriggerStockInsightModal, onCopyErrorsToClipboard, currentStockForInsightModal,
    plotOptions, currentAIBullishStockSuggestions // Added
}) => {

    const renderTabContent = () => {
        switch (activeTab) {
            case InsightTabKey.Status:
                return <StatusTabContent generalStatusMessage={generalStatusMessage} onCloseGeneralStatus={onCloseGeneralStatus} isLoading={isLoading} />;
            case InsightTabKey.Tickers:
                return <TickersTabContent bullishStockInsights={bullishStockInsights} onOpenReasoningModal={onOpenReasoningModal} onTriggerStockInsightModal={onTriggerStockInsightModal} isLoading={isLoading} currentStockForInsightModal={currentStockForInsightModal} />;
            case InsightTabKey.Strategies:
                return <StrategiesTabContent 
                            strategyInsights={strategyInsights} 
                            onOpenReasoningModal={onOpenReasoningModal} 
                            onApplyAIStrategySuggestion={onApplyAIStrategySuggestion} 
                            anyAppLoading={isLoading} 
                            onTriggerStockInsightModal={onTriggerStockInsightModal}
                            currentAIBullishStockSuggestions={currentAIBullishStockSuggestions}
                            historicalBullishSuggestions={historicalBullishSuggestions}
                            plotOptions={plotOptions}
                        />;
            case InsightTabKey.History:
                return <HistoryTabContent historicalBullishSuggestions={historicalBullishSuggestions} onOpenReasoningModal={onOpenReasoningModal} onTriggerStockInsightModal={onTriggerStockInsightModal} isLoading={isLoading} currentStockForInsightModal={currentStockForInsightModal}/>;
            case InsightTabKey.Analytics:
                return <AnalyticsTabContent allLoggedErrors={allLoggedErrors} onCopyErrorsToClipboard={onCopyErrorsToClipboard} anyAppLoading={isLoading} />;
            default: return null;
        }
    };

    const tabConfig = [
        { key: InsightTabKey.Status, label: "Status", icon: <MessageIcon /> },
        { key: InsightTabKey.Tickers, label: "Ticker Insights", icon: <BullishIcon /> },
        { key: InsightTabKey.Strategies, label: "Strategy Insights", icon: <BrainIcon /> },
        { key: InsightTabKey.History, label: "History", icon: <HistoryIcon /> },
        { key: InsightTabKey.Analytics, label: "Analytics", icon: <AnalyticsIcon /> },
    ];

    return (
        <div style={{backgroundColor: PANEL_BACKGROUND, borderColor: BORDER_COLOR}} className="shadow-xl rounded-xl mb-6">
            <div style={{borderColor: BORDER_COLOR}} className="flex border-b overflow-x-auto">
                {tabConfig.map(tab => (
                    <button
                        key={tab.key}
                        onClick={() => setActiveTab(tab.key)}
                        className={`flex-shrink-0 sm:flex-none flex items-center justify-center py-2.5 px-3 sm:px-4 text-xs sm:text-sm font-medium focus:outline-none transition-colors duration-200 group
                            ${activeTab === tab.key
                                ? `border-b-2 text-[${DUKE_BLUE}]` 
                                : `text-[${TEXT_COLOR_SECONDARY}] hover:text-[${DUKE_BLUE}] hover:bg-slate-100`}`}
                        style={{borderColor: activeTab === tab.key ? DUKE_BLUE : 'transparent'}}
                        aria-selected={activeTab === tab.key}
                        role="tab"
                    >
                        {React.cloneElement<{className?: string}>(tab.icon, { className: `mr-1.5 w-4 h-4 ${activeTab === tab.key ? `text-[${DUKE_BLUE}]` : `text-[${TEXT_COLOR_SECONDARY}] group-hover:text-[${DUKE_BLUE}]`}` })} 
                        {tab.label}
                    </button>
                ))}
            </div>
            <div className="transition-all duration-300 ease-in-out">
                {renderTabContent()}
            </div>
        </div>
    );
};


export const App = () => { 
  const [legs, setLegs] = useState<OptionLeg[]>([]);
  const [plotOptions, setPlotOptions] = useState<PlotOptions>({
    id: SINGLE_ITEM_KEY,
    underlyingName: 'SPY', currentS: '', pointValue: DEFAULT_POINT_VALUE,
    minST: '', maxST: '', numPoints: DEFAULT_NUM_POINTS, showIndividualLegs: true,
    initialTTEForSimulation: 45 / 365,
    simulationSigma: '0.20',
    simulationR: '0.05',
  });
  const [chartData, setChartData] = useState<ChartData | null>(null);
  const [generalStatusMessage, setGeneralStatusMessage] = useState<GeneralStatusMessage | null>(null);
  const [allLoggedErrors, setAllLoggedErrors] = useState<string[]>([]);
  const [isLoadingPlot, setIsLoadingPlot] = useState(false);
  const [selectedStrategyName, setSelectedStrategyName] = useState<string>(PREDEFINED_STRATEGIES[0].name);
  
  const [isStockInsightModalOpen, setIsStockInsightModalOpen] = useState(false);
  const [currentStockForInsightModal, setCurrentStockForInsightModal] = useState<StockInsightModalData | null>(null);

  const [currentAIStrategyInsights, setCurrentAIStrategyInsights] = useState<StoredAISuggestion[]>([]);
  const [currentAIBullishStockInsights, setCurrentAIBullishStockInsights] = useState<StoredBullishStockSuggestion[]>([]);
  const [historicalBullishSuggestions, setHistoricalBullishSuggestions] = useState<HistoricalBullishSuggestionEntry[]>([]);
  const [activeInsightTab, setActiveInsightTab] = useState<InsightTabKey>(InsightTabKey.Status);
  const [suggestedStrategyNamesForDropdown, setSuggestedStrategyNamesForDropdown] = useState<string[]>([]);
  const [reasoningModalInfo, setReasoningModalInfo] = useState<ReasoningModalInfo | null>(null);

  const [showConfiguration, setShowConfiguration] = useState(true);
  const [showOptionLegs, setShowOptionLegs] = useState(true);
  const [showTTESimulation, setShowTTESimulation] = useState(false); 
  const [showBlackScholes, setShowBlackScholes] = useState(false);
  const [showDataManagement, setShowDataManagement] = useState(false);
  const [showDeveloperTools, setShowDeveloperTools] = useState(false);
  const [showAnalyticsPanel, setShowAnalyticsPanel] = useState(false); 
  const [showAIDataProvenance, setShowAIDataProvenance] = useState(false);

  const [currentSimulatedTTEDays, setCurrentSimulatedTTEDays] = useState<number>(
    plotOptions.initialTTEForSimulation ? Math.max(0, Math.round(plotOptions.initialTTEForSimulation * 365)) : 45
  );
  const [simulationSigmaInput, setSimulationSigmaInput] = useState<string>(plotOptions.simulationSigma || '0.20');
  const [simulationRInput, setSimulationRInput] = useState<string>(plotOptions.simulationR || '0.05');
  const [isTTESimulationActive, setIsTTESimulationActive] = useState<boolean>(false);

  const [githubSettings, setGithubSettings] = useState<GitHubExportSettings>({
    id: SINGLE_ITEM_KEY, pat: '', username: '', repoName: '', filePath: 'option_plotter_config.json'
  });
  const [isExporting, setIsExporting] = useState(false);
  const [dbInitialized, setDbInitialized] = useState(false); 
  const [sqliteDbInitialized, setSqliteDbInitialized] = useState(false); 
  
  const [appDBState, setAppDBState] = useState<AppDBState>({
    id: SINGLE_ITEM_KEY, selectedStrategyName: PREDEFINED_STRATEGIES[0].name, showBlackScholes: false,
    currentAIStrategySuggestions: null, lastUnderlyingForStrategySuggestions: null,
    currentAIBullishStockSuggestions: null, lastFetchedBullishStocksTimestamp: null,
    allAccumulatedAISources: null,
    activeInsightTab: InsightTabKey.Status,
    aiCallDurations: {},
    showAnalyticsPanel: false, 
  });

  const [isOptionsChainModalOpen, setIsOptionsChainModalOpen] = useState(false);
  const [optionsChainForModal, setOptionsChainForModal] = useState<OptionsChainData | null>(null);
  const [targetStrikesForModal, setTargetStrikesForModal] = useState<TargetStrikeInfo[] | null>(null); 
  const [currentStockPriceForModalChain, setCurrentStockPriceForModalChain] = useState<number | null>(null);
  const [allAccumulatedAISources, setAllAccumulatedAISources] = useState<GroundingSource[]>([]);
  const [modalPrimingLeg, setModalPrimingLeg] = useState<ModalPrimingLegInfo | null>(null);

  const showStatus = useCallback((text: string, type: GeneralStatusMessage['type'], aiCallType?: AICallType, durationMs?: number) => {
    let messageText = text;
    const relevantCallType = aiCallType || (currentStockForInsightModal?.isLoadingDeepDive ? AICallType.BullishStocksDeepDive : undefined);

    if (relevantCallType && appDBState.aiCallDurations && appDBState.aiCallDurations[relevantCallType] && type === 'info' && !durationMs) {
        messageText += ` (Est. ETA: ~${(appDBState.aiCallDurations[relevantCallType]! / 1000).toFixed(1)}s)`;
    }
    if (durationMs && (type === 'success' || type === 'warning')) {
        messageText += ` (Took: ${(durationMs / 1000).toFixed(1)}s)`;
    }

    setGeneralStatusMessage({ text: messageText, type, key: Date.now() });
    if (type === 'error') {
        setAllLoggedErrors(prevErrors => [...prevErrors, `[${new Date().toISOString()}] Status Error: ${messageText}`]);
    }
  }, [appDBState.aiCallDurations, currentStockForInsightModal?.isLoadingDeepDive]);

  const updateAppDBStateCallback = useCallback((updates: Partial<AppDBState>) => {
    setAppDBState(prev => {
        const newState = {...prev, ...updates };
        if (updates.allAccumulatedAISources) {
            const existingUris = new Set(prev.allAccumulatedAISources?.map(s => s.uri) || []);
            const newSources = updates.allAccumulatedAISources.filter(s => !existingUris.has(s.uri));
            newState.allAccumulatedAISources = [...(prev.allAccumulatedAISources || []), ...newSources];
            setAllAccumulatedAISources(newState.allAccumulatedAISources); 
        }
        if(updates.activeInsightTab) setActiveInsightTab(updates.activeInsightTab); 
        if (updates.currentAIBullishStockSuggestions) {
            setCurrentAIBullishStockInsights(updates.currentAIBullishStockSuggestions); 
        }
        if (updates.currentAIStrategySuggestions) {
             const sortedStrategies = updates.currentAIStrategySuggestions.sort((a, b) => (a.rank || 99) - (b.rank || 99));
            setCurrentAIStrategyInsights(sortedStrategies); 
            setSuggestedStrategyNamesForDropdown(sortedStrategies.map(s => s.name));
        }
        if (updates.aiCallDurations) { 
            newState.aiCallDurations = { ...prev.aiCallDurations, ...updates.aiCallDurations };
        }
        if (updates.hasOwnProperty('showAnalyticsPanel')) setShowAnalyticsPanel(!!updates.showAnalyticsPanel);
        return newState;
    });
  }, []);

  const {
    isFetchingStrategyData, 
    isFetchingStrategyExplanation,
    isFetchingAIStrategySuggestions, isFetchingAIBullishStocks, isFetchingDeeperAnalysis,
    anyGeminiLoading,
    fetchStrategyData, 
    fetchStrategyExplanation, fetchAISuggestStrategies, fetchAIBullishStocks, fetchDeeperAnalysis,
  } = useGeminiService({ 
        showStatus, 
        updateAppDBState: updateAppDBStateCallback, 
        predefinedStrategyNames: PREDEFINED_STRATEGIES.map(s=>s.name) 
    });

  const anyAppLoading = isLoadingPlot || isExporting || anyGeminiLoading;

  const addDefaultLeg = useCallback((): OptionLeg[] => {
     const newLeg: OptionLeg = { id: generateUniqueId(), type: OptionType.Call, action: Action.Buy, strike: '', premium: '', quantity: '1', role: 'Default Leg', premiumMissing: true };
     return [newLeg];
  }, []);

  useEffect(() => {
    const initializeApp = async () => {
      await sqliteService.initSqlJsDb().then(setSqliteDbInitialized);
      
      const [dbPlotOptions, dbLegs, dbAppStateFromDB, dbGitHubSettings, dbHistoricalSuggestions] = await Promise.all([
        getPlotOptionsFromDB(), getLegsFromDB(), getAppStateFromDB(), getGitHubSettingsFromDB(), getHistoricalBullishSuggestionsFromDB()
      ]);

      let currentUnderlyingForSuggestions = plotOptions.underlyingName; 
      if (dbPlotOptions) {
          const mergedPlotOptions = {...plotOptions, ...dbPlotOptions};
          setPlotOptions(mergedPlotOptions);
          currentUnderlyingForSuggestions = mergedPlotOptions.underlyingName;
          setCurrentSimulatedTTEDays(Math.max(0, Math.round((mergedPlotOptions.initialTTEForSimulation || 45/365) * 365)));
          setSimulationSigmaInput(mergedPlotOptions.simulationSigma || '0.20');
          setSimulationRInput(mergedPlotOptions.simulationR || '0.05');
      } else {
           savePlotOptionsToDB(plotOptions);
           if (sqliteDbInitialized) sqliteService.savePlotOptionsToSQLite(plotOptions);
      }

      if (dbLegs && dbLegs.length > 0) setLegs(dbLegs.map(l => ({...l, premiumMissing: !l.premium || parseFloat(l.premium) <= 0 })));
      else {
          const defaultLegs = addDefaultLeg();
          setLegs(defaultLegs);
          saveLegsToDB(defaultLegs);
          if (sqliteDbInitialized) sqliteService.saveLegsToSQLite(defaultLegs);
      }

      if (dbAppStateFromDB) {
        const mergedAppState = {...appDBState, ...dbAppStateFromDB};
        setAppDBState(mergedAppState); 
        setSelectedStrategyName(mergedAppState.selectedStrategyName);
        setShowBlackScholes(mergedAppState.showBlackScholes);
        setActiveInsightTab(mergedAppState.activeInsightTab || InsightTabKey.Status);
        setShowAnalyticsPanel(!!mergedAppState.showAnalyticsPanel);
        if (mergedAppState.allAccumulatedAISources) setAllAccumulatedAISources(mergedAppState.allAccumulatedAISources);
        if (mergedAppState.lastUnderlyingForStrategySuggestions === currentUnderlyingForSuggestions && mergedAppState.currentAIStrategySuggestions) {
          const sortedStrategies = mergedAppState.currentAIStrategySuggestions.sort((a, b) => (a.rank || 99) - (b.rank || 99));
          setCurrentAIStrategyInsights(sortedStrategies);
          setSuggestedStrategyNamesForDropdown(sortedStrategies.map(s => s.name));
        }
        if (mergedAppState.currentAIBullishStockSuggestions) {
          const validatedBullishSuggestions = mergedAppState.currentAIBullishStockSuggestions.map(s => ({
              ...s, priceProjectionDetails: s.priceProjectionDetails || undefined, detailedReasoning: s.detailedReasoning || undefined,
              microstructureInsights: s.microstructureInsights || undefined, covarianceConsiderations: s.covarianceConsiderations || undefined,
              advancedModelReferences: s.advancedModelReferences || undefined, analysisTimestamp: s.analysisTimestamp || undefined,
              currentChartPatterns: s.currentChartPatterns || undefined, barPlayAnalysis: s.barPlayAnalysis || undefined,
          }));
          setCurrentAIBullishStockInsights(validatedBullishSuggestions);
        }
      } else {
        saveAppStateToDB(appDBState); 
        if (sqliteDbInitialized) sqliteService.saveAppStateToSQLite(appDBState);
      }
      if (dbGitHubSettings) setGithubSettings(dbGitHubSettings);
      else {
          saveGitHubSettingsToDB(githubSettings);
          if (sqliteDbInitialized) sqliteService.saveGitHubSettingsToSQLite(githubSettings);
      }

      if (dbHistoricalSuggestions) setHistoricalBullishSuggestions(dbHistoricalSuggestions.sort((a,b) => b.initialTimestamp - a.initialTimestamp));
      setDbInitialized(true);
    };
    initializeApp().catch(e => {
      console.error("Initialization Error:", e);
      setAllLoggedErrors(prev => [...prev, `[${new Date().toISOString()}] App Init Error: ${e instanceof Error ? e.message : String(e)}`]);
    });
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [addDefaultLeg, sqliteDbInitialized]); 

  useEffect(() => {
    if (dbInitialized && sqliteDbInitialized) {
        const prefetchFMPData = async () => {
            showStatus(`Prefetching FMP data for ${PREDEFINED_TICKERS_FOR_PREFETCH.length} tickers (staggered)...`, 'info');
            let successCount = 0;
            let skippedCount = 0;
            for (let i = 0; i < PREDEFINED_TICKERS_FOR_PREFETCH.length; i++) {
                const ticker = PREDEFINED_TICKERS_FOR_PREFETCH[i];
                let fetchedProfileThisRun = false;
                let fetchedQuoteThisRun = false;
                
                const profileCacheKey = `${ticker.toUpperCase()}_profile`;
                const cachedProfile = await getFMPCacheFromDB(profileCacheKey);
                let profileFetchedLive = false;
                if (cachedProfile && (Date.now() - cachedProfile.timestamp < FMP_PROFILE_CACHE_DURATION)) {
                    fetchedProfileThisRun = true; 
                } else {
                    try {
                        showStatus(`Prefetching FMP profile for ${ticker}... (${i+1}/${PREDEFINED_TICKERS_FOR_PREFETCH.length})`, 'info');
                        const profile = await fmpService.getCompanyProfileFMP(ticker);
                        if (profile) { fetchedProfileThisRun = true; profileFetchedLive = true; }
                        await new Promise(resolve => setTimeout(resolve, 3000)); // Increased delay for live calls
                    } catch (e) { console.warn(`Error prefetching FMP profile for ${ticker}:`, e); }
                }

                const quoteCacheKey = `${ticker.toUpperCase()}_quote`;
                const cachedQuote = await getFMPCacheFromDB(quoteCacheKey);
                if (cachedQuote && (Date.now() - cachedQuote.timestamp < FMP_QUOTE_CACHE_DURATION)) {
                    fetchedQuoteThisRun = true;
                } else {
                     try {
                        if(profileFetchedLive) await new Promise(resolve => setTimeout(resolve, 3000)); // Increased extra delay if profile was just live fetched
                        showStatus(`Prefetching FMP quote for ${ticker}... (${i+1}/${PREDEFINED_TICKERS_FOR_PREFETCH.length})`, 'info');
                        const quote = await fmpService.getQuoteFMP(ticker);
                        if (quote) fetchedQuoteThisRun = true;
                    } catch (e) { console.warn(`Error prefetching FMP quote for ${ticker}:`, e); }
                }
                
                if (fetchedProfileThisRun && fetchedQuoteThisRun) {
                    successCount++;
                    if (cachedProfile && cachedQuote && 
                        (Date.now() - (cachedProfile?.timestamp || 0) < FMP_PROFILE_CACHE_DURATION) &&
                        (Date.now() - (cachedQuote?.timestamp || 0) < FMP_QUOTE_CACHE_DURATION)) {
                        skippedCount++;
                    }
                } else {
                     setAllLoggedErrors(prev => [...prev, `[${new Date().toISOString()}] FMP Prefetch Warning for ${ticker}: Profile or Quote fetch failed/cache miss.`]);
                }

                if (i < PREDEFINED_TICKERS_FOR_PREFETCH.length - 1) {
                    await new Promise(resolve => setTimeout(resolve, 20000)); // Further increased delay between DIFFERENT tickers
                }
            }
            let finalMsg = `FMP prefetch: ${successCount}/${PREDEFINED_TICKERS_FOR_PREFETCH.length} tickers' data ensured.`;
            if (skippedCount > 0) finalMsg += ` (${skippedCount} used fresh cache).`;
            showStatus(finalMsg, successCount === PREDEFINED_TICKERS_FOR_PREFETCH.length ? 'success' : 'warning');
            setActiveInsightTab(InsightTabKey.Status);
        };
        prefetchFMPData();
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dbInitialized, sqliteDbInitialized]);


  useEffect(() => { if(dbInitialized && sqliteDbInitialized) savePlotOptionsToDB(plotOptions).then(() => sqliteService.savePlotOptionsToSQLite(plotOptions)); }, [plotOptions, dbInitialized, sqliteDbInitialized]);
  useEffect(() => { if(dbInitialized && sqliteDbInitialized) saveLegsToDB(legs).then(() => sqliteService.saveLegsToSQLite(legs)); }, [legs, dbInitialized, sqliteDbInitialized]);
  useEffect(() => { if(dbInitialized && sqliteDbInitialized) saveAppStateToDB(appDBState).then(() => sqliteService.saveAppStateToSQLite(appDBState));}, [appDBState, dbInitialized, sqliteDbInitialized]);
  useEffect(() => { if(dbInitialized && sqliteDbInitialized) saveGitHubSettingsToDB(githubSettings).then(() => sqliteService.saveGitHubSettingsToSQLite(githubSettings)); }, [githubSettings, dbInitialized, sqliteDbInitialized]);

  const closeGeneralStatusMessage = useCallback(() => setGeneralStatusMessage(null), []);
  const handleAddLeg = () => {
    if (legs.length < MAX_LEGS) {
      const newLegRole = `Custom Leg ${legs.length + 1}`;
      setLegs([...legs, { id: generateUniqueId(), type: OptionType.Call, action: Action.Buy, strike: '', premium: '', quantity: '1', role: newLegRole, premiumMissing: true }]);
    } else { showStatus(`Maximum of ${MAX_LEGS} legs reached.`, 'warning'); setActiveInsightTab(InsightTabKey.Status); }
  };
  const handleRemoveLeg = (id: string) => {
    setLegs(currentLegsInState => {
      const newLegs = currentLegsInState.filter(leg => leg.id !== id);
      if (newLegs.length === 0) setChartData(null);
      return newLegs;
    });
  };
  const handleLegChange = (id: string, field: keyof OptionLeg, value: string | OptionType | Action) => {
    setLegs(legs.map(leg => {
        if (leg.id === id) {
            const updatedLeg = { ...leg, [field]: value };
            if (field === 'premium') updatedLeg.premiumMissing = !value || parseFloat(value as string) <= 0;
            return updatedLeg;
        }
        return leg;
    }));
  };

  const handlePlotOptionsChange = useCallback((field: keyof PlotOptions, value: string | boolean) => {
    setPlotOptions(prev => {
        const newState = { ...prev, [field]: value };
        if (field === 'underlyingName' && typeof value === 'string' && value.trim() !== '') {
            const ticker = value.toUpperCase().trim();
            if(ticker !== (appDBState.lastUnderlyingForStrategySuggestions || '').toUpperCase()) {
                setCurrentAIStrategyInsights([]); 
                setSuggestedStrategyNamesForDropdown([]); 
                updateAppDBStateCallback({ 
                    currentAIStrategySuggestions: null,
                    lastUnderlyingForStrategySuggestions: ticker, 
                });
            }
        }
        return newState;
    });
  }, [appDBState.lastUnderlyingForStrategySuggestions, updateAppDBStateCallback]);


  const handleTriggerStockInsightModal = useCallback(async (stockSuggestion: StoredBullishStockSuggestion | HistoricalBullishSuggestionEntry, isHistorical: boolean) => {
    const tickerToUse = stockSuggestion.ticker;
    const currentPrice = isHistorical ? (stockSuggestion as HistoricalBullishSuggestionEntry).priceAtSuggestion : (stockSuggestion as StoredBullishStockSuggestion).currentPrice;
    setCurrentStockForInsightModal({ suggestion: stockSuggestion, isHistorical, deepDiveAnalysis: null, isLoadingDeepDive: true });
    setIsStockInsightModalOpen(true); setActiveInsightTab(InsightTabKey.Tickers); 
    
    if (plotOptions.underlyingName !== tickerToUse || (currentPrice && plotOptions.currentS !== currentPrice.toString())) {
        setPlotOptions(prev => ({ ...prev, underlyingName: tickerToUse, currentS: currentPrice?.toString() || '' }));
    }
    if (plotOptions.underlyingName !== tickerToUse) {
      updateAppDBStateCallback({ currentAIStrategySuggestions: null, lastUnderlyingForStrategySuggestions: tickerToUse });
    }

    const initialContext: StoredBullishStockSuggestion = { 
        id: stockSuggestion.id, 
        ticker: tickerToUse, 
        currentPrice: currentPrice, 
        reasoning: stockSuggestion.reasoning,
        projectedPriceChangePercentMin: stockSuggestion.projectedPriceChangePercentMin, 
        projectedPriceChangePercentMax: stockSuggestion.projectedPriceChangePercentMax,
        projectedTimeline: stockSuggestion.projectedTimeline, 
        priceCategory: stockSuggestion.priceCategory, 
        outlookHorizon: stockSuggestion.outlookHorizon,
        timestamp: isHistorical ? (stockSuggestion as HistoricalBullishSuggestionEntry).initialTimestamp : (stockSuggestion as StoredBullishStockSuggestion).timestamp,
        detailedReasoning: stockSuggestion.detailedReasoning,
        priceProjectionDetails: stockSuggestion.priceProjectionDetails,
        analysisTimestamp: stockSuggestion.analysisTimestamp,
        currentChartPatterns: stockSuggestion.currentChartPatterns,
        barPlayAnalysis: stockSuggestion.barPlayAnalysis,
        microstructureInsights: !isHistorical ? (stockSuggestion as StoredBullishStockSuggestion).microstructureInsights : undefined,
        covarianceConsiderations: !isHistorical ? (stockSuggestion as StoredBullishStockSuggestion).covarianceConsiderations : undefined,
        advancedModelReferences: !isHistorical ? (stockSuggestion as StoredBullishStockSuggestion).advancedModelReferences : undefined,
        dataComment: !isHistorical ? (stockSuggestion as StoredBullishStockSuggestion).dataComment : undefined,
    };
    const deepDiveResult = await fetchDeeperAnalysis(tickerToUse, currentPrice, initialContext);
    setCurrentStockForInsightModal(prev => prev ? ({ ...prev, deepDiveAnalysis: deepDiveResult, isLoadingDeepDive: false }) : null);
    
    if (deepDiveResult.error) { 
        showStatus(`Deeper analysis for ${tickerToUse} failed: ${deepDiveResult.error}. Displaying initial data. (FMP: ${deepDiveResult.fmpDataUsed ? 'Used' : 'Not Used'})`, 'warning', AICallType.BullishStocksDeepDive, deepDiveResult.durationMs);  
        setAllLoggedErrors(prev => [...prev, `[${new Date().toISOString()}] Deeper Analysis Error for ${tickerToUse}: ${deepDiveResult.error}`]);
    } else {
        const updatedStock: StoredBullishStockSuggestion = { 
            ...initialContext, 
            id: `${tickerToUse}-${Date.now()}`, 
            detailedReasoning: deepDiveResult.detailedReasoning || initialContext.detailedReasoning,
            priceProjectionDetails: deepDiveResult.priceProjectionDetails || initialContext.priceProjectionDetails,
            microstructureInsights: deepDiveResult.microstructureInsights || initialContext.microstructureInsights,
            covarianceConsiderations: deepDiveResult.covarianceConsiderations || initialContext.covarianceConsiderations,
            advancedModelReferences: deepDiveResult.advancedModelReferences || initialContext.advancedModelReferences,
            currentChartPatterns: deepDiveResult.currentChartPatterns || initialContext.currentChartPatterns,
            barPlayAnalysis: deepDiveResult.barPlayAnalysis || initialContext.barPlayAnalysis,
            analysisTimestamp: deepDiveResult.analysisTimestamp || Date.now(), 
            dataComment: deepDiveResult.dataComment || initialContext.dataComment,
        };
        const existingIdx = currentAIBullishStockInsights.findIndex(s => s.ticker === tickerToUse);
        let newCurrentInsights = [...currentAIBullishStockInsights];
        if(existingIdx > -1) newCurrentInsights[existingIdx] = updatedStock;
        else newCurrentInsights = [updatedStock, ...newCurrentInsights];
        
        updateAppDBStateCallback({ currentAIBullishStockSuggestions: newCurrentInsights });
        showStatus(`Deeper analysis for ${tickerToUse} complete. View in modal. (FMP: ${deepDiveResult.fmpDataUsed ? 'Used' : 'Not Used'})`, 'success', AICallType.BullishStocksDeepDive, deepDiveResult.durationMs);
    }
    await handleSuggestStrategiesFromPanel(tickerToUse);
  }, [currentAIBullishStockInsights, fetchDeeperAnalysis, showStatus, updateAppDBStateCallback, plotOptions.underlyingName, plotOptions.currentS]); 

   useEffect(() => {
    if (!plotOptions.underlyingName || plotOptions.underlyingName.trim() === '') return;
    const ticker = plotOptions.underlyingName.toUpperCase().trim();

    if (currentStockForInsightModal && currentStockForInsightModal.suggestion.ticker === ticker) {
        return;
    }

    const currentSuggestion = currentAIBullishStockInsights.find(s => s.ticker === ticker);
    if (currentSuggestion) {
        handleTriggerStockInsightModal(currentSuggestion, false);
        return; 
    }

    const historicalSuggestion = historicalBullishSuggestions.find(h => h.ticker === ticker);
    if (historicalSuggestion) {
        handleTriggerStockInsightModal(historicalSuggestion, true);
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [plotOptions.underlyingName]);


  const handleGeneratePlot = useCallback(() => {
    setIsLoadingPlot(true); setChartData(null);
    showStatus('Generating plot...', 'info'); setActiveInsightTab(InsightTabKey.Status);
    if (legs.length === 0) {
      showStatus('Please add at least one leg to plot.', 'warning'); setIsLoadingPlot(false); setActiveInsightTab(InsightTabKey.Status); return;
    }
    for (const leg of legs) {
      if (!leg.strike || !leg.premium || !leg.quantity) {
        showStatus('All leg fields (Strike, Premium, Quantity) are required for base plot.', 'warning'); setIsLoadingPlot(false); setActiveInsightTab(InsightTabKey.Status); return;
      }
    }
    
    let simParamsToUse: SimulationParams | undefined = undefined;
    if (isTTESimulationActive) {
        const currentS = parseFloat(plotOptions.currentS); const sigma = parseFloat(simulationSigmaInput); const r = parseFloat(simulationRInput);
        const tteYears = Math.max(0, currentSimulatedTTEDays / 365); 
        if (isNaN(currentS) || currentS <= 0) { showStatus('Current Stock Price for TTE sim must be positive.', 'warning'); setIsLoadingPlot(false); return; }
        if (isNaN(sigma) || sigma <= 0) { showStatus('Sim Volatility for TTE sim must be positive.', 'warning'); setIsLoadingPlot(false); return; }
        if (isNaN(r) || r < 0) { showStatus('Sim Risk-Free Rate for TTE sim must be non-negative.', 'warning'); setIsLoadingPlot(false); return; }
        simParamsToUse = { tte: tteYears, sigma, r, currentS };
    }

    setTimeout(() => {
        const result = generatePlotData(legs, plotOptions, simParamsToUse);
        if ('error' in result) { showStatus(`Error: ${result.error}`, 'error'); setChartData(null); } 
        else { 
          setChartData(result); 
          let successMsg = `Plot for: ${result.strategyTitleShort || 'Strategy'}. Range: ${result.minSTPlot.toFixed(2)}-${result.maxSTPlot.toFixed(2)}`;
          if (simParamsToUse) successMsg += ` (Sim TTE: ${currentSimulatedTTEDays} days)`;
          showStatus(successMsg, 'success');
        }
        setIsLoadingPlot(false); setActiveInsightTab(InsightTabKey.Status);
    }, 100);
  }, [legs, plotOptions, showStatus, isTTESimulationActive, simulationSigmaInput, simulationRInput, currentSimulatedTTEDays]); 

  const handleClearForm = useCallback(() => {
    setLegs(addDefaultLeg());
    const defaultPlotOpts: PlotOptions = {
        id: SINGLE_ITEM_KEY, underlyingName: 'SPY', currentS: '', pointValue: DEFAULT_POINT_VALUE,
        minST: '', maxST: '', numPoints: DEFAULT_NUM_POINTS, showIndividualLegs: true,
        initialTTEForSimulation: 45 / 365, simulationSigma: '0.20', simulationR: '0.05'
    };
    setPlotOptions(defaultPlotOpts);
    setCurrentSimulatedTTEDays(Math.max(0, Math.round((defaultPlotOpts.initialTTEForSimulation || 45/365) * 365)));
    setSimulationSigmaInput(defaultPlotOpts.simulationSigma || '0.20');
    setSimulationRInput(defaultPlotOpts.simulationR || '0.05');
    setIsTTESimulationActive(false); setChartData(null); setSelectedStrategyName(PREDEFINED_STRATEGIES[0].name);
    setCurrentAIStrategyInsights([]); setSuggestedStrategyNamesForDropdown([]); setCurrentAIBullishStockInsights([]);
    setOptionsChainForModal(null); setTargetStrikesForModal(null); setCurrentStockPriceForModalChain(null);
    setGeneralStatusMessage(null); setAllLoggedErrors([]); setCurrentStockForInsightModal(null); setIsStockInsightModalOpen(false);
    updateAppDBStateCallback({
        selectedStrategyName: PREDEFINED_STRATEGIES[0].name, currentAIStrategySuggestions: null,
        lastUnderlyingForStrategySuggestions: null, currentAIBullishStockSuggestions: null,
        activeInsightTab: InsightTabKey.Status, aiCallDurations: {}, showAnalyticsPanel: appDBState.showAnalyticsPanel,
    });
    showStatus('Form cleared. Underlying, strategy and AI suggestions reset.', 'info'); setActiveInsightTab(InsightTabKey.Status);
  }, [addDefaultLeg, showStatus, updateAppDBStateCallback, appDBState.showAnalyticsPanel]);

  const handleStrategySelectChange = useCallback(async (strategyName: string, autoFetchLiveData = false, underlyingForFetch?: string) => {
    setSelectedStrategyName(strategyName); updateAppDBStateCallback({ selectedStrategyName: strategyName });
    const strategy = PREDEFINED_STRATEGIES.find(s => s.name === strategyName);
    setOptionsChainForModal(null); setTargetStrikesForModal(null); setCurrentStockPriceForModalChain(null); setIsTTESimulationActive(false);
    const currentUnderlying = underlyingForFetch || plotOptions.underlyingName;

    if (strategy && strategy.legs.length > 0) {
      const newLegs = strategy.legs.map((legDef: StrategyLegDefinition) => ({
        id: generateUniqueId(), type: legDef.type, action: legDef.action,
        strike: '', premium: '', quantity: legDef.quantity.toString(), role: legDef.role, premiumMissing: true,
      }));
      if (newLegs.length > MAX_LEGS) { showStatus(`Strategy has ${newLegs.length} legs, > max ${MAX_LEGS}. Truncating.`, 'warning'); setLegs(newLegs.slice(0, MAX_LEGS)); } 
      else { setLegs(newLegs); }
      if (autoFetchLiveData) {
        showStatus(`Applying '${strategy.name}' for ${currentUnderlying}. Auto-fetching FMP & AI data...`, 'info', AICallType.StrategyData);
        setActiveInsightTab(InsightTabKey.Status);
        const tempPlotOptions = {...plotOptions, underlyingName: currentUnderlying};
        await handleFetchLiveData(tempPlotOptions, strategy.name);
      } else { showStatus(`Loaded '${strategy.name}'. Fill strikes/premiums or fetch data. Fields cleared.`, 'info'); setActiveInsightTab(InsightTabKey.Status); }
    } else if (strategyName === PREDEFINED_STRATEGIES[0].name) setLegs(addDefaultLeg());
  }, [showStatus, addDefaultLeg, updateAppDBStateCallback, plotOptions]); 

  const handleFetchLiveData = useCallback(async (currentPlotOptionsOverride?: PlotOptions, strategyToFetch?: string) => {
    const currentPlotOptionsToUse = currentPlotOptionsOverride || plotOptions;
    const currentStrategyName = strategyToFetch || selectedStrategyName;
    if (!currentPlotOptionsToUse.underlyingName) { showStatus('Enter Underlying Name to fetch data.', 'warning'); return; }
    const currentStrategy = PREDEFINED_STRATEGIES.find(s => s.name === currentStrategyName);
    if (!currentStrategy || currentStrategy.legs.length === 0) { showStatus('Select valid strategy to fetch data.', 'warning'); return; }

    setOptionsChainForModal(null); setTargetStrikesForModal(null); setCurrentStockPriceForModalChain(null); setIsTTESimulationActive(false);
    const legRolesDescription = currentStrategy.legs.map(leg => `- ${leg.role} (Type: ${leg.type}, Action: ${leg.action}, Qty: ${leg.quantity})`).join('\n');
    
    const result = await fetchStrategyData(currentPlotOptionsToUse.underlyingName, currentStrategy.name, legRolesDescription);
    
    let baseMsg = `Data for ${currentPlotOptionsToUse.underlyingName} - ${currentStrategy.name} (FMP:${result.fmpDataUsed ? 'Used' : 'Not Used'}).`;
    let details = ""; let allDataFound = true; let premiumsPopulated = true;
    let newPlotOptsForState = { ...currentPlotOptionsToUse };

    if (result.error) { showStatus(result.error, 'error', AICallType.StrategyData, result.durationMs); } 
    else {
        if (result.suggestedPointValue !== null && result.suggestedPointValue !== undefined) { newPlotOptsForState.pointValue = result.suggestedPointValue!.toString(); details += ` Point value: ${result.suggestedPointValue}.`; }
        if (result.suggestedNumPoints !== null && result.suggestedNumPoints !== undefined) { newPlotOptsForState.numPoints = result.suggestedNumPoints!.toString(); details += ` Plot points: ${result.suggestedNumPoints}.`; }
        if (result.currentStockPrice !== null && result.currentStockPrice !== undefined) { newPlotOptsForState.currentS = result.currentStockPrice!.toString(); } 
        else { details += " Current stock price not found."; allDataFound = false; }
        
        const chainToUse = result.optionsChain; 
        if (chainToUse?.expirationDate) {
            const today = new Date(); const expDate = new Date(chainToUse.expirationDate); expDate.setUTCHours(0,0,0,0); today.setUTCHours(0,0,0,0);
            const diffDays = Math.max(0, Math.ceil((expDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24)));
            newPlotOptsForState.initialTTEForSimulation = diffDays >= 0 ? diffDays / 365 : (0 / 365);
            setCurrentSimulatedTTEDays(diffDays); details += ` Options expire in ${diffDays} days.`;
        } else { newPlotOptsForState.initialTTEForSimulation = 45/365; setCurrentSimulatedTTEDays(45); }
        setPlotOptions(newPlotOptsForState); 

        if (chainToUse) { setOptionsChainForModal(chainToUse); setCurrentStockPriceForModalChain(chainToUse.currentStockPriceForChain || result.currentStockPrice || null); }
        if (result.targetStrikesByRole) setTargetStrikesForModal(result.targetStrikesByRole);

        setLegs(currentLegs => {
            const strategyDef = PREDEFINED_STRATEGIES.find(s => s.name === currentStrategyName);
            if (!strategyDef) return currentLegs;
            const baseLegs = strategyDef.legs.map(def => ({id: generateUniqueId(), ...def, quantity: def.quantity.toString(), strike: '', premium: '', premiumMissing: true}));
            if (chainToUse && result.targetStrikesByRole) {
                return baseLegs.map(uiLeg => {
                    const targetInfo = result.targetStrikesByRole!.find(ts => ts.role === uiLeg.role);
                    let finalStrike = '', finalPremium = ''; let missing = true;
                    if (targetInfo && targetInfo.targetStrike !== null) {
                        const chainList = uiLeg.type === OptionType.Call ? chainToUse.calls : chainToUse.puts;
                        let match = chainList.find(o => o.strike === targetInfo!.targetStrike) || chainList.reduce((p,c) => Math.abs(c.strike-targetInfo!.targetStrike!) < Math.abs(p.strike-targetInfo!.targetStrike!) ? c : p, chainList[0]);
                        if (match) {
                            finalStrike = match.strike.toString();
                            let prem = uiLeg.action === Action.Buy ? (match.ask ?? match.mid ?? match.last) : (match.bid ?? match.mid ?? match.last);
                            if (prem !== null && prem !== undefined && prem > 0) { finalPremium = prem.toString(); missing = false; }
                            else { details += ` Premium for ${uiLeg.role} (K:${finalStrike}) invalid/zero.`; premiumsPopulated = false; } 
                        } else { details += ` No match for ${uiLeg.role} (Target K:${targetInfo.targetStrike}) in provided chain.`; allDataFound = false; premiumsPopulated = false; }
                    } else { details += ` Target strike for '${uiLeg.role}' not suggested by AI.`; allDataFound = false; premiumsPopulated = false; }
                    return { ...uiLeg, strike: finalStrike, premium: finalPremium, premiumMissing: missing };
                });
            } else { details += " Options chain or AI target strikes missing. Legs not auto-filled."; allDataFound = false; premiumsPopulated = false; return baseLegs; }
        });
        if (result.dataComment) baseMsg += ` AI Note: ${result.dataComment}`;
        let finalMsg = baseMsg + (details ? ` Details:${details}` : "");
        if (!premiumsPopulated && chainToUse && (chainToUse.calls.length > 0 || chainToUse.puts.length > 0)) { finalMsg += " Some premiums not auto-filled. Use Chain modal."; }
        else if (!chainToUse) { finalMsg += " Options chain not available. Enter premiums manually."; }
        showStatus(finalMsg, allDataFound ? 'success' : 'warning', AICallType.StrategyData, result.durationMs);
        if (!premiumsPopulated && chainToUse && (chainToUse.calls.length > 0 || chainToUse.puts.length > 0)) setIsOptionsChainModalOpen(true);
    }
  }, [plotOptions, selectedStrategyName, fetchStrategyData, showStatus]); 

  const handleModalPremiumSelect = useCallback((legIdToUpdate: string, premium: number, strikePrice: number, optionType: OptionType) => {
    setLegs(prevLegs => prevLegs.map(leg => {
            if (leg.id === legIdToUpdate) {
                const updatedLeg = { ...leg, premium: premium.toFixed(2), premiumMissing: false };
                if (leg.strike !== strikePrice.toString() || leg.type !== optionType) {
                    updatedLeg.strike = strikePrice.toString(); updatedLeg.type = optionType;
                    showStatus(`Leg (${leg.role || legIdToUpdate}) updated: K to ${strikePrice}, Type to ${optionType}, Prem to ${premium.toFixed(2)}.`, 'success');
                } else { showStatus(`Premium for Leg (${leg.role || legIdToUpdate}) updated to ${premium.toFixed(2)} from chain.`, 'success'); }
                setActiveInsightTab(InsightTabKey.Status); return updatedLeg;
            } return leg;
        }));
  }, [showStatus]); 
  const handleOpenChainForLeg = useCallback((legId: string, currentStrike: string, optionType: OptionType) => {
    if (!optionsChainForModal) { showStatus("Chain data not fetched. Use 'Fetch Live Data' first.", 'warning'); return; }
    setModalPrimingLeg({ legId, strike: currentStrike, optionType }); setIsOptionsChainModalOpen(true);
  }, [optionsChainForModal, showStatus]);

  const handleExplainStrategyFromPanel = async (strategyNameToExplain?: string) => {
    const stratName = strategyNameToExplain || selectedStrategyName;
    if (!stratName || stratName === PREDEFINED_STRATEGIES[0].name) return;
    setActiveInsightTab(InsightTabKey.Strategies);
    const explanationResult = await fetchStrategyExplanation(stratName);
    if (explanationResult.error) { showStatus(`Error fetching explanation: ${explanationResult.error}`, 'error', AICallType.StrategyExplanation, explanationResult.durationMs); } 
    else if (explanationResult.text) {
      const newInsight: StoredAISuggestion = { id: `${plotOptions.underlyingName}-${stratName}-manualexplain-${Date.now()}`, underlyingName: plotOptions.underlyingName, name: stratName, reasoning: explanationResult.text, timestamp: Date.now() };
      updateAppDBStateCallback({ currentAIStrategySuggestions: [newInsight, ...currentAIStrategyInsights.filter(s => s.name !== stratName || s.underlyingName !== plotOptions.underlyingName)], activeInsightTab: InsightTabKey.Strategies });
      showStatus(`Explanation for ${stratName} loaded.`, 'success', AICallType.StrategyExplanation, explanationResult.durationMs);
    } else { showStatus(`No explanation found for ${stratName}.`, 'warning', AICallType.StrategyExplanation, explanationResult.durationMs); }
  };
  const handleSuggestStrategiesFromPanel = async (underlyingForSuggestions: string) => {
    if (!underlyingForSuggestions) { showStatus('Underlying Name required for AI strategy suggestions.', 'warning'); return; }
    updateAppDBStateCallback({ currentAIStrategySuggestions: [], activeInsightTab: InsightTabKey.Strategies });
    const result = await fetchAISuggestStrategies(underlyingForSuggestions);
    updateAppDBStateCallback({ lastUnderlyingForStrategySuggestions: underlyingForSuggestions });
    if (result.error) { showStatus(`Error fetching AI suggestions: ${result.error}`, 'error', AICallType.StrategySuggestions, result.durationMs); updateAppDBStateCallback({ currentAIStrategySuggestions: null, activeInsightTab: InsightTabKey.Status }); } 
    else if (result.suggestedStrategies && result.suggestedStrategies.length > 0) {
        const storedSuggestions: StoredAISuggestion[] = result.suggestedStrategies.map(s => ({ id: `${underlyingForSuggestions}-${s.name}-${Date.now()}`, underlyingName: underlyingForSuggestions, ...s, timestamp: Date.now() })).sort((a, b) => (a.rank || 99) - (b.rank || 99));
        updateAppDBStateCallback({ currentAIStrategySuggestions: storedSuggestions, activeInsightTab: InsightTabKey.Strategies });
        let message = `AI suggested for ${underlyingForSuggestions}: ${storedSuggestions.map(s => `${s.name} (Rank:${s.rank || 'N/A'})`).join(', ')}. '${storedSuggestions[0].name}' selected. View details in 'Strategy Insights' tab. (FMP: ${result.fmpDataUsed ? 'Used' : 'Not Used'})`;
        if(result.dataComment) message += ` AI Note: ${result.dataComment}`;
        showStatus(message, 'success', AICallType.StrategySuggestions, result.durationMs); 
        await handleStrategySelectChange(storedSuggestions[0].name, true, underlyingForSuggestions);
    } else { showStatus(`AI found no specific strategy suggestions for ${underlyingForSuggestions}. (FMP: ${result.fmpDataUsed ? 'Used' : 'Not Used'})`, 'warning', AICallType.StrategySuggestions, result.durationMs); updateAppDBStateCallback({ currentAIStrategySuggestions: null, activeInsightTab: InsightTabKey.Status }); }
  };
  const handleApplyAIStrategySuggestion = async (suggestion: StoredAISuggestion) => {
    showStatus(`Applying AI suggestion: ${suggestion.name} for ${suggestion.underlyingName}...`, 'info');
    setActiveInsightTab(InsightTabKey.Status);
    const newPlotOptions = {...plotOptions, underlyingName: suggestion.underlyingName.toUpperCase(), currentS: ''};
    setPlotOptions(newPlotOptions); 
    await handleStrategySelectChange(suggestion.name, true, suggestion.underlyingName);
  };
  
  const handleSuggestBullishStocksFromPanel = async () => {
    setActiveInsightTab(InsightTabKey.Tickers);
    const result = await fetchAIBullishStocks();
    if (result.error) { 
        showStatus(`Error fetching bullish stocks: ${result.error.includes("PERMISSION_DENIED") || result.error.includes("403") ? `This feature may be unavailable due to service access restrictions. AI reported: "${result.error}"` : result.error} (FMP: ${result.fmpDataUsed ? 'Used' : 'Not Used'})`, 'error', AICallType.BullishStocksInitial, result.durationMs);
        updateAppDBStateCallback({ activeInsightTab: InsightTabKey.Status });
    } else if (result.suggestedStocks && result.suggestedStocks.length > 0) {
        const currentTimestamp = Date.now();
        const newStored: StoredBullishStockSuggestion[] = result.suggestedStocks.map(s => ({ ...s, ticker: s.ticker.toUpperCase(), id: `${s.ticker}-${currentTimestamp}`, timestamp: currentTimestamp }));
        const historicalEntries: HistoricalBullishSuggestionEntry[] = newStored.map(s => ({ id: s.id, ticker: s.ticker, priceAtSuggestion: s.currentPrice, initialTimestamp: s.timestamp, projectedPriceChangePercentMin: s.projectedPriceChangePercentMin, projectedPriceChangePercentMax: s.projectedPriceChangePercentMax, projectedTimeline: s.projectedTimeline, priceCategory: s.priceCategory, outlookHorizon: s.outlookHorizon, reasoning: s.reasoning }));
        try {
            for (const entry of historicalEntries) { 
                await saveHistoricalBullishSuggestionToDB(entry);
                if (sqliteDbInitialized) await sqliteService.saveHistoricalBullishSuggestionToSQLite(entry);
            }
            const updatedHistorical = await getHistoricalBullishSuggestionsFromDB(); 
            setHistoricalBullishSuggestions(updatedHistorical.sort((a,b) => b.initialTimestamp - a.initialTimestamp));
            showStatus(`Saved ${historicalEntries.length} new suggestions to history.`, 'info');
        } catch (dbError) { console.error("Error saving historical suggestions:", dbError); showStatus(`Error saving suggestions to history: ${dbError instanceof Error ? dbError.message : String(dbError)}`, 'error'); }
        updateAppDBStateCallback({ currentAIBullishStockSuggestions: newStored, lastFetchedBullishStocksTimestamp: currentTimestamp, activeInsightTab: InsightTabKey.Tickers });
        let message = `AI suggested bullish underlyings (${newStored.length}). View in 'Ticker Insights'. Click to apply & get detailed analysis. (FMP: ${result.fmpDataUsed ? 'Used' : 'Not Used'})`;
        if(result.dataComment) message += ` AI Note: ${result.dataComment}`;
        showStatus(message, 'success', AICallType.BullishStocksInitial, result.durationMs); 
    } else { showStatus(`AI found no specific bullish stock suggestions. (FMP: ${result.fmpDataUsed ? 'Used' : 'Not Used'})`, 'warning', AICallType.BullishStocksInitial, result.durationMs); updateAppDBStateCallback({ currentAIBullishStockSuggestions: null, activeInsightTab: InsightTabKey.Status }); }
  };

  const handleSetHistoricalContextForStrategy = async (historicalSuggestion: HistoricalBullishSuggestionEntry, historicalOptionPlay: GeminiSuggestedHistoricalOption | null) => {
    setPlotOptions(prev => ({
        ...prev,
        underlyingName: historicalSuggestion.ticker,
        currentS: historicalSuggestion.priceAtSuggestion?.toString() || '',
    }));
    
    showStatus(`Main config updated to historical context: ${historicalSuggestion.ticker} at $${historicalSuggestion.priceAtSuggestion?.toFixed(2) || 'N/A'}.`, 'info');
    setActiveInsightTab(InsightTabKey.Status);

    if (historicalOptionPlay && historicalOptionPlay.legs && historicalOptionPlay.legs.length > 0) {
        const newUILegs: OptionLeg[] = historicalOptionPlay.legs.map(aiLeg => {
            let premiumValue = "0.00";
            let premiumIsMissing = true;
            // Use estimatedNetCostOrCredit if it's a single leg strategy and makes sense.
            // This is a simplification; for spreads, individual leg premiums are needed.
            // The AI prompt was updated to ask for estimatedPremiumPerLeg, but that's not in GeminiSuggestedHistoricalOption yet.
            // For now, we'll assume the user needs to verify/adjust premiums for multi-leg.
            // If it's a single leg and estimatedNetCostOrCredit is available:
            if (historicalOptionPlay.legs!.length === 1 && historicalOptionPlay.estimatedNetCostOrCredit !== undefined && historicalOptionPlay.estimatedNetCostOrCredit !== null) {
                if (aiLeg.action === Action.Buy && historicalOptionPlay.estimatedNetCostOrCredit < 0) {
                    premiumValue = Math.abs(historicalOptionPlay.estimatedNetCostOrCredit).toFixed(2);
                    premiumIsMissing = false;
                } else if (aiLeg.action === Action.Sell && historicalOptionPlay.estimatedNetCostOrCredit > 0) {
                    premiumValue = historicalOptionPlay.estimatedNetCostOrCredit.toFixed(2);
                    premiumIsMissing = false;
                } else if (historicalOptionPlay.estimatedNetCostOrCredit === 0) {
                    premiumValue = "0.00"; 
                    premiumIsMissing = false;
                } else {
                    // If action and sign of cost/credit don't match, it's ambiguous or AI implies free trade
                    premiumValue = "0.01"; // Default for buy if no good estimate
                    premiumIsMissing = true;
                }
            } else { // Multi-leg or no estimatedNetCostOrCredit
                 premiumValue = aiLeg.action === Action.Buy ? "0.01" : "0.00"; // Placeholder for multi-leg or missing premium
                 premiumIsMissing = true;
            }

            return {
                id: generateUniqueId(),
                type: aiLeg.type,
                action: aiLeg.action,
                strike: aiLeg.strike.toString(),
                premium: premiumValue,
                quantity: "1", // Default quantity
                role: aiLeg.role || `AI Hist Leg ${aiLeg.type} ${aiLeg.strike}`,
                premiumMissing: premiumIsMissing,
            };
        });
        setLegs(newUILegs);
        setSelectedStrategyName("AI Historical Play"); // Custom name
        updateAppDBStateCallback({selectedStrategyName: "AI Historical Play"});
        showStatus(`AI's historical option play for ${historicalSuggestion.ticker} applied to legs. Review premiums.`, 'info');
        handleGeneratePlot(); // Regenerate plot with new legs and historical context
    } else if (selectedStrategyName !== PREDEFINED_STRATEGIES[0].name) {
        showStatus(`Attempting to apply current strategy '${selectedStrategyName}' to this historical context...`, 'info');
        const newPlotOptions = {...plotOptions, underlyingName: historicalSuggestion.ticker, currentS: historicalSuggestion.priceAtSuggestion?.toString() || ''};
        await handleFetchLiveData(newPlotOptions, selectedStrategyName);
    } else {
        setLegs(addDefaultLeg());
        setSelectedStrategyName(PREDEFINED_STRATEGIES[0].name);
        updateAppDBStateCallback({selectedStrategyName: PREDEFINED_STRATEGIES[0].name});
        showStatus(`Historical context set. Select or define a strategy for ${historicalSuggestion.ticker}.`, 'info');
    }
};

  const handleExportData = async () => {
    setIsExporting(true); showStatus('Preparing data for export...', 'info'); setActiveInsightTab(InsightTabKey.Status);
    try {
        const allData = await getAllDataForExport();
        let dataToExport = JSON.stringify(allData, null, 2);
        let fileName = githubSettings.filePath || 'option_plotter_config.json';
        let contentType = 'application/json';
        let finalData: Uint8Array | string = dataToExport;

        if (dataToExport.length > 100000) { 
            try {
                const dataToCompress = new TextEncoder().encode(dataToExport);
                const compressedData = compressSync(dataToCompress); 
                finalData = compressedData;
                fileName += '.gz';
                contentType = 'application/gzip';
                showStatus('Data compressed for export.', 'info');
            } catch (compressionError) {
                console.error("Compression error:", compressionError);
                showStatus(`Compression failed: ${compressionError instanceof Error ? compressionError.message : String(compressionError)}. Exporting raw data.`, 'warning');
            }
        }

        if (githubSettings.pat && githubSettings.username && githubSettings.repoName && githubSettings.filePath) {
            showStatus(`Simulating export to GitHub: ${githubSettings.username}/${githubSettings.repoName}/${fileName}. Check console for data.`, 'success');
            console.log("SIMULATED GITHUB EXPORT: Data to be pushed:", finalData instanceof Uint8Array ? "[Uint8Array]" : finalData.substring(0, 1000));
        } else {
            showStatus('GitHub settings incomplete for direct export. Downloading file instead.', 'warning');
            const blob = new Blob([finalData], { type: contentType });
            const url = URL.createObjectURL(blob); const a = document.createElement('a');
            a.href = url; a.download = fileName; document.body.appendChild(a); a.click(); document.body.removeChild(a); URL.revokeObjectURL(url);
            showStatus(`Data downloaded as ${fileName}.`, 'success');
        }
    } catch (error) {
        const errorMsg = error instanceof Error ? error.message : String(error);
        showStatus(`Error during export: ${errorMsg}`, 'error');
        setAllLoggedErrors(prev => [...prev, `[${new Date().toISOString()}] Export Error: ${errorMsg}`]);
    } finally { setIsExporting(false); setActiveInsightTab(InsightTabKey.Status); }
  };

  const handleCopyErrorsToClipboard = async () => {
    if (allLoggedErrors.length === 0) { showStatus("No errors to copy.", "info"); return; }
    try {
      await navigator.clipboard.writeText(allLoggedErrors.join("\n\n"));
      showStatus("Error log copied to clipboard.", "success");
    } catch (err) {
      showStatus("Failed to copy errors. See console.", "error");
      console.error("Failed to copy errors to clipboard:", err);
    }
  };

  const toggleSection = (setter: React.Dispatch<React.SetStateAction<boolean>>, dbField?: keyof AppDBState) => {
      setter(prev => {
          const newState = !prev;
          if (dbField) updateAppDBStateCallback({ [dbField]: newState });
          return newState;
      });
  };


  const renderBullishStockList = () => {
    if (!currentAIBullishStockInsights || currentAIBullishStockInsights.length === 0) return null;
    
    const renderCategory = (stocks: StoredBullishStockSuggestion[], title: string, categoryColor: string, iconColor: string, highlightColor: string) => {
        if (stocks.length === 0) return null;
        return (
            <div className="mb-3">
                <h4 className={`text-xs font-bold mb-1.5 text-center underline decoration-wavy`} style={{color: categoryColor, textDecorationColor: highlightColor}}>{title}</h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2">
                    {stocks.map(stock => (
                        <div key={stock.id} className={`p-2.5 border rounded-lg shadow-sm hover:shadow-md transition-shadow duration-200`} style={{borderColor: highlightColor, backgroundColor: `${highlightColor}1A`}}>
                            <button
                                onClick={() => handleTriggerStockInsightModal(stock, false)}
                                disabled={anyAppLoading}
                                title={stock.reasoning || `View detailed analysis for ${stock.ticker}`}
                                className={`block w-full text-left font-semibold disabled:opacity-60 transition-all truncate flex items-center text-sm hover:opacity-80`}
                                style={{color: categoryColor}}
                            >
                                {stock.outlookHorizon === OutlookHorizon.ShortTerm && <BrainIcon className="w-3.5 h-3.5 mr-1 inline-block" style={{color: iconColor}}/>}
                                {stock.ticker} {stock.currentPrice ? `(${stock.currentPrice.toFixed(2)})` : ''}
                                {stock.outlookHorizon === OutlookHorizon.ShortTerm && <span className="ml-0.5" style={{color: iconColor}}>⚡️</span>}
                                {currentStockForInsightModal?.isLoadingDeepDive && currentStockForInsightModal.suggestion.ticker === stock.ticker && <LoadingSpinner className="h-3 w-3 inline-block ml-1.5" />}
                            </button>
                            {(stock.projectedPriceChangePercentMin !== null && stock.projectedPriceChangePercentMin !== undefined) || (stock.projectedPriceChangePercentMax !== null && stock.projectedPriceChangePercentMax !== undefined) ? (
                                <p className={`text-xs mt-0.5 font-semibold`} style={{color: OREGON_GREEN}}>
                                    📈 +{stock.projectedPriceChangePercentMin ?? '?'}% to +{stock.projectedPriceChangePercentMax ?? '?'}%
                                </p>
                            ) : null}
                            {stock.projectedTimeline && (
                                <p className={`text-xs mt-0.5`} style={{color: categoryColor}}>
                                    ⏳ {stock.projectedTimeline}
                                </p>
                            )}
                            {stock.reasoning && (
                                <button
                                    onClick={() => setReasoningModalInfo({ title: `Reasoning for ${stock.ticker}`, reasoning: stock.reasoning || "" })}
                                    className={`mt-1 hover:underline text-[0.7rem] p-0 focus:outline-none`}
                                    style={{color: categoryColor, opacity: 0.85}}
                                    title="Read full reasoning"
                                >
                                    Read Initial Insight...
                                </button>
                            )}
                        </div>
                    ))}
                </div>
            </div>
        );
    };

    const shortTerm = currentAIBullishStockInsights.filter(s => s.outlookHorizon === OutlookHorizon.ShortTerm);
    const midTerm = currentAIBullishStockInsights.filter(s => s.outlookHorizon === OutlookHorizon.MidTerm);
    const longTerm = currentAIBullishStockInsights.filter(s => s.outlookHorizon === OutlookHorizon.LongTerm);

    return (
      <div className="p-3 sm:p-4 border rounded-lg space-y-2 max-h-[350px] overflow-y-auto mb-6 shadow-inner" style={{backgroundColor: `${DUKE_BLUE}0D`, borderColor: `${DUKE_BLUE}33`}}>
            <p className="text-sm font-bold mb-2 text-center sticky top-0 py-1 z-10" style={{color: DUKE_BLUE, backgroundColor: `${DUKE_BLUE}1A`}}>AI Suggested Bullish Tickers (Click for Chart & Deeper Analysis)</p>
            {renderCategory(shortTerm, "⚡️ Short-Term Outlook (< 1 Week)", STANFORD_CARDINAL_RED, STANFORD_CARDINAL_RED, STANFORD_CARDINAL_RED)}
            {renderCategory(midTerm, "⏳ Mid-Term Outlook (1-6 Weeks)", DUKE_BLUE, DUKE_BLUE, DUKE_BLUE)}
            {renderCategory(longTerm, "🗓️ Long-Term Outlook (1-6+ Months)", OREGON_GREEN, OREGON_GREEN, OREGON_GREEN)}
        </div>
    );
  };


  return (
    <div className="min-h-screen p-3 sm:p-4 md:p-6 lg:p-8 font-sans" style={{backgroundColor: LIGHT_NEUTRAL_BACKGROUND, color: TEXT_COLOR_PRIMARY}}>
      <header className="mb-6 sm:mb-8 text-center">
        <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-[#003087] via-[#001A57] to-[#000F33]"> 
          Advanced Option Strategy Visualizer
        </h1>
        <p className="text-sm sm:text-md mt-1.5" style={{color: TEXT_COLOR_SECONDARY}}>Plot payoff diagrams, analyze strategies with AI, and explore market data.</p>
      </header>

      <div className="max-w-screen-2xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1 space-y-6">
            <InsightsPanel 
                activeTab={activeInsightTab} setActiveTab={(tab) => updateAppDBStateCallback({ activeInsightTab: tab })}
                generalStatusMessage={generalStatusMessage} onCloseGeneralStatus={closeGeneralStatusMessage}
                bullishStockInsights={currentAIBullishStockInsights} strategyInsights={currentAIStrategyInsights}
                historicalBullishSuggestions={historicalBullishSuggestions} allLoggedErrors={allLoggedErrors}
                onOpenReasoningModal={setReasoningModalInfo}
                isLoading={anyAppLoading}
                onApplyAIStrategySuggestion={handleApplyAIStrategySuggestion}
                onTriggerStockInsightModal={handleTriggerStockInsightModal}
                onCopyErrorsToClipboard={handleCopyErrorsToClipboard}
                currentStockForInsightModal={currentStockForInsightModal}
                plotOptions={plotOptions} // Pass plotOptions
                currentAIBullishStockSuggestions={currentAIBullishStockInsights} // Pass currentAIBullishStockSuggestions
            />
             <button onClick={() => handleSuggestBullishStocksFromPanel()}
                disabled={anyAppLoading || isFetchingAIBullishStocks}
                style={{backgroundColor: OREGON_GREEN}}
                className="w-full flex items-center justify-center text-white text-sm font-medium py-2.5 px-3 rounded-xl shadow-lg disabled:opacity-50 transition-all duration-150 ease-in-out hover:opacity-90 active:scale-98 active:brightness-95 mb-0"
            >
                {isFetchingAIBullishStocks ? <LoadingSpinner className="h-4 w-4 mr-2"/> : <BullishIcon className="mr-1.5 w-4 h-4"/>}
                {isFetchingAIBullishStocks ? 'AI Finding Stocks...' : 'AI Suggest Bullish Underlyings (Initial Scan)'}
            </button>
            {currentAIBullishStockInsights && currentAIBullishStockInsights.length > 0 && renderBullishStockList()}

            <PanelSection title="Strategy Configuration" isVisible={showConfiguration} onToggle={() => toggleSection(setShowConfiguration)} titleIcon={<ChartIcon/>}>
                 <ConfigurationPanel
                    plotOptions={plotOptions} onPlotOptionsChange={handlePlotOptionsChange}
                    selectedStrategyName={selectedStrategyName} onStrategySelectChange={handleStrategySelectChange}
                    suggestedStrategyNamesForDropdown={suggestedStrategyNamesForDropdown}
                    appDBState={appDBState} currentAIStrategyInsights={currentAIStrategyInsights}
                    historicalBullishSuggestions={historicalBullishSuggestions}
                    onApplyAIStrategySuggestion={handleApplyAIStrategySuggestion} 
                    onSetReasoningModalInfo={setReasoningModalInfo}
                    onSuggestStrategies={handleSuggestStrategiesFromPanel} 
                    onFetchLiveData={handleFetchLiveData} onExplainStrategy={handleExplainStrategyFromPanel}
                    isFetchingAIStrategySuggestions={isFetchingAIStrategySuggestions} 
                    isFetchingLiveData={isFetchingStrategyData} isFetchingStrategyExplanation={isFetchingStrategyExplanation}
                    anyAppLoading={anyAppLoading} 
                    onTriggerStockInsightModal={handleTriggerStockInsightModal} // Pass prop
                />
            </PanelSection>
            <PanelSection title={`Option Legs (${legs.length}/${MAX_LEGS})`} isVisible={showOptionLegs} onToggle={() => toggleSection(setShowOptionLegs)} titleIcon={<WalletIcon/>}>
                <OptionLegsPanel legs={legs} onLegChange={handleLegChange} onAddLeg={handleAddLeg} onRemoveLeg={handleRemoveLeg} onOpenChainForLeg={handleOpenChainForLeg} optionsChainForModal={optionsChainForModal} anyAppLoading={anyAppLoading} />
            </PanelSection>
        </div>

        <div className="lg:col-span-2 space-y-6">
          <PayoffChart chartData={chartData} showIndividualLegs={plotOptions.showIndividualLegs} />
          
            {showTTESimulation && (
                <PanelSection title="TTE Simulation" isVisible={showTTESimulation} onToggle={() => toggleSection(setShowTTESimulation)}>
                    <TTESimulationPanel
                        plotOptions={plotOptions} currentSimulatedTTEDays={currentSimulatedTTEDays}
                        simulationSigmaInput={simulationSigmaInput} simulationRInput={simulationRInput}
                        isTTESimulationActive={isTTESimulationActive}
                        onToggleTTESimulation={() => { setIsTTESimulationActive(prev => !prev); handleGeneratePlot(); }}
                        onSet0DTESimulation={() => {
                            setCurrentSimulatedTTEDays(0);
                            if (isTTESimulationActive) handleGeneratePlot(); else { setIsTTESimulationActive(true); handleGeneratePlot(); }
                         }}
                        onResetTTESimulation={() => {
                            setIsTTESimulationActive(false);
                            setCurrentSimulatedTTEDays(plotOptions.initialTTEForSimulation ? Math.max(0, Math.round(plotOptions.initialTTEForSimulation * 365)) : 45);
                            setSimulationSigmaInput(plotOptions.simulationSigma || '0.20');
                            setSimulationRInput(plotOptions.simulationR || '0.05');
                            handleGeneratePlot(); 
                        }}
                        onCurrentSimulatedTTEDaysChange={(days) => { setCurrentSimulatedTTEDays(days); if (isTTESimulationActive) handleGeneratePlot(); }}
                        onSimulationSigmaInputChange={(val) => { setSimulationSigmaInput(val); if (isTTESimulationActive) handleGeneratePlot(); }}
                        onSimulationRInputChange={(val) => { setSimulationRInput(val); if (isTTESimulationActive) handleGeneratePlot(); }}
                        anyAppLoading={anyAppLoading}
                    />
                </PanelSection>
            )}

            {showBlackScholes && ( 
                <PanelSection title="Black-Scholes Calculator" isVisible={showBlackScholes} onToggle={() => { toggleSection(setShowBlackScholes, 'showBlackScholes'); }}>
                    <BlackScholesCalculator 
                        underlyingNameForFetch={plotOptions.underlyingName}
                        onBlackScholesError={(calcError, fetchError) => {
                            if (calcError) { showStatus(`B/S Calc Error: ${calcError}`, 'error'); setAllLoggedErrors(prev => [...prev, `B/S Calc: ${calcError}`]); }
                            if (fetchError) { showStatus(`B/S Fetch Error: ${fetchError}`, 'error'); setAllLoggedErrors(prev => [...prev, `B/S Fetch: ${fetchError}`]); }
                        }}
                    />
                </PanelSection>
            )}
            
            {showDataManagement && (
                <PanelSection title="Data Management" isVisible={showDataManagement} onToggle={() => toggleSection(setShowDataManagement)} titleIcon={<DatabaseIcon/>}>
                    <DataManagementPanel githubSettings={githubSettings} onGitHubSettingsChange={(field, value) => setGithubSettings(prev => ({ ...prev, [field]: value }))} onExportData={handleExportData} onClearForm={handleClearForm} anyAppLoading={anyAppLoading} isExporting={isExporting} />
                </PanelSection>
            )}

            {showAnalyticsPanel && (
                 <PanelSection title="Analytics & App Health" isVisible={showAnalyticsPanel} onToggle={() => toggleSection(setShowAnalyticsPanel, 'showAnalyticsPanel')} titleIcon={<AnalyticsIcon />}>
                    <AnalyticsTabContent allLoggedErrors={allLoggedErrors} onCopyErrorsToClipboard={handleCopyErrorsToClipboard} anyAppLoading={anyAppLoading} />
                </PanelSection>
            )}
            
            {showDeveloperTools && (
                <PanelSection title="Developer Tools" isVisible={showDeveloperTools} onToggle={() => toggleSection(setShowDeveloperTools)}>
                    <DeveloperToolsPanel 
                        showAIDataProvenance={showAIDataProvenance} 
                        onToggleAIDataProvenance={setShowAIDataProvenance}
                        allAccumulatedAISources={allAccumulatedAISources}
                        aiCallDurations={appDBState.aiCallDurations}
                        anyAppLoading={anyAppLoading}
                    />
                </PanelSection>
            )}
            <div className="mt-4 flex flex-col sm:flex-row items-center gap-3 sm:gap-4">
                <ChartSettingsDropdown
                    showBlackScholes={showBlackScholes}
                    onToggleBlackScholes={() => toggleSection(setShowBlackScholes, 'showBlackScholes')}
                    showTTESimulation={showTTESimulation}
                    onToggleTTESimulation={() => toggleSection(setShowTTESimulation)}
                    showDataManagement={showDataManagement}
                    onToggleDataManagement={() => toggleSection(setShowDataManagement)}
                    showDeveloperTools={showDeveloperTools}
                    onToggleDeveloperTools={() => toggleSection(setShowDeveloperTools)}
                    showAnalyticsPanel={showAnalyticsPanel}
                    onToggleAnalyticsPanel={() => toggleSection(setShowAnalyticsPanel, 'showAnalyticsPanel')}
                    anyAppLoading={anyAppLoading}
                />
                <button 
                    onClick={handleGeneratePlot}
                    disabled={anyAppLoading || isLoadingPlot || legs.length === 0}
                    style={{backgroundColor: OREGON_GREEN}}
                    className="w-full sm:w-auto flex-grow sm:flex-grow-0 p-2.5 rounded-lg text-sm font-medium shadow-md text-white hover:opacity-90 transition-all duration-150 disabled:opacity-60 flex items-center justify-center"
                >
                    {isLoadingPlot ? <LoadingSpinner className="h-4 w-4 mr-2"/> : <ChartIcon className="mr-1.5 w-4 h-4"/>}
                    {isLoadingPlot ? "Plotting..." : "Generate Plot"}
                </button>
            </div>
        </div>
      </div>
        {isOptionsChainModalOpen && optionsChainForModal && (
            <OptionsChainModal
            isOpen={isOptionsChainModalOpen}
            onClose={() => { setIsOptionsChainModalOpen(false); setModalPrimingLeg(null); }}
            optionsChain={optionsChainForModal}
            currentUILegs={legs}
            targetStrikesFromAI={targetStrikesForModal}
            onPremiumSelect={handleModalPremiumSelect}
            underlyingName={plotOptions.underlyingName}
            currentStockPriceForChain={currentStockPriceForModalChain}
            primedLegForModal={modalPrimingLeg}
            />
        )}
        {reasoningModalInfo && (
            <ReasoningModal info={reasoningModalInfo} onClose={() => setReasoningModalInfo(null)} />
        )}
         {isStockInsightModalOpen && currentStockForInsightModal && (
            <StockInsightModal
                isOpen={isStockInsightModalOpen}
                onClose={() => { setIsStockInsightModalOpen(false); setCurrentStockForInsightModal(null);}}
                modalData={currentStockForInsightModal}
                onSetHistoricalContextForStrategy={handleSetHistoricalContextForStrategy}
            />
        )}
         {anyAppLoading && (
            <div style={{backgroundColor: DUKE_BLUE}} className="fixed bottom-4 right-4 text-white text-xs px-3 py-1.5 rounded-full shadow-xl z-[100] flex items-center">
                <LoadingSpinner className="h-4 w-4 mr-2"/>
                Processing...
            </div>
        )}
    </div>
  );
};