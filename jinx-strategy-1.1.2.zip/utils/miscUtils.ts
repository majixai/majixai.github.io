// utils/miscUtils.ts

export const generateUniqueId = (): string => `leg_${Date.now().toString(36)}_${Math.random().toString(36).substring(2, 9)}`;

export const formatDate = (timestamp?: number): string => {
    if (!timestamp) return 'N/A';
    return new Date(timestamp).toLocaleString();
};

export const formatPrice = (price?: number | null): string => {
    if (price === null || price === undefined) return 'N/A';
    return `$${price.toFixed(2)}`;
};

// Add other miscellaneous utility functions here as needed.