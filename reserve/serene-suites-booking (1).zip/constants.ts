
import { Room } from './types';

export const HOTEL_ROOMS: Room[] = [
  {
    id: 1,
    name: 'Ocean View Serenity',
    description: 'Wake up to the soothing sounds of the ocean in this beautifully appointed room with a private balcony overlooking the sea.',
    price: 350,
    imageUrl: 'https://picsum.photos/seed/ocean/800/600',
    detailedDescription: 'The Ocean View Serenity room offers an unparalleled coastal experience. Floor-to-ceiling windows provide breathtaking views of the ocean, while the private balcony is the perfect spot to enjoy your morning coffee. The room features a plush king-size bed, a spa-like bathroom with a rainfall shower, and a comfortable seating area.',
    amenities: ['Private Balcony', 'King-size Bed', 'Jacuzzi Tub', 'Mini Bar', 'Free Wi-Fi', '4K Smart TV'],
  },
  {
    id: 2,
    name: 'Metropolitan Suite',
    description: 'A chic, modern suite offering panoramic city views. Perfect for the urban explorer seeking luxury and convenience.',
    price: 450,
    imageUrl: 'https://picsum.photos/seed/city/800/600',
    detailedDescription: 'Experience the city from above in our Metropolitan Suite. Located on the top floors, this suite boasts panoramic views of the skyline. It features a separate living area, a dedicated workspace, a king-size bed, and a luxurious bathroom with premium toiletries. It\'s the ultimate urban retreat for business or leisure.',
    amenities: ['Cityscape Views', 'Workstation', 'Espresso Machine', 'Rainfall Shower', 'High-speed Wi-Fi', 'Room Service'],
  },
  {
    id: 3,
    name: 'Garden Oasis Retreat',
    description: 'Escape to a peaceful sanctuary surrounded by lush gardens. This ground-floor room offers direct access to our tranquil oasis.',
    price: 280,
    imageUrl: 'https://picsum.photos/seed/garden/800/600',
    detailedDescription: 'The Garden Oasis Retreat is a ground-floor haven of peace and tranquility. Step from your room onto a private patio with direct access to our beautifully landscaped gardens. The room is decorated in calming, natural tones and features a comfortable queen-size bed, a deep soaking tub, and all the modern amenities you need for a relaxing stay.',
    amenities: ['Direct Garden Access', 'Queen-size Bed', 'Soaking Tub', 'Patio Seating', 'Free Wi-Fi', 'Gourmet Coffee'],
  },
];