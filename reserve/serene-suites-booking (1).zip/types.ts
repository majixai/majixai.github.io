
export interface Room {
  id: number;
  name: string;
  description: string;
  price: number;
  imageUrl: string;
  detailedDescription: string;
  amenities: string[];
}

export interface Booking {
  id: string;
  roomId: number;
  roomName: string;
  guestName: string;
  guestEmail: string;
  checkInDate: string;
  checkOutDate: string;
}