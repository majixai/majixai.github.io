
import React, { useEffect } from 'react';
import type { Room } from '../types';
import { CheckIcon } from './icons/CheckIcon';

interface RoomDetailsModalProps {
  room: Room | null;
  onClose: () => void;
}

export const RoomDetailsModal: React.FC<RoomDetailsModalProps> = ({ room, onClose }) => {
  useEffect(() => {
    if (room) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'auto';
    }
    return () => {
      document.body.style.overflow = 'auto';
    };
  }, [room]);

  if (!room) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-50 p-4 overflow-y-auto">
      <div className="bg-white rounded-xl shadow-2xl max-w-3xl w-full relative transform transition-all duration-300 scale-95 animate-fade-in-up my-8">
        <button onClick={onClose} className="absolute top-4 right-4 text-gray-400 hover:text-gray-600 transition-colors z-10">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" /></svg>
        </button>
        <div className="max-h-[90vh] overflow-y-auto rounded-xl">
          <img className="w-full h-64 object-cover" src={room.imageUrl} alt={room.name} />
          <div className="p-8">
            <h2 className="text-4xl font-bold text-gray-900 mb-2">{room.name}</h2>
            <p className="text-xl text-indigo-600 font-semibold mb-6">${room.price} / night</p>
            
            <p className="text-gray-700 mb-6">{room.detailedDescription}</p>

            <h3 className="text-2xl font-semibold text-gray-800 mb-4">Amenities</h3>
            <ul className="grid grid-cols-1 sm:grid-cols-2 gap-x-8 gap-y-2">
              {room.amenities.map((amenity, index) => (
                <li key={index} className="flex items-center text-gray-600">
                  <CheckIcon className="w-5 h-5 text-green-500 mr-3" />
                  <span>{amenity}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
      <style>{`
        @keyframes fade-in-up {
          0% {
            opacity: 0;
            transform: translateY(20px) scale(0.95);
          }
          100% {
            opacity: 1;
            transform: translateY(0) scale(1);
          }
        }
        .animate-fade-in-up {
          animation: fade-in-up 0.3s ease-out forwards;
        }
      `}</style>
    </div>
  );
};