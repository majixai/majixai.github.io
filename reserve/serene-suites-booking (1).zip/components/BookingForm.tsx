import React, { useState, useEffect, useMemo } from 'react';
import type { Room, Booking } from '../types';

interface BookingFormProps {
  selectedRoom: Room | null;
  onBook: (bookingDetails: Omit<Booking, 'id' | 'roomName'>) => void;
  onClose: () => void;
  isSaving: boolean;
}

export const BookingForm: React.FC<BookingFormProps> = ({ selectedRoom, onBook, onClose, isSaving }) => {
  const [guestName, setGuestName] = useState('');
  const [guestEmail, setGuestEmail] = useState('');
  const [checkInDate, setCheckInDate] = useState('');
  const [checkOutDate, setCheckOutDate] = useState('');
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (selectedRoom) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'auto';
    }
    return () => {
      document.body.style.overflow = 'auto';
    };
  }, [selectedRoom]);

  const { nights, subtotal, discount, total } = useMemo(() => {
    if (!checkInDate || !checkOutDate || !selectedRoom) {
      return { nights: 0, subtotal: 0, discount: 0, total: 0 };
    }

    const startDate = new Date(checkInDate);
    const endDate = new Date(checkOutDate);

    if (endDate <= startDate) {
      return { nights: 0, subtotal: 0, discount: 0, total: 0 };
    }

    const diffTime = endDate.getTime() - startDate.getTime();
    const nights = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (nights <= 0) {
        return { nights: 0, subtotal: 0, discount: 0, total: 0 };
    }

    const subtotal = selectedRoom.price * nights;
    const discount = nights >= 30 ? subtotal * 0.10 : 0;
    const total = subtotal - discount;

    return { nights, subtotal, discount, total };
  }, [checkInDate, checkOutDate, selectedRoom]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedRoom || isSaving) return;

    if (!guestName || !guestEmail || !checkInDate || !checkOutDate) {
      setError('Please fill in all fields.');
      return;
    }
    if (new Date(checkOutDate) <= new Date(checkInDate)) {
      setError('Check-out date must be after check-in date.');
      return;
    }
    setError(null);
    onBook({
      roomId: selectedRoom.id,
      guestName,
      guestEmail,
      checkInDate,
      checkOutDate,
    });
  };

  if (!selectedRoom) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-50 p-4 overflow-y-auto">
      <div className="bg-white rounded-xl shadow-2xl p-8 max-w-lg w-full relative transform transition-all duration-300 scale-95 animate-fade-in-up my-8">
        <button onClick={onClose} className="absolute top-4 right-4 text-gray-400 hover:text-gray-600 transition-colors">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" /></svg>
        </button>
        <h2 className="text-3xl font-bold text-gray-900 mb-2">Book Your Stay</h2>
        <p className="text-lg text-indigo-600 font-semibold mb-6">You've selected: {selectedRoom.name}</p>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label htmlFor="guestName" className="block text-sm font-medium text-gray-700">Full Name</label>
            <input type="text" id="guestName" value={guestName} onChange={(e) => setGuestName(e.target.value)} className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" />
          </div>
          <div>
            <label htmlFor="guestEmail" className="block text-sm font-medium text-gray-700">Email Address</label>
            <input type="email" id="guestEmail" value={guestEmail} onChange={(e) => setGuestEmail(e.target.value)} className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="checkInDate" className="block text-sm font-medium text-gray-700">Check-in Date</label>
              <input type="date" id="checkInDate" value={checkInDate} onChange={(e) => setCheckInDate(e.target.value)} min={new Date().toISOString().split("T")[0]} className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" />
            </div>
            <div>
              <label htmlFor="checkOutDate" className="block text-sm font-medium text-gray-700">Check-out Date</label>
              <input type="date" id="checkOutDate" value={checkOutDate} onChange={(e) => setCheckOutDate(e.target.value)} min={checkInDate || new Date().toISOString().split("T")[0]} className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" />
            </div>
          </div>
          
          {nights > 0 && (
            <div className="mt-6 p-4 bg-gray-50 rounded-lg border border-gray-200">
              <h3 className="text-lg font-semibold text-gray-800 mb-3">Price Breakdown</h3>
              <div className="space-y-2 text-sm text-gray-600">
                <div className="flex justify-between">
                  <span>${selectedRoom.price.toFixed(2)} / night &times; {nights} {nights === 1 ? 'night' : 'nights'}</span>
                  <span>${subtotal.toFixed(2)}</span>
                </div>
                {discount > 0 && (
                  <div className="flex justify-between text-green-600 font-medium">
                    <span>Long stay discount (10%)</span>
                    <span>&minus;${discount.toFixed(2)}</span>
                  </div>
                )}
                <div className="border-t border-gray-200 pt-2 mt-2">
                    <div className="flex justify-between font-bold text-gray-900 text-base">
                        <span>Total Price</span>
                        <span>${total.toFixed(2)}</span>
                    </div>
                </div>
              </div>
            </div>
          )}

          {error && <p className="text-red-500 text-sm mt-2">{error}</p>}
          <button 
            type="submit" 
            disabled={isSaving}
            className="w-full bg-indigo-600 text-white font-bold py-3 px-4 rounded-lg hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-opacity-50 transition-colors duration-300 text-lg disabled:bg-indigo-400 disabled:cursor-not-allowed"
          >
            {isSaving ? 'Confirming...' : 'Confirm Booking'}
          </button>
        </form>
      </div>
       <style>{`
        @keyframes fade-in-up {
          0% {
            opacity: 0;
            transform: translateY(20px) scale(0.95);
          }
          100% {
            opacity: 1;
            transform: translateY(0) scale(1);
          }
        }
        .animate-fade-in-up {
          animation: fade-in-up 0.3s ease-out forwards;
        }
      `}</style>
    </div>
  );
};