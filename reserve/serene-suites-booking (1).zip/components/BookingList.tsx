
import React from 'react';
import type { Booking } from '../types';
import { CalendarIcon } from './icons/CalendarIcon';

interface BookingListProps {
  bookings: Booking[];
}

export const BookingList: React.FC<BookingListProps> = ({ bookings }) => {
  if (bookings.length === 0) {
    return (
        <div className="text-center py-10 px-6 bg-white rounded-lg shadow-md">
            <h3 className="text-xl font-semibold text-gray-800">No Bookings Yet</h3>
            <p className="text-gray-500 mt-2">Your confirmed bookings will appear here.</p>
        </div>
    );
  }

  return (
    <div className="space-y-4">
      {bookings.map((booking) => (
        <div key={booking.id} className="bg-white p-6 rounded-lg shadow-md border-l-4 border-green-500">
          <div className="flex flex-col sm:flex-row justify-between">
            <div>
                <h4 className="text-xl font-bold text-gray-800">{booking.roomName}</h4>
                <p className="text-gray-600">{booking.guestName} ({booking.guestEmail})</p>
            </div>
            <div className="flex items-center space-x-4 mt-4 sm:mt-0 text-gray-700">
                <div className="flex items-center space-x-2">
                    <CalendarIcon className="w-5 h-5 text-green-600" />
                    <span>{new Date(booking.checkInDate).toLocaleDateString()}</span>
                </div>
                <span>&rarr;</span>
                <div className="flex items-center space-x-2">
                    <CalendarIcon className="w-5 h-5 text-red-600" />
                    <span>{new Date(booking.checkOutDate).toLocaleDateString()}</span>
                </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};
