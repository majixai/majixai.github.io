
import React from 'react';
import type { Room } from '../types';

interface RoomCardProps {
  room: Room;
  onSelectRoom: (room: Room) => void;
  onViewDetails: (room: Room) => void;
}

export const RoomCard: React.FC<RoomCardProps> = ({ room, onSelectRoom, onViewDetails }) => {
  return (
    <div className="bg-white rounded-lg shadow-lg overflow-hidden transform hover:scale-105 transition-transform duration-300 ease-in-out flex flex-col">
      <img className="w-full h-56 object-cover" src={room.imageUrl} alt={room.name} />
      <div className="p-6 flex flex-col flex-grow">
        <h3 className="text-2xl font-semibold text-gray-800 mb-2">{room.name}</h3>
        <p className="text-gray-600 mb-4 h-24 flex-grow">{room.description}</p>
        <div className="mt-auto">
          <p className="text-xl font-bold text-indigo-600 mb-4">
            ${room.price} <span className="text-sm font-normal text-gray-500">/ night</span>
          </p>
          <div className="flex flex-col sm:flex-row gap-2">
            <button
              onClick={() => onViewDetails(room)}
              className="flex-1 bg-gray-200 text-gray-800 font-bold py-2 px-4 rounded-lg hover:bg-gray-300 focus:outline-none focus:ring-2 focus:ring-gray-400 focus:ring-opacity-50 transition-colors duration-300"
            >
              View Details
            </button>
            <button
              onClick={() => onSelectRoom(room)}
              className="flex-1 bg-indigo-600 text-white font-bold py-2 px-4 rounded-lg hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-opacity-50 transition-colors duration-300"
            >
              Book Now
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};