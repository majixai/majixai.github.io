
import React, { useState, useEffect, useCallback } from 'react';
import { Header } from './components/Header';
import { RoomCard } from './components/RoomCard';
import { BookingForm } from './components/BookingForm';
import { BookingList } from './components/BookingList';
import { RoomDetailsModal } from './components/RoomDetailsModal';
import { CheckCircleIcon } from './components/icons/CheckCircleIcon';
import { XCircleIcon } from './components/icons/XCircleIcon';
import { HOTEL_ROOMS } from './constants';
import type { Room, Booking } from './types';

// Declare pako for TypeScript since it's loaded from a script tag
declare var pako: any;

// GitHub Configuration - WARNING: Hardcoding tokens in client-side code is highly insecure.
// This should be handled by a backend service in a real-world application.
const GITHUB_TOKEN = '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';
const GITHUB_REPO_OWNER = 'serene-suites-data';
const GITHUB_REPO_NAME = 'reservations';
const GITHUB_BOOKINGS_PATH = 'bookings';
const GITHUB_API_URL = `https://api.github.com/repos/${GITHUB_REPO_OWNER}/${GITHUB_REPO_NAME}/contents/${GITHUB_BOOKINGS_PATH}`;

// --- Helper Functions ---
function uint8ArrayToBase64(array: Uint8Array): string {
  let binary = '';
  for (let i = 0; i < array.byteLength; i++) {
    binary += String.fromCharCode(array[i]);
  }
  return btoa(binary);
}
// --- End Helper Functions ---

const App: React.FC = () => {
  const [selectedRoom, setSelectedRoom] = useState<Room | null>(null);
  const [viewingRoomDetails, setViewingRoomDetails] = useState<Room | null>(null);
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchBookings = async () => {
      try {
        const response = await fetch(GITHUB_API_URL, {
          headers: {
            'Authorization': `token ${GITHUB_TOKEN}`,
            'Accept': 'application/vnd.github.v3+json',
          },
        });

        if (response.status === 404) {
          console.log('Bookings repository or directory not found. Starting with empty list.');
          setBookings([]);
          return;
        }

        if (!response.ok) {
          const errorData = await response.json();
          throw new Error(`Failed to fetch bookings: ${errorData.message || response.statusText}`);
        }

        const files: { name: string; url: string }[] = await response.json();
        
        const bookingPromises = files
          .filter(file => file.name.endsWith('.json.gz'))
          .map(async (file) => {
            const fileResponse = await fetch(file.url, {
              headers: {
                'Authorization': `token ${GITHUB_TOKEN}`,
                'Accept': 'application/vnd.github.v3.raw', // Fetch raw content directly
              },
            });
            if (!fileResponse.ok) {
              console.error(`Failed to fetch file content: ${file.name}`);
              return null;
            }
            const blob = await fileResponse.blob();
            const buffer = await blob.arrayBuffer();
            const compressedData = new Uint8Array(buffer);
            const decompressedData = pako.inflate(compressedData, { to: 'string' });
            return JSON.parse(decompressedData) as Booking;
        });

        const resolvedBookings = (await Promise.all(bookingPromises)).filter((b): b is Booking => b !== null);
        setBookings(resolvedBookings);
      } catch (err: any) {
        console.error(err);
        setError('Could not load existing bookings. Please try again later.');
      } finally {
        setIsLoading(false);
      }
    };

    fetchBookings();
  }, []);
  
  const handleSelectRoom = useCallback((room: Room) => setSelectedRoom(room), []);
  const handleCloseForm = useCallback(() => setSelectedRoom(null), []);
  const handleViewDetails = useCallback((room: Room) => setViewingRoomDetails(room), []);
  const handleCloseDetailsModal = useCallback(() => setViewingRoomDetails(null), []);

  const handleBookRoom = useCallback(async (bookingDetails: Omit<Booking, 'id' | 'roomName'>) => {
    const room = HOTEL_ROOMS.find(r => r.id === bookingDetails.roomId);
    if (!room) return;

    setIsSaving(true);
    setError(null);

    const newBooking: Booking = {
      ...bookingDetails,
      id: `${new Date().getTime()}-${Math.random().toString(36).substring(2, 9)}`,
      roomName: room.name,
    };

    try {
      const bookingJson = JSON.stringify(newBooking);
      const compressedData = pako.deflate(bookingJson);
      const base64Content = uint8ArrayToBase64(compressedData);
      
      const response = await fetch(`${GITHUB_API_URL}/${newBooking.id}.json.gz`, {
        method: 'PUT',
        headers: {
          'Authorization': `token ${GITHUB_TOKEN}`,
          'Accept': 'application/vnd.github.v3+json',
        },
        body: JSON.stringify({
          message: `feat: add booking ${newBooking.id}`,
          content: base64Content,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(`Failed to save booking: ${errorData.message || response.statusText}`);
      }
      
      setBookings(prevBookings => [...prevBookings, newBooking]);
      setSelectedRoom(null);
      setShowConfirmation(true);
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'An unknown error occurred while saving.');
    } finally {
      setIsSaving(false);
    }
  }, []);

  useEffect(() => {
    if (showConfirmation) {
      const timer = setTimeout(() => setShowConfirmation(false), 4000);
      return () => clearTimeout(timer);
    }
  }, [showConfirmation]);
  
  useEffect(() => {
    if (error) {
        const timer = setTimeout(() => setError(null), 5000);
        return () => clearTimeout(timer);
    }
  }, [error]);

  return (
    <div className="min-h-screen bg-gray-100 font-sans">
      <Header />
      <main className="container mx-auto px-6 py-8">
        <section id="rooms" className="mb-12">
          <h2 className="text-4xl font-bold text-center text-gray-800 mb-8">Our Rooms</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {HOTEL_ROOMS.map(room => (
              <RoomCard 
                key={room.id} 
                room={room} 
                onSelectRoom={handleSelectRoom}
                onViewDetails={handleViewDetails}
              />
            ))}
          </div>
        </section>

        <section id="bookings">
          <h2 className="text-4xl font-bold text-center text-gray-800 mb-8">Your Bookings</h2>
          {isLoading ? (
            <div className="text-center py-10 px-6 bg-white rounded-lg shadow-md">
                <p className="text-lg text-gray-600">Loading bookings from GitHub...</p>
            </div>
          ) : (
            <BookingList bookings={bookings} />
          )}
        </section>
      </main>

      <BookingForm 
        selectedRoom={selectedRoom} 
        onBook={handleBookRoom} 
        onClose={handleCloseForm} 
        isSaving={isSaving}
      />

      <RoomDetailsModal
        room={viewingRoomDetails}
        onClose={handleCloseDetailsModal}
      />

      {/* Toasts */}
      {showConfirmation && (
        <div className="fixed bottom-5 right-5 bg-white border-l-4 border-green-500 text-gray-800 p-4 rounded-lg shadow-lg flex items-center space-x-4 animate-slide-in-up z-50">
          <CheckCircleIcon className="w-8 h-8 text-green-500" />
          <div>
            <p className="font-bold">Booking Confirmed!</p>
            <p className="text-sm text-gray-600">Your reservation has been saved to GitHub.</p>
          </div>
        </div>
      )}
      {error && (
        <div className="fixed bottom-24 right-5 bg-white border-l-4 border-red-500 text-gray-800 p-4 rounded-lg shadow-lg flex items-center space-x-4 animate-slide-in-up z-50">
          <XCircleIcon className="w-8 h-8 text-red-500" />
          <div>
            <p className="font-bold">An Error Occurred</p>
            <p className="text-sm text-gray-600">{error}</p>
          </div>
        </div>
      )}
      <style>{`
        @keyframes slide-in-up {
          from { transform: translateY(100%); opacity: 0; }
          to { transform: translateY(0); opacity: 1; }
        }
        .animate-slide-in-up {
          animation: slide-in-up 0.5s cubic-bezier(0.25, 0.46, 0.45, 0.94) both;
        }
      `}</style>
    </div>
  );
};

export default App;